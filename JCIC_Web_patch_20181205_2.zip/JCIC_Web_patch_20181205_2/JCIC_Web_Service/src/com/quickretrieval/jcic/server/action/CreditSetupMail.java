/**
 * 
 */
package com.quickretrieval.jcic.server.action;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpSession;

import com.quickretrieval.common.utils.FormatCheckUtil;
import com.quickretrieval.common.utils.MyDate;
import com.quickretrieval.server.log.Log;
import com.quickretrieval.jcic.server.adapter.LoginSessionControl;
import com.quickretrieval.jcic.server.db.SetupMailInfoDao;
import com.quickretrieval.jcic.server.entity.EndUser;
import com.quickretrieval.jcic.server.entity.EndUserServiceResult;
import com.quickretrieval.jcic.server.entity.SetupMailInfo;
import com.quickretrieval.jcic.server.entity.Transaction;
import com.quickretrieval.jcic.server.entity.UserErrorInfo;
import com.quickretrieval.server.control.RequestWrapper;
import com.quickretrieval.server.control.ResponseWrapper;

/**
 * @author BruceHuang
 * 這個 Class 實現信用報告查詢的各項使用者操作功能業務邏輯
 */
public class CreditSetupMail extends EndUserBaseAction {

	/**
	 * Default Serialized Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	// Action Services
	private static final String SETUP_EMAIL_SERVICE_NAME = "SetupMail.do";
	private static final String SETUP_MAIL_INPUT_SERVICE_NAME = "SetupMailInput.do";
	private static final String SETUP_MAIL_UPDATE_SERVICE_NAME = "SetupMailUpdate.do";
	private static final String SETUP_MAIL_DELETE_SERVICE_NAME = "SetupMailDelete.do";
	
	// Session Attributes
	private static final String SESSION_ATTRIBUTE_CSRF_TOKEN = "csrf_token";
	
	// Request Parameters
	private static final String REQUEST_PARAMETER_EMAIL = "email";
	private static final String REQUEST_PARAMETER_CSRF_TOKEN = "csrf_token";
	// Response Data Parameters
	private static final String RESPONSE_DATA_USER = "user";
	private static final String RESPONSE_DATA_EMAIL_INFO = "email_info";
	private static final String RESPONSE_DATA_CSRF_TOKEN = "csrf_token";
	
	private String setSessionCSRFToken(RequestWrapper request) {
		//Random rnd = new SecureRandom();
		SecureRandom rnd = new SecureRandom();
		long rndValue = rnd.nextLong();
		String tokenValue = Long.toString(rndValue);
		this.setSessionInfo(request, SESSION_ATTRIBUTE_CSRF_TOKEN, tokenValue);
		return tokenValue;
	}
	
	private boolean checkSubmitCSRFToken(RequestWrapper request) {
		String input_token = request.getStringParameter(REQUEST_PARAMETER_CSRF_TOKEN, null);
		String session_token = this.getSessionInfo(request, SESSION_ATTRIBUTE_CSRF_TOKEN, String.class);
		if (input_token == null || session_token == null || !input_token.equals(session_token)) {
			return false;
		}
		return true;
	}
	
	/*
	 * 這個 Method 提供「設定 email 通知」的主功能，顯示用戶目前已設定的通知電子郵件設定資訊
	 */
	private EndUserServiceResult doSetupMail(RequestWrapper request) {
		String method = "doSetupMail";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		result.setCatalog(Transaction.CATALOG_SETUP_EMAIL);
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		// Read User current active Email Address
		SetupMailInfo emailInfo = SetupMailInfoDao.getInstance().getActiveByIDN(user.getUserIdentification());
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_USER, user);
		// Modify by 何政東, 20181205, set CSRF token
		if (emailInfo != null) {
			resultMap.put(RESPONSE_DATA_EMAIL_INFO, emailInfo);
			resultMap.put(RESPONSE_DATA_CSRF_TOKEN, this.setSessionCSRFToken(request));
		}
		result.setOutputResult(resultMap);
		return result;
	}
		
	/*
	 * 這個 Method 提供「設定 email 通知」的輸入頁面功能，顯示用戶目前的通知 Email 設定，並提供輸入／更新頁面
	 */
	private EndUserServiceResult doSetupMailInput(RequestWrapper request) {
		String method = "doSetupMailInput";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_SETUP_EMAIL);
		// Get/Check Login User
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		// Read User current active Email Address
		SetupMailInfo emailInfo = SetupMailInfoDao.getInstance().getActiveByIDN(user.getUserIdentification());
		String csrfToken = this.setSessionCSRFToken(request);
		// Setup Result
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_USER, user);
		resultMap.put(RESPONSE_DATA_CSRF_TOKEN, csrfToken);
		if (emailInfo != null) resultMap.put(RESPONSE_DATA_EMAIL_INFO, emailInfo);
		result.setOutputResult(resultMap);
		return result;
	}
	
	/*
	 * 這個 Method 提供「設定 email 通知」的新增／修改功能
	 * 本功能檢查用戶輸入的「email」是否符合電子郵件格式，並更新資料庫：
	 * (1) 將用戶所有有效(狀態為'A')的「通知 Email 設定」記錄（SetupMailInfo)，更新狀態為「已刪除('D')」，並設定更新時間為目前系統時間
	 * (2) 新增一筆「通知 Email 設定」記錄，填入用戶輸入的 Email，狀態為'A'，並設定新增時間為目前系統時間。
	 * 上述兩個資料庫操作，必須在一個 DB Transaction 內完成（亦即全部完成，或無一完成）。
	 */
	private EndUserServiceResult doSetupMailUpdate(RequestWrapper request) {
		String method = "doSetupMailUpdate";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_SETUP_EMAIL);
		// Get/Check Login User
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		// Check CSRF Token
		if (!this.checkSubmitCSRFToken(request)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Get Request Parameters
		String mail_address = request.getStringParameter(REQUEST_PARAMETER_EMAIL, null);
		if (mail_address == null || !FormatCheckUtil.isEmailAddressFormat(mail_address, 50)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_INVALID_EMAIL, "Invalid email address", null);
			Log.warning(this, method, "Invalid email address Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input_invalid_email_address");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Setup new SetupMailInfo object
		MyDate date = new MyDate();
		SetupMailInfo emailInfo = new SetupMailInfo();
		emailInfo.setUserIDN(user.getUserIdentification());
		emailInfo.setEmailAddress(mail_address);
		emailInfo.setStatusInserted();
		emailInfo.setInsertTime(date);
		emailInfo.setUpdateTime(date);
		if (!SetupMailInfoDao.getInstance().updateToNew(emailInfo)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_DB_ERROR, "Update to Database Error", null);
			Log.error(this, method, "Update to Database Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Setup Result
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("user", user);
		// Modify by 何政東, 20181205, set CSRF token
		if (emailInfo != null) {
			resultMap.put("email_info", emailInfo);
			resultMap.put(RESPONSE_DATA_CSRF_TOKEN, this.setSessionCSRFToken(request));
		}
		result.setOutputResult(resultMap);
		return result;
	}
	
	/*
	 * 這個 Method 提供「設定 email 通知」的刪除功能。
	 * 將此用戶原設定有效的郵件通知設定，更新狀態為「已刪除(D)」，以及更新時間設為目前的系統日期時間
	 */
	private EndUserServiceResult doSetupMailDelete(RequestWrapper request) {
		String method = "doSetupMailDelete";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_SETUP_EMAIL);
		// Get/Check Login User
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		// Check CSRF Token
		if (!this.checkSubmitCSRFToken(request)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		SetupMailInfo emailInfo = SetupMailInfoDao.getInstance().getActiveByIDN(user.getUserIdentification());
		if (emailInfo != null) {
			emailInfo.setStatusDeleted();
			emailInfo.setUpdateTime(new MyDate());
			if (!SetupMailInfoDao.getInstance().update(emailInfo)) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_DB_ERROR, "Update to Database Error", null);
				Log.error(this, method, "Update to Database Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(errorInfo);
				return result;
			}
		}
		// Setup Result
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("user", user);
		result.setOutputResult(resultMap);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.quickretrieval.jcic.server.action.EndUserBaseAction#doService(java.lang.String, javax.servlet.http.RequestWrapper, javax.servlet.http.ResponseWrapper)
	 */
	@Override
	protected EndUserServiceResult doService(String serviceName, RequestWrapper request, ResponseWrapper response) {
		// long service_begin_time = System.currentTimeMillis();
		EndUserServiceResult result = null;
		if (serviceName.equalsIgnoreCase(SETUP_EMAIL_SERVICE_NAME)) {
			result = doSetupMail(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(SETUP_MAIL_INPUT_SERVICE_NAME)) {
			result = doSetupMailInput(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(SETUP_MAIL_UPDATE_SERVICE_NAME)) {
			result = doSetupMailUpdate(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(SETUP_MAIL_DELETE_SERVICE_NAME)) {
			result = doSetupMailDelete(request);
			return result;
		}
		Log.error(this, "doService", "service("+serviceName+") not found"); 
		return null;
	}
}
