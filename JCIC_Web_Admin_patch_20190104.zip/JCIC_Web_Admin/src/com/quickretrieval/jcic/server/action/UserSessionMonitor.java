/**
 * 
 */
package com.quickretrieval.jcic.server.action;

// Add by 何政東, 20190104, sort sessions
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import com.quickretrieval.jcic.server.adapter.GetUserSessionClient;
import com.quickretrieval.jcic.server.control.JCICServiceResult;
import com.quickretrieval.jcic.server.entity.UserSessionInfo;
import com.quickretrieval.server.log.Log;
import com.quickretrieval.server.control.BaseAction;
import com.quickretrieval.server.control.RequestWrapper;
import com.quickretrieval.server.control.ResponseWrapper;
import com.quickretrieval.server.control.ServiceResult;
import com.quickretrieval.server.entity.ErrorInfo;

/**
 * @author BruceHuang
 *
 */
public class UserSessionMonitor extends BaseAction {
	
	/**
	 * Default Serialized Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	private static String ACTION_LIST_USER_SESSIONS = "ListUserSessions.do";
	
	private ServiceResult doListUserSessions(RequestWrapper request, ResponseWrapper response) {
		
		Log.debug(this, "doListUserSessions", "invoked.");
		JCICServiceResult result = new JCICServiceResult();
		// Query All System Parameters from database
		ErrorInfo error = new ErrorInfo();
		List<UserSessionInfo> sessionsList = GetUserSessionClient.getInstance().getUserSessions(error);
		if (sessionsList == null || sessionsList.size() < 1) {
			result.setResultFlag(false);
			String[] args = { Integer.toString(error.getErrorCode()), error.getErrorMessage() };
			result.setErrorMessage("quickcode.error.query_no_user_sessions", args);
			return result;
		}
		UserSessionInfo[] sessions = new UserSessionInfo[sessionsList.size()];
		sessionsList.toArray(sessions);
		// Add by 何政東, 20190104, sort sessions
		Arrays.sort(sessions, new UserSessionInfoComparator());
		result.setResultFlag(true);
		result.setOutputResult(sessions);
		result.setOutputString("Get "+sessions.length+" User Sessions");
		Log.debug(this, "doListUserSessions", "Output:"+result.getOutputString());
		return result;
	}

	// Add by 何政東, 20190104, sort sessions
	private class UserSessionInfoComparator implements Comparator<UserSessionInfo> {
		@Override
		public int compare(UserSessionInfo s1, UserSessionInfo s2) {
			return -s1.getSessionReportTime().compareToIgnoreCase(s2.getSessionReportTime());
	    }
	}

	/* (non-Javadoc)
	 * @see com.quickretrieval.server.action.BaseService#doService(java.lang.String, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected ServiceResult doService(String serviceName,
									  RequestWrapper request, ResponseWrapper response) {
		if (serviceName.compareToIgnoreCase(ACTION_LIST_USER_SESSIONS)==0) {
			return doListUserSessions(request, response);
		} 
		Log.error(this, "doService", "cannot found Service="+serviceName);
		return null;
	}

}
