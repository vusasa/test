/**
 * 
 */
package com.quickretrieval.jcic.server.action;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.quickretrieval.common.utils.FormatCheckUtil;
import com.quickretrieval.common.utils.MyDate;
import com.quickretrieval.jcic.server.adapter.OrderProcedure;
import com.quickretrieval.jcic.server.adapter.PerformanceCollector;
import com.quickretrieval.jcic.server.adapter.InvoiceAdapter;
import com.quickretrieval.jcic.server.adapter.InvoiceAdapterCollector;
import com.quickretrieval.jcic.server.adapter.LoginSessionControl;
import com.quickretrieval.jcic.server.db.OrderDao;
import com.quickretrieval.jcic.server.db.UserJcicTokenDao;
import com.quickretrieval.jcic.server.db.WinnerInvoiceDao;
import com.quickretrieval.jcic.server.em.CreditCardType;
import com.quickretrieval.jcic.server.em.InvoiceMethod;
import com.quickretrieval.jcic.server.em.JcicTokenStatus;
import com.quickretrieval.jcic.server.em.OrderStatus;
import com.quickretrieval.jcic.server.entity.EndUser;
import com.quickretrieval.jcic.server.entity.EndUserServiceResult;
import com.quickretrieval.jcic.server.entity.InvoiceDonate;
import com.quickretrieval.jcic.server.entity.InvoiceInfo;
import com.quickretrieval.jcic.server.entity.Order;
import com.quickretrieval.jcic.server.entity.Transaction;
import com.quickretrieval.jcic.server.entity.UserErrorInfo;
import com.quickretrieval.jcic.server.entity.UserJcicToken;
import com.quickretrieval.jcic.server.entity.UserOrderControl;
import com.quickretrieval.jcic.server.entity.WinnerInvoice;
import com.quickretrieval.server.control.RequestWrapper;
import com.quickretrieval.server.control.ResponseWrapper;
import com.quickretrieval.server.dao.QueryResult;
import com.quickretrieval.server.log.Log;
import com.quickretrieval.server.properties.SystemProperties;

/**
 * @author brucehuang
 *
 */
public class CreditPaymentService extends EndUserBaseAction {

	/**
	 * Default Serialized Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	// Action Services Definition
	private static final String PAYMENT_WITH_INPUT_BILL_SERVICE_NAME = "PaymentWithInputBill.do";
	private static final String PAYMENT_WITH_ORDER_SERVICE_NAME = "PaymentWithOrder.do";
	private static final String PAYMENT_NOTIFY_SERVICE_NAME = "PaymentNotify.do";
	private static final String PAYMENT_CUP_NOTIFY_SERVICE_NAME = "PaymentCupNotify.do";
	private static final String PAYMENT_QUERY_ORDER_HISTORY_SERVICE_NAME = "QueryOrderHistory.do";
	private static final String PAYMENT_QUEYR_ORDER_INVOICE_SERVICE_NAME = "QueyrOrderInvoice.do";
	// Action Services for Credit Report Generate
	private static final String CREDIT_QUERY_REPORT_GENERATE_SERVICE_NAME = "CreditReportGenerate.do";
	
	// System Configuration Properties
	private static final String PROPERTY_SERVICE_EXTERNAL_URL = "service.external.url";
	
	// Session Attributes Definition
	private static final String SESSION_ATTRIBUTE_ORDER = "report_order";
	private static final String SESSION_ATTRIBUTE_ORDER_CONTROL = "report_order_control";

	// Request Parameters
	private static final String PARAMETER_CREDIT_CARD_TYPE = "credit_card_type";
	private static final String PARAMETER_INVOICE_METHOD = "invoice_method";
	private static final String PARAMETER_BUYER_NAME = "buyer_name";
	private static final String PARAMETER_INVOICE_NPOBAN = "invoice_npoban";
	private static final String PARAMETER_INVOICE_NPOCODE = "invoice_npocode";
	@SuppressWarnings("unused")
	private static final String PARAMETER_INVOICE_NPONAME = "invoice_npo_name";
	private static final String PARAMETER_BUYER_ADDRESS = "buyer_address";
	//Add by 何政東, 2018/07/23, add zip code parameter
	private static final String PARAMETER_BUYER_ZIP_CODE = "buyer_zip_code";
	private static final String PARAMETER_BUYER_PHONE = "buyer_phone";
	private static final String PARAMETER_BUYER_EMAIL = "buyer_email";
	private static final String PARAMETER_INVOICE_TAXBAN = "invoice_taxban";
	private static final String PARAMETER_INVOICE_PHONE_TOKEN = "invoice_phone_token";
	private static final String PARAMETER_INVOICE_CERT_TOKEN = "invoice_cert_token";
	private static final String PARAMETER_TRANSACTION_KEY = "KEY";
	private static final String PARAMETER_ORDER_NO = "order_no";
	// CUP Notify Parameters
	private static final String CUP_PARAMETER_TRANS_TYPE = "TransType";
	private static final String CUP_PARAMETER_RESPONSE_CODE = "RespCode";
	private static final String CUP_PARAMETER_RESPONSE_MESSAGE = "RespMsg";
	private static final String CUP_PARAMETER_MERCHANT_NAME = "MerAbbr";
	private static final String CUP_PARAMETER_MERCHANT_ID = "MerId";
	private static final String CUP_PARAMETER_ORDER_NO = "OrderNumber";
	private static final String CUP_PARAMETER_ORDER_AMOUNT = "orderAmount";
	private static final String CUP_PARAMETER_ORDER_CURRENCY = "OrderCurrency";
	private static final String CUP_PARAMETER_RESPONSE_TIME = "RespTime";
	private static final String CUP_PARAMETER_RESERVED = "CupReserved";
	private static final String CUP_PARAMETER_PAN = "Pan";
	// Response Result Map Field Define
	private static final String RESPONSE_DATA_USER = "user";
	private static final String RESPONSE_DATA_ORDER = "order";
	private static final String RESPONSE_DATA_ORDERS = "orders";
	private static final String RESPONSE_DATA_BEGIN_YEAR = "begin_year";
	private static final String RESPONSE_DATA_END_YEAR = "end_year";
	private static final String RESPONSE_DATA_REDIRECT_URL = "redirect";
	private static final String RESPONSE_DATA_NEXT_SERVICE = "next_service";
	@SuppressWarnings("unused")
	private static final String RESPONSE_DATA_AUTO_NEXT_SERVICE = "auto_next_service";
	private static final String RESPONSE_DATA_REDIRECT_HTML = "redirectHTML";
	
	// Constant Definitions
	@SuppressWarnings("unused")
	private static final int	MAX_ORDER_QUERY_COUNT = 10;
	
	private UserOrderControl getSessionOrderControl(RequestWrapper request, EndUser user) {
		UserOrderControl orderControl = this.getSessionInfo(request, SESSION_ATTRIBUTE_ORDER_CONTROL, UserOrderControl.class);
		if (orderControl == null || !orderControl.getIdnBan().equalsIgnoreCase(user.getUserIdentification())) {
			orderControl = OrderProcedure.getInstance().getUserOrderControl(user.getUserIdentification());
			this.setSessionOrderControl(request, orderControl);
		}
		return orderControl;
	}
	
	private UserOrderControl getIdnOrderControl(String idnBan) {
		UserOrderControl orderControl = OrderProcedure.getInstance().getUserOrderControl(idnBan);
		return orderControl;
	}
	
	private Order getSessionOrder(RequestWrapper request) {
		Order order = this.getSessionInfo(request, SESSION_ATTRIBUTE_ORDER, Order.class);
		if (order != null && 
			(order.getOrderStatus() == OrderStatus.WaitAuthorize || order.getOrderStatus() == OrderStatus.AuthorizeNotified)) {
			Order dbOrder = OrderProcedure.getInstance().getOrderByNo(order.getOrderNo());
			if (dbOrder.getOrderStatus().code() > order.getOrderStatus().code()) {
				order = dbOrder;
				this.setSessionInfo(request, SESSION_ATTRIBUTE_ORDER, order);
			}
		}
		return order;
	}
	
	private void setSessionOrderControl(RequestWrapper request, UserOrderControl orderControl) {
		if (orderControl == null) {
			this.removeSessionInfo(request, SESSION_ATTRIBUTE_ORDER_CONTROL);
		}
		this.setSessionInfo(request, SESSION_ATTRIBUTE_ORDER_CONTROL, orderControl);
	}
	
	private void setSessionOrder(RequestWrapper request, Order order) {
		if (order == null) {
			this.removeSessionInfo(request, SESSION_ATTRIBUTE_ORDER);
		}
		this.setSessionInfo(request, SESSION_ATTRIBUTE_ORDER, order);
	}

	@SuppressWarnings("unused")
	private String checkTaxBan(String taxBan) {
		if (taxBan == null || taxBan.trim().length() != 8) return null;
		taxBan = taxBan.trim();
		for (int i = 0; i < taxBan.length(); i++) {
			char c = taxBan.charAt(i);
			if (c < '0' || c > '9') return null;
		}
		return taxBan;
	}
	
	private String checkBuyerName(String name) {
		if (name == null) return null;
		name = name.trim();
		if (!FormatCheckUtil.isNameFormat(name, 60)) return null;
		return name;
	}
	
	private String checkEmail(String email) {
		if (email == null) return null;
		email = email.trim();
		if (!FormatCheckUtil.isEmailAddressFormat(email, 80)) return null;
		return email;
	}
	
	private String checkPhone(String phone) {
		if (phone == null || phone.trim().length() < 1) return null;
		phone = phone.trim();
		if (!FormatCheckUtil.isPhoneFormat(phone, 26)) return null;
		return phone;
	}
	
	private String checkAddress(String address) {
		if (address == null || address.trim().length() < 1) return null;
		address = address.trim();
		if (!FormatCheckUtil.isAddressFormat(address, 100)) return null;
		return address;
	}
	//Add by 何政東, 2018/07/23, check zip code
	private String checkZipCode(String zipCode) {
		if (zipCode == null || zipCode.trim().length() < 1) return null;
		zipCode = zipCode.trim();
		if (!FormatCheckUtil.isNumber(zipCode) || (zipCode.length()!=3 && zipCode.length()!=5)) return null;
		return zipCode;
	}
		
	private EndUserServiceResult doPaymentWithInputBill(RequestWrapper request) {
		String method = "doPaymentWithInputBill";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_CREDIT_PAYMENT);
		// Get/Check Login User
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_NOT_LOGIN, "User not login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NOT_LOGIN));
			return result;
		}
		user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_INPUT, 0);
		LoginSessionControl.updateLoginUser(request.getSession(false), user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		String[] args = {  Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_BILL_CHECK) };
		// Get Request Parameters
		int code = request.getIntParameter(PARAMETER_CREDIT_CARD_TYPE, CreditCardType.InternationalCard.code());
		CreditCardType cardType = CreditCardType.getCardCardType(code);
		// Check Card Type (Must be International Credit Card)
		if (cardType == null || cardType != CreditCardType.InternationalCard) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_CARD_TYPE_INVALID, "Invalid Card Type("+code+")", args);
			Log.error(this, method, "Check Credit Card Type Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_CARD_TYPE_INVALID));
			user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_CARD_TYPE_INVALID);
			return result;
		}
		code = request.getIntParameter(PARAMETER_INVOICE_METHOD, -1);
		InvoiceMethod invoiceMethod = InvoiceMethod.getInvoiceMethod(code);
		String buyer_name = request.getStringParameter(PARAMETER_BUYER_NAME, null);
		String invoice_npoban = request.getStringParameter(PARAMETER_INVOICE_NPOBAN, null);
		String invoice_npocode = request.getStringParameter(PARAMETER_INVOICE_NPOCODE, null);
		String buyer_address = request.getStringParameter(PARAMETER_BUYER_ADDRESS, null);
		//Add by 何政東, 2018/07/23, add zip code parameter
		String buyer_zip_code = request.getStringParameter(PARAMETER_BUYER_ZIP_CODE, null);
		String buyer_phone = request.getStringParameter(PARAMETER_BUYER_PHONE, null);
		String buyer_email = request.getStringParameter(PARAMETER_BUYER_EMAIL, null);
		String invoice_phone_token = request.getStringParameter(PARAMETER_INVOICE_PHONE_TOKEN, null);
		String invoice_cert_token = request.getStringParameter(PARAMETER_INVOICE_CERT_TOKEN, null);
		@SuppressWarnings("unused")
		String buyer_taxban = request.getStringParameter(PARAMETER_INVOICE_TAXBAN, null);
		String invoice_buyer_name = this.checkBuyerName(buyer_name);
		String invoice_buyer_phone = this.checkPhone(buyer_phone);
		String invoice_buyer_address = this.checkAddress(buyer_address);
		//Add by 何政東, 2018/07/23, check zip code parameter
		String invoice_buyer_zip_code = this.checkZipCode(buyer_zip_code);
		@SuppressWarnings("unused")
		String invoice_buyer_email = this.checkEmail(buyer_email);
		InvoiceInfo invoice = new InvoiceInfo();
		invoice.setMethod(invoiceMethod);
		if (invoiceMethod == InvoiceMethod.InvoiceDonate) {
			//add by dajun, 20180814, to refresh all npo list by post
			InvoiceAdapterCollector.getInstance().refreshNpoList();
			
			// Check NPO Love Code exist or not
			InvoiceDonate donate = null;
			if (invoice_npocode != null) {
				invoice_npocode = invoice_npocode.trim();
				donate = InvoiceAdapter.getInstance().getNpoByLoveCode(invoice_npocode);
			}
			// Check NPO BAN exist or not
			if (donate == null && invoice_npoban != null) {
				invoice_npoban = invoice_npoban.trim();
				donate = InvoiceAdapter.getInstance().getNpoByBan(invoice_npoban);
			}
			// If NPO Love Code and BAN both not exist, then error
			if (donate == null ) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_INVOICE_NPO_INVALID,  "Invoice NPO Ban/Code not valid", args);
				Log.error(this, method, "Check NPO Ban/Code Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_INVOICE_NPO_INVALID));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_INVOICE_NPO_INVALID);
				return result;
			}
			invoice.setNpoCode(donate.code());
			invoice.setNpoName(donate.name());
		} else 
		if (invoiceMethod == InvoiceMethod.InvoiceJCIC) {
			// Get JCIC Token Information from UserJcicToken
			UserJcicToken jcicToken = UserJcicTokenDao.getInstance().getByIdnBan(user.getUserIdentification());
			if (jcicToken == null || 
				(jcicToken.getStatus() != JcicTokenStatus.TokenRegistered &&
				 jcicToken.getStatus() != JcicTokenStatus.TokenSubsumed)) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_NO_JCIC_TOKEN,  "Buyer not register JCIC Token ", args);
				Log.error(this, method, "Check Buyer JCIC Token("+user.getUserIdentification()+") Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_NO_JCIC_TOKEN));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_NO_JCIC_TOKEN);
				return result;
			}
			invoice.setTokenNo(jcicToken.getCardNo());
			invoice.setName(jcicToken.getName());
			invoice.setEmail(jcicToken.getEmail());
			invoice.setPhone(jcicToken.getPhone());
			//add by 何政東, 2018/07/23, set zip code
			invoice.setZipCode(jcicToken.getZipCode());
			invoice.setAddress(jcicToken.getAddress());
		} else
		if (invoiceMethod == InvoiceMethod.InvoicePhone) {
			// Check Invoice Phone BarCode, if not input or invalid format, then error
			if (!InvoiceAdapter.getInstance().checkPhoneTokenFormat(invoice_phone_token)) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_PHONE_TOKEN_INVALID,  "Invoice Phone token not valid", args);
				Log.error(this, method, "Check Phone Token("+invoice_phone_token+") Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_PHONE_TOKEN_INVALID));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_PHONE_TOKEN_INVALID);
				return result;
			}
			Log.debug(this, method, "Phone Token("+invoice_phone_token+") check OK");
			invoice.setTokenNo(invoice_phone_token.trim());
		} else
		if (invoiceMethod == InvoiceMethod.InvoiceNPCert) {
			// Check NP Certificate Token No, if not input or invalid format, then error
			if (!InvoiceAdapter.getInstance().checkNPCertToken(invoice_cert_token)) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_CERT_TOKEN_INVALID,  "Invoice NP Certificate token not valid", args);
				Log.error(this, method, "Check NP Certificate Token("+invoice_cert_token+") Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_CERT_TOKEN_INVALID));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_CERT_TOKEN_INVALID);
				return result;
			}
			Log.debug(this, method, "NP Certificate Token("+invoice_cert_token+") check OK");
			invoice.setTokenNo(invoice_cert_token.trim());
		} else
		if (invoiceMethod == InvoiceMethod.InvoiceForPaper) {
			// Check Buyer Name, Phone, Address, if not input or invalid format, then error
			if (invoice_buyer_name == null) {
				// If Buyer Name not input, then error
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_NAME_INVALID,  "Invoice Buyer Name Required", args);
				Log.error(this, method, "Check Buyer Name Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_NAME_INVALID));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_NAME_INVALID);
				return result;
			}
			//Add by 何政東, 2018/07/23, check zip code 
			if (invoice_buyer_zip_code == null) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_ZIP_CODE_INVALID,  "Buyer zip code not valid", args);
				Log.error(this, method, "Check Buyer zip code("+invoice_buyer_zip_code+") Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_ZIP_CODE_INVALID));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_ZIP_CODE_INVALID);
				return result;
			}
			if (invoice_buyer_address == null) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_ADDRESS_INVALID,  "Buyer Address not valid", args);
				Log.error(this, method, "Check Buyer Address("+buyer_address+") Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_ADDRESS_INVALID));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_ADDRESS_INVALID);
				return result;
			}
			if (invoice_buyer_phone == null) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_PHONE_INVALID,  "Buyer Phone not valid", args);
				Log.error(this, method, "Check Buyer Address("+buyer_address+") Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_PHONE_INVALID));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_PHONE_INVALID);
				return result;
			}
			invoice.setName(invoice_buyer_name);
			//add by 何政東, 2018/07/23, set zip code
			invoice.setZipCode(invoice_buyer_zip_code);
			invoice.setAddress(invoice_buyer_address);
			invoice.setPhone(invoice_buyer_phone);
		} else
		/* 不適用統一編號發票證明
		if (invoiceMethod == InvoiceMethod.InvoiceForBan) {
			// Check Buyer Address and Tax Ban, if not input or invalid format, then error
			if (invoice_buyer_name == null) {
				// If Buyer Name not input, then error
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_NAME_INVALID,  "Invoice Buyer Name Required", args);
				Log.error(this, method, "Check Buyer Name Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_NAME_INVALID));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_NAME_INVALID);
				return result;
			}
			if (invoice_buyer_phone == null) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_PHONE_INVALID,  "Buyer Phone not valid", args);
				Log.error(this, method, "Check Buyer Address("+buyer_address+") Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_PHONE_INVALID));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_PHONE_INVALID);
				return result;
			}
			if (invoice_buyer_address == null) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_ADDRESS_INVALID,  "Buyer Address not valid", null);
				Log.error(this, method, "Check Buyer Address("+buyer_address+") Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_BUYER_ADDRESS_INVALID));
				return result;
			}
			String invoice_buyer_taxban = this.checkTaxBan(buyer_taxban);
			if (invoice_buyer_taxban == null) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_TAX_BAN_INVALID,  "Tax-Ban not valid", null);
				Log.error(this, method, "Check Tax-Ban("+buyer_taxban+") Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_TAX_BAN_INVALID));
				return result;
			}
			invoice.setTaxBan(invoice_buyer_taxban);
			invoice.setName(invoice_buyer_name);
			invoice.setAddress(invoice_buyer_address);
			invoice.setPhone(invoice_buyer_phone);
		} else
		*/
		{
			// Invalid Invoice Method
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_INVOICE_METHOD_INVALID, "Invalid Invoice Method("+code+")", args);
			Log.error(this, method, "Check Invoice Method Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_INVOICE_METHOD_INVALID));
			user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_INVOICE_METHOD_INVALID);
			return result;
		}
		user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, 0);
		// Check Pay Page URL
		String payPageUrl = OrderProcedure.getInstance().getPayPageURL();
		if (payPageUrl == null) {
			// Pay Page URL not define
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_INTERNAL_ERROR, "Pay Page URL not defined", null);
			Log.error(this, method, "Check Pay Page URL Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_INTERNAL_ERROR));
			user.setProcessStep(Order.ORDER_PROCESS_STEP_BILL_CHECK, UserErrorInfo.ERROR_CODE_PAYMENT_INTERNAL_ERROR);
			return result;
		}
		// Check Exist Order Information in Session
		Order order = this.getSessionOrder(request);
		if (order == null) {
			args[0] = Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_CREATE);
			// Session has no Order Information, Create a New Order
			order = OrderProcedure.getInstance()
							.createChargeOrder(user.getUserIdentification(), user.getDeviceType(), 
											   null, cardType, invoice);
			if (order == null) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_CREATE_ORDER_ERROR, "Create charge order error", args);
				Log.error(this, method, "Create Charge Order Error("+errorInfo.getErrorCode()
											+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_CREATE_ORDER_ERROR));
				user.setProcessStep(Order.ORDER_PROCESS_STEP_CREATE, UserErrorInfo.ERROR_CODE_PAYMENT_CREATE_ORDER_ERROR);
				return result;
			}
		}
		this.setSessionOrder(request, order);
		UserOrderControl orderControl = this.getSessionOrderControl(request, user);
		if (orderControl != null) {
			orderControl.setInvoice(order.getInvoice());
			OrderProcedure.getInstance().saveUserOrderControl(orderControl);
		}
		user.setProcessStep(Order.ORDER_PROCESS_STEP_CREATE, 0);
		return doPaymentWithOrder(request);
	}
	
	private EndUserServiceResult doPaymentWithOrder(RequestWrapper request) {
		String method = "doPaymentWithOrder";
		String service_name = "D.刷卡付款";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_CREDIT_PAYMENT);
		// Get/Check Login User
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_NOT_LOGIN, "User not login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NOT_LOGIN));
			return result;
		}
		user.setProcessStep(Order.ORDER_PROCESS_STEP_CREATE, 0);
		LoginSessionControl.updateLoginUser(request.getSession(false), user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		String[] args = { Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_CREATE) };
		// Get Order information and User Order Control from Session
		UserOrderControl orderControl = this.getSessionOrderControl(request, user);
		Order order = this.getSessionOrder(request);
		if (order == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR, "There is no order information", args);
			Log.error(this, method, "Check Session order information Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR));
			user.setProcessStep(Order.ORDER_PROCESS_STEP_CREATE, UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR);
			return result;
		}
		if (order.getCardType() != CreditCardType.InternationalCard &&
			order.getCardType() != CreditCardType.ChinaUnionCard) {
			// Invalid Card Type
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_CARD_TYPE_INVALID, "Card Type Invalid for Payment Order error", null);
			Log.error(this, method, "Payment order with card type Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_CARD_TYPE_INVALID));
			user.setProcessStep(Order.ORDER_PROCESS_STEP_CREATE, UserErrorInfo.ERROR_CODE_PAYMENT_CARD_TYPE_INVALID);
			return result;
		}
		result.setOrderNo(order.getOrderNo());
		// Check Pay Page URL
		String payPageUrl = OrderProcedure.getInstance().getPayPageURL();
		if (payPageUrl == null) {
			// Pay Page URL not define
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_INTERNAL_ERROR, "Pay Page URL not defined", null);
			Log.error(this, method, "Check Pay Page URL Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_INTERNAL_ERROR));
			user.setProcessStep(Order.ORDER_PROCESS_STEP_CREATE, UserErrorInfo.ERROR_CODE_PAYMENT_CARD_TYPE_INVALID);
			return result;
		}
		if (order.getOrderStatus() == OrderStatus.WaitAuthorize ||
			order.getOrderStatus() == OrderStatus.AuthorizeNotified) {
			// Modify by 何政東, 20181118, query authorize result from internal
			OrderProcedure.getInstance().queryAuthorizeResultFromInternal(order, false);
		}
		String cupAuthorizeHtml = null;
		if (order.getOrderStatus() == OrderStatus.NotAuthorize) {
			if (order.getCardType() == CreditCardType.ChinaUnionCard) {
				args[0] = Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_GET_CUP_PAY_HTML);
				// CUP Credit Card
				String authorizedResponseURL = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort() +
						request.getContextPath() + "/" + PAYMENT_CUP_NOTIFY_SERVICE_NAME;
				String merchantResponseURL = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort() +
						request.getContextPath() + "/" + PAYMENT_NOTIFY_SERVICE_NAME+"?"+PARAMETER_ORDER_NO+"="+order.getOrderNo();
				String clientIp = request.getUserIP();
				long time_begin = System.currentTimeMillis();
				String step = "8.取得銀聯刷卡頁面";
				PerformanceCollector.addFunctionBegin(service_name, step);
				// Modify by 何政東, 20181118, get CUP html from internal
				cupAuthorizeHtml = OrderProcedure.getInstance().getPaymentCUPHtmlFromInternal(order, clientIp, authorizedResponseURL, merchantResponseURL);
				PerformanceCollector.addFunctionPerformance(user.getUserIdentification(), service_name, step, step,
															time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
															user.getLoginSessionId(), user.getLoginUserIP(), "", "");
				if (cupAuthorizeHtml == null) {
					errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_GET_CUP_AUTHORIZE_HTML_ERROR, "Get CUP Authorize HTML error", args);
					Log.error(this, method, "Get CUP Authorize HTML Error("+errorInfo.getErrorCode()
												+"), Message="+errorInfo.getSubErrorMessage());
					result.setResultFlag(false);
					result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_GET_CUP_AUTHORIZE_HTML_ERROR));
					user.setProcessStep(Order.ORDER_PROCESS_STEP_GET_CUP_PAY_HTML, UserErrorInfo.ERROR_CODE_PAYMENT_GET_CUP_AUTHORIZE_HTML_ERROR);
					return result;
				}
				user.setProcessStep(Order.ORDER_PROCESS_STEP_GET_CUP_PAY_HTML, 0);
			} else {
				args[0] = Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_GET_TRANSACTION_KEY);
				// VISA/MasterCard/JCB
			    String urlString = request.getServerName()+":"+request.getServerPort()+request.getContextPath();
			    String serviceUrl = SystemProperties.getInstance().getStringProperty(PROPERTY_SERVICE_EXTERNAL_URL, urlString);
			    /*
			    try {
			    	URL url = new URL(urlString);
			    	serverName = url.getHost();
			    	serverPort = url.getPort();
			    } catch (Exception ex) {
			    	Log.error(this, method, "Convert URL String to URL exception:"+ex.getMessage());
			    }
			    */
			    Log.debug(this, method, "serviceUrl="+serviceUrl);
				String authorizedResponseURL = request.getScheme()+"://"+serviceUrl+"/" + PAYMENT_NOTIFY_SERVICE_NAME+"?"+PARAMETER_TRANSACTION_KEY+"=";
				Log.debug(this,method,"authorizedResponseURL="+authorizedResponseURL);
				long time_begin = System.currentTimeMillis();
				String step = "7.取得NCCC交易金鑰頁面";
				PerformanceCollector.addFunctionBegin(service_name, step);
				// Modify by 何政東, 20181118, get transaction key from internal
				String transactionKey = OrderProcedure.getInstance().getPaymentTransactionKeyFromInternal(order, authorizedResponseURL);
				PerformanceCollector.addFunctionPerformance(user.getUserIdentification(), service_name, step, step,
															time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
															user.getLoginSessionId(), user.getLoginUserIP(), "", "");
				if (transactionKey == null) {
					errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_GET_TRANSACTION_KEY_ERROR, "Get transaction key error", args);
					Log.error(this, method, "Get transaction key Error("+errorInfo.getErrorCode()
												+"), Message="+errorInfo.getSubErrorMessage());
					result.setResultFlag(false);
					result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_GET_TRANSACTION_KEY_ERROR));
					user.setProcessStep(Order.ORDER_PROCESS_STEP_GET_TRANSACTION_KEY, UserErrorInfo.ERROR_CODE_PAYMENT_GET_TRANSACTION_KEY_ERROR);
					return result;
				} 
				user.setProcessStep(Order.ORDER_PROCESS_STEP_GET_TRANSACTION_KEY, 0);
			}
		}
		args[0] = Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_PAYING);
		// Output Payment Redirect Information
		result.setOutputString("OrderNo="+order.getOrderNo());
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put(RESPONSE_DATA_USER, user);
		resultMap.put(RESPONSE_DATA_ORDER, order);
		if (order.getOrderStatus() != OrderStatus.NotAuthorize) {
			resultMap.put(RESPONSE_DATA_REDIRECT_URL, request.getContextPath() + "/" + PAYMENT_NOTIFY_SERVICE_NAME);
		} else {
			order.setOrderStatus(OrderStatus.WaitAuthorize);
			if (order.getCardType() == CreditCardType.ChinaUnionCard) {
				resultMap.put(RESPONSE_DATA_REDIRECT_HTML, cupAuthorizeHtml);
			} else {
				try {
					payPageUrl += "?KEY="+URLEncoder.encode(order.getTransactionKey(), "UTF-8");
				} catch (Exception ex) {
					Log.error(this, method, "Encode TransactionKey("+order.getTransactionKey()+") Exception:"+ex.getMessage());
				}
				// resultMap.put(RESPONSE_DATA_REDIRECT_URL, payPageUrl);
				resultMap.put(RESPONSE_DATA_REDIRECT_URL, payPageUrl);
			}
			if (!OrderDao.getInstance().update(order)) {
				Log.error(this, method, "Update Order Status to WaitAuthorize Error");
			}
		}
		result.setResultFlag(true);
		result.setOutputResult(resultMap);
		// Setup Order to Session
		this.setSessionOrder(request, order);
		// Update Oder information to User Order Control
		if (!orderControl.getLastOrderNo().equalsIgnoreCase(order.getOrderNo())) {
			orderControl.setLastOrderNo(order.getOrderNo());
			if (orderControl.getOrderYear() < order.getOrderYear()) {
				orderControl.setOrderYear(order.getOrderYear());
				orderControl.setOrderCount(0);
			}
			orderControl.setInvoice(order.getInvoice());
		}
		orderControl.setLastOrderStatus(order.getOrderStatus());
		// Update User OrderControl to Session & Database.
		this.setSessionOrderControl(request, orderControl);
		OrderProcedure.getInstance().saveUserOrderControl(orderControl);
		user.setProcessStep(Order.ORDER_PROCESS_STEP_PAYING, 0);
		return result;
	}

	private EndUserServiceResult doPaymentNotify(RequestWrapper request) {
		String method = "doPaymentNotify";
		String service_name = "E.付款完成通知";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result Catalog
		result.setCatalog(Transaction.CATALOG_CREDIT_PAYMENT);
		// Check Login User
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user != null) {
			LoginSessionControl.updateLoginUser(request.getSession(false), user);
			result.setUser(user);
			result.setCertType(user.getCertType());
			user.setProcessStep(Order.ORDER_PROCESS_STEP_PAYING, 0);
		}
		String[] args = { Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT) };
		String transactionKey = request.getStringParameter(PARAMETER_TRANSACTION_KEY, null);
		String orderNo = request.getStringParameter(PARAMETER_ORDER_NO, null);
		result.setInputString("TransactionKey="+transactionKey+";OrderNo="+orderNo);
		if (transactionKey != null && transactionKey.trim().length() < 1) transactionKey = null;
		if (orderNo != null && orderNo.trim().length() < 1) orderNo = null;
		// Query Result By TransactionKey
		if (transactionKey != null) {
			// Query Result By TransactionKey
			Order transactionOrder = OrderDao.getInstance().getByTranactionKey(transactionKey);
			if (transactionOrder != null) {
				// Modify by 何政東, 20181118, query authorize result from internal
				boolean resultFlag = OrderProcedure.getInstance().queryAuthorizeResultFromInternal(transactionOrder, true);
				Log.debug(this, method, "QueryAuthorizeResult for Order("+transactionOrder.getOrderNo()+"), TransactionKey("+transactionOrder.getTransactionKey()+"), Result="+resultFlag+", OrderStatus="+transactionOrder.getOrderStatus().desc());
			} else {
				Log.error(this, method, "Order not found for TransactinKey("+transactionKey+")");
			}
		}
		if (orderNo != null) {
			Order transactionOrder = OrderDao.getInstance().getByKey(orderNo);
			if (transactionOrder != null) {
				// Modify by 何政東, 20190107, query authorize result from internal
				boolean resultFlag = OrderProcedure.getInstance().queryAuthorizeResultFromInternal(transactionOrder, false);
				Log.debug(this, method, "QueryAuthorizeResult for Order("+transactionOrder.getOrderNo()+"), Result="+resultFlag+", OrderStatus="+transactionOrder.getOrderStatus().desc());
			} else {
				Log.error(this, method, "Order not found for Order No("+orderNo+")");
			}
		}
		// Get Order information and User Order Control from Session
		UserOrderControl orderControl = this.getSessionOrderControl(request, user);
		Order order = this.getSessionOrder(request);
		if (order == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR, "Order not found in Session", args);
			Log.error(this, method, "Get Order Information Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR));
			if (user != null) user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT , UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR);
			return result;
		}
		/*
		if (transactionKey != null && !transactionKey.equalsIgnoreCase(order.getTransactionKey())) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR, "TransactionKey("+transactionKey
					+") not match Order TransactionKey("+order.getTransactionKey()+")", null);
			Log.error(this, method, "Check Order Information Error("+errorInfo.getErrorCode()
						+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR));
			if (user != null) user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT , UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR);
			return result;
		}
		*/
		/*
		if (orderNo != null && !orderNo.equals(order.getOrderNo())) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR, "OrderNo("+orderNo
					+") not match Order No("+order.getOrderNo()+")", null);
			Log.error(this, method, "Check Order Information Error("+errorInfo.getErrorCode()
						+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR));
			if (user != null) user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT , UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR);
			return result;
		}
		*/
		result.setOutputString("OrderNo="+order.getOrderNo());
		result.setOrderNo(order.getOrderNo());
		// Query Order Authorized Result
		long time_begin = System.currentTimeMillis();
		String step = "9.取得刷卡付款結果";
		PerformanceCollector.addFunctionBegin(service_name, step);
		// Modify by 何政東, 20190107, query authorize result from internal
		OrderProcedure.getInstance().queryAuthorizeResultFromInternal(order, false);
		// Get/Check Login User
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_NOT_LOGIN, "User not login", args);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			PerformanceCollector.addFunctionPerformance(order.getIdnBan(), service_name, step, step,
														time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
														request.getSession().getId(), request.getUserIP(), "", "");
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NOT_LOGIN));
			return result;
		}
		user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT , 0);
		// Set Order to Session
		this.setSessionOrder(request, order);
		OrderStatus status = order.getOrderStatus(); 
		if (status == OrderStatus.NotAuthorize) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_AHTHORIZE_NOT_COMPLETED, "Order authorize not complete", args);
			Log.error(this, method, "Order authorize not complete Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			PerformanceCollector.addFunctionPerformance(user.getUserIdentification(), service_name, step, step,
															time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
															user.getLoginSessionId(), user.getLoginUserIP(), "", "");
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_AHTHORIZE_NOT_COMPLETED));
			result.setResultFlag(true);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(RESPONSE_DATA_NEXT_SERVICE, PAYMENT_WITH_ORDER_SERVICE_NAME);
			result.setOutputResult(resultMap);
			result.setOutputString("OrderNo="+order.getOrderNo()+", Not Authorized");
			user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT , UserErrorInfo.ERROR_CODE_PAYMENT_AHTHORIZE_NOT_COMPLETED);
			return result;
		}
		if (status.code() <= OrderStatus.AuthorizeNotified.code()) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_WAITING_AUTHORIZE_RESULT, "Authorize", args);
			Log.error(this, method, "Waiting order authorize result("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_WAITING_AUTHORIZE_RESULT));
			PerformanceCollector.addFunctionPerformance(user.getUserIdentification(), service_name, step, step,
															time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
															user.getLoginSessionId(), user.getLoginUserIP(), "", "");
			result.setResultFlag(true);
			Map<String, Object> resultMap = new HashMap<>();
			// resultMap.put(RESPONSE_DATA_NEXT_SERVICE, PAYMENT_NOTIFY_SERVICE_NAME+"?KEY="+order.getTransactionKey());
			resultMap.put(RESPONSE_DATA_NEXT_SERVICE, PAYMENT_NOTIFY_SERVICE_NAME);
			result.setOutputResult(resultMap);
			result.setOutputString("OrderNo="+order.getOrderNo()+", Waiting Authorize");
			user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT , UserErrorInfo.ERROR_CODE_PAYMENT_WAITING_AUTHORIZE_RESULT);
			return result;
		}
		if (status == OrderStatus.AuthorizeFailed) {
			Log.debug(this, method, "Authorize Response:"+order.getAuthorizeResp()+", Card-Type:"+order.getCardType());
			String[] errorArgs = { OrderProcedure.getInstance().getAuthorizeResponeMessage(order.getAuthorizeResp(), order.getCardType()) };
			Log.debug(this, method, "Authorize Failed Reason:"+args[0]);
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_AUTHORIZED_FAILED, "Order Authorized Failed", errorArgs);
			Log.error(this, method, "Order Authorized Failed("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			PerformanceCollector.addFunctionPerformance(user.getUserIdentification(), service_name, step, step,
														time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
														user.getLoginSessionId(), user.getLoginUserIP(), "", "");
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			result.setOutputString("OrderNo="+order.getOrderNo()+", Authorize Failed, ResponseCode="+order.getAuthorizeResp());
			user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT , UserErrorInfo.ERROR_CODE_PAYMENT_AUTHORIZED_FAILED);
			return result;
		}
		if (status == OrderStatus.RefundWaitApprove ||		// 申請退款（或取消授權）等待覆核
			status == OrderStatus.Cancelled ||				// 已取消授權
			status == OrderStatus.RefundApproved ||			// 退款已覆核，等待發送退款
			status == OrderStatus.Refunding ||				// 退款中，等待退款回覆
			status == OrderStatus.RefundFailed ||			// 退款失敗
			status == OrderStatus.Refund) {					// 已退款
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_ORDER_ALREADY_REFUND, "Order already Cancel or Refund", args);
			Log.error(this, method, "Order Status("+status.code()+") Cancel or Refund("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			PerformanceCollector.addFunctionPerformance(user.getUserIdentification(), service_name, step, step,
														time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
														user.getLoginSessionId(), user.getLoginUserIP(), "", "");
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_ORDER_ALREADY_REFUND));
			result.setOutputString("OrderNo="+order.getOrderNo()+", OrderStatus="+status.code()+", State Inconsistent");
			user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT , UserErrorInfo.ERROR_CODE_PAYMENT_ORDER_ALREADY_REFUND);
			return result;
		}
		PerformanceCollector.addFunctionPerformance(user.getUserIdentification(), service_name, step, step,
														time_begin, System.currentTimeMillis(), 0, 
														user.getLoginSessionId(), user.getLoginUserIP(), "", "");
		args[0] = Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_PAYMENTED);
		user.setProcessStep(Order.ORDER_PROCESS_STEP_PAYMENTED , 0);
		result.setOutputString("OrderNo="+order.getOrderNo()+", Authorize Succeed");
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<>();
		// resultMap.put(RESPONSE_DATA_REDIRECT_URL, request.getContextPath() + "/" + CREDIT_QUERY_REPORT_GENERATE_SERVICE_NAME);
		resultMap.put(RESPONSE_DATA_NEXT_SERVICE, CREDIT_QUERY_REPORT_GENERATE_SERVICE_NAME);
		result.setOutputResult(resultMap);
		result.setErrorMessage("quickcode.info.payment_result_succeed", null);
		// Update Oder information to User Order Control
		if (!orderControl.getLastOrderNo().equalsIgnoreCase(order.getOrderNo())) {
			orderControl.setLastOrderNo(order.getOrderNo());
			if (orderControl.getOrderYear() < order.getOrderYear()) {
				orderControl.setOrderYear(order.getOrderYear());
				orderControl.setOrderCount(0);
			}
		}
		orderControl.setLastOrderStatus(order.getOrderStatus());
		// Update User OrderControl to Session & Database.
		this.setSessionOrderControl(request, orderControl);
		OrderProcedure.getInstance().saveUserOrderControl(orderControl);
		return result;
	}

	private EndUserServiceResult doPaymentCUPNotify(RequestWrapper request) {
		String method = "doPaymentCUPNotify";
		String service_name = "F.銀聯付款完成通知";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result Catalog
		result.setCatalog(Transaction.CATALOG_CREDIT_PAYMENT);
		// Check Login User
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user != null) {
			LoginSessionControl.updateLoginUser(request.getSession(false), user);
			result.setUser(user);
			result.setCertType(user.getCertType());
			user.setProcessStep(Order.ORDER_PROCESS_STEP_PAYING, 0);
		}
		String[] args = { Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT) };
		// Get CUP Notify Parameters
		String transType = request.getStringParameter(CUP_PARAMETER_TRANS_TYPE, null);
		String responseCode = request.getStringParameter(CUP_PARAMETER_RESPONSE_CODE, null);
		String responseMsg = request.getStringParameter(CUP_PARAMETER_RESPONSE_MESSAGE, null);
		String merchantId = request.getStringParameter(CUP_PARAMETER_MERCHANT_ID, null);
		String merchantName = request.getStringParameter(CUP_PARAMETER_MERCHANT_NAME, null);
		String orderNo = request.getStringParameter(CUP_PARAMETER_ORDER_NO, null);
		String orderAmountStr = request.getStringParameter(CUP_PARAMETER_ORDER_AMOUNT, null);
		String orderCurrency = request.getStringParameter(CUP_PARAMETER_ORDER_CURRENCY, null);
		String responseTimeStr = request.getStringParameter(CUP_PARAMETER_RESPONSE_TIME, null);
		String reserved = request.getStringParameter(CUP_PARAMETER_RESERVED, null);
		String cardPan = request.getStringParameter(CUP_PARAMETER_PAN, null);
		// Virtual Check
		result.setInputString("transType="+transType+";responseCode="+responseCode+";responseMsg="+responseMsg+";merchantId="+merchantId
							+ "merchantName="+merchantName+";orderAmount="+orderAmountStr+";orderCurrenty="+orderCurrency
							+ "responseTime="+responseTimeStr+";reserved="+reserved+";pan="+cardPan);
		Order order = OrderDao.getInstance().getByKey(orderNo);
		if (order == null) {
			Log.error(this, method, "Order not found for Order No="+orderNo);
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR, "Order for Order NO("+orderNo
					+") not found", null);
			Log.error(this, method, "Check Order Information Error("+errorInfo.getErrorCode()
						+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR));
			if (user != null) user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT, UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR);
			return result;
		}
		String userIdn = order.getIdnBan();
		String sessionId = request.getSession().getId();
		String userIp = request.getUserIP();
		if (user != null) {
			userIdn = user.getUserIdentification();
			sessionId = user.getLoginSessionId();
			userIp = user.getLoginUserIP();
		}
		result.setOutputString("OrderNo="+order.getOrderNo());
		result.setOrderNo(order.getOrderNo());
		// Query Order Authorized Result
		long time_begin = System.currentTimeMillis();
		String step = "10.取得銀聯刷卡付款結果";
		PerformanceCollector.addFunctionBegin(service_name, step);
		// Modify by 何政東, 20181118, query authorize result from internal
		OrderProcedure.getInstance().queryAuthorizeResultFromInternal(order, false);
		OrderStatus status = order.getOrderStatus(); 
		if (status == OrderStatus.NotAuthorize) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_AHTHORIZE_NOT_COMPLETED, "Order authorize not complete", args);
			Log.error(this, method, "Order authorize not complete Error("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			PerformanceCollector.addFunctionPerformance(userIdn, service_name, step, step,
														time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
														sessionId, userIp, "", "");
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_AHTHORIZE_NOT_COMPLETED));
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR));
			if (user != null) user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT, UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR);
			return result;
		}
		if (status.code() <= OrderStatus.AuthorizeNotified.code()) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_WAITING_AUTHORIZE_RESULT, "Authorize", null);
			Log.error(this, method, "Waiting order authorize result("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			PerformanceCollector.addFunctionPerformance(userIdn, service_name, step, step,
														time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
														sessionId, userIp, "", "");
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_WAITING_AUTHORIZE_RESULT));
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR));
			if (user != null) user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT, UserErrorInfo.ERROR_CODE_PAYMENT_NO_ORDER_ERROR);
			return result;
		}
		if (status == OrderStatus.AuthorizeFailed) {
			String[] errorArgs = { order.getAuthorizeResp() };
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_AUTHORIZED_FAILED, "Order Authorized Failed", errorArgs);
			Log.error(this, method, "Order Authorized Failed("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			PerformanceCollector.addFunctionPerformance(userIdn, service_name, step, step,
														time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
														sessionId, userIp, "", "");
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_AUTHORIZED_FAILED));
			if (user != null) user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT, UserErrorInfo.ERROR_CODE_PAYMENT_AUTHORIZED_FAILED);
			return result;
		}
		if (status == OrderStatus.RefundWaitApprove ||		// 申請退款（或取消授權）等待覆核
			status == OrderStatus.Cancelled ||				// 已取消授權
			status == OrderStatus.RefundApproved ||			// 退款已覆核，等待發送退款
			status == OrderStatus.Refunding ||				// 退款中，等待退款回覆
			status == OrderStatus.RefundFailed ||			// 退款失敗
			status == OrderStatus.Refund) {					// 已退款
			errorInfo.set(UserErrorInfo.ERROR_CODE_PAYMENT_ORDER_ALREADY_REFUND, "Order already Cancel or Refund", args);
			Log.error(this, method, "Order Status("+status.code()+") Cancel or Refund("+errorInfo.getErrorCode()
										+"), Message="+errorInfo.getSubErrorMessage());
			PerformanceCollector.addFunctionPerformance(userIdn, service_name, step, step,
														time_begin, System.currentTimeMillis(), errorInfo.getErrorCode(), 
														sessionId, userIp, "", "");
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_PAYMENT_ORDER_ALREADY_REFUND));
			if (user != null) user.setProcessStep(Order.ORDER_PROCESS_STEP_QUERY_PAY_RESULT, UserErrorInfo.ERROR_CODE_PAYMENT_ORDER_ALREADY_REFUND);
			return result;
		}
		PerformanceCollector.addFunctionPerformance(userIdn, service_name, step, step,
													time_begin, System.currentTimeMillis(), 0, 
													sessionId, userIp, "", "");
		args[0] = Order.getNameOfOrderStep(Order.ORDER_PROCESS_STEP_PAYMENTED);
		if (user != null) user.setProcessStep(Order.ORDER_PROCESS_STEP_PAYMENTED , 0);
		// Update Oder information to User Order Control
		UserOrderControl orderControl = this.getIdnOrderControl(order.getIdnBan());
		if (!orderControl.getLastOrderNo().equalsIgnoreCase(order.getOrderNo())) {
			orderControl.setLastOrderNo(order.getOrderNo());
			if (orderControl.getOrderYear() < order.getOrderYear()) {
				orderControl.setOrderYear(order.getOrderYear());
				orderControl.setOrderCount(0);
			}
		}
		orderControl.setLastOrderStatus(order.getOrderStatus());
		OrderProcedure.getInstance().saveUserOrderControl(orderControl);
		// Setup Result
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<>();
		result.setOutputResult(resultMap);
		return result;
	}
	
	/*
	 * 
	 */
	private EndUserServiceResult doQueryHistoryOrders(RequestWrapper request) {
		String method = "doQueryHistoryOrders";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_CREDIT_PAYMENT);
		// Get/Check Login User
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_QUERY_HISTORY_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			// result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(request.getSession(false), user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		Map<String, Object> conditions = new HashMap<>();
		conditions.put(OrderDao.QUERY_CONDITION_USER_IDN, user.getUserIdentification());
		int end_year = new MyDate().getYear();
		// int month = new MyDate().getMonth() + 1;
		// if (month <= 2) year--;
		int begin_year = end_year - 1;
		String beginDateString = String.format("%04d0000", begin_year);
		conditions.put(OrderDao.QUERY_CONDITION_ORDER_BEGIN_TIME, MyDate.parseDateString(beginDateString));
		conditions.put(OrderDao.QUERY_CONDITION_ORDER_END_TIME, new MyDate());
		QueryResult<Order> queryResult = OrderDao.getInstance().query(conditions, 0, 0);
		if (queryResult == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_QUERY_HISTORY_DB_ERROR, "Query History Order db error", null);
			Log.error(this, method, "Get History Record Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			user.setReportProcessErrorCode(errorInfo.getErrorCode());
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			result.setErrorMessage("quickcode.error.credit_query_order_failed");
			return result;
		}
		Order[] orders = queryResult.getResult();
		/*
		if (orders == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_QUERY_HISTORY_DB_ERROR, "Query History Order db error", null);
			Log.error(this, method, "Get History Record Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			user.setReportProcessErrorCode(errorInfo.getErrorCode());
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			result.setErrorMessage("quickcode.error.credit_query_order_failed");
			return result;
		}
		*/
		List<Order> orderList = new ArrayList<>();
		if (orders != null) {
			for (int i = 0; i < orders.length; i++) {
				Order order = orders[i];
				if (order.getOrderStatus().code() <= OrderStatus.AuthorizeFailed.code() &&
					order.getOrderStatus() != OrderStatus.Free) continue;
				orderList.add(order);
				// if (orderList.size() >= MAX_ORDER_QUERY_COUNT) break;
			}
		}
		Order[] resultOrders = new Order[orderList.size()];
		orderList.toArray(resultOrders);
		user.setReportProcessErrorCode(0);
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_ORDERS, resultOrders);
		resultMap.put(RESPONSE_DATA_BEGIN_YEAR, begin_year-1911);
		resultMap.put(RESPONSE_DATA_END_YEAR, end_year-1911);
		if (resultOrders.length > 0) {
			// result.setErrorMessage("quickcode.info.CreditQueryHistorySucceed");
		} else {
			result.setErrorMessage("quickcode.error.credit_query_order_not_found");
		}
		result.setOutputResult(resultMap);
		return result;
	}
	
	/*
	 * 
	 */
	private EndUserServiceResult doQueryOrderInvoice(RequestWrapper request) {
		String method = "doQueryOrderInvoice";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_CREDIT_PAYMENT);
		// Get/Check Login User
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_QUERY_HISTORY_INVOICE_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(request.getSession(false), user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		String order_no = request.getStringParameter(PARAMETER_ORDER_NO, null);
		if (order_no == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_QUERY_HISTORY_NO_ORDER_ERROR, "Query History No Order No error", null);
			Log.error(this, method, "No Order parameter Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			user.setReportProcessErrorCode(errorInfo.getErrorCode());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.credit_query_no_order_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		Order order = OrderDao.getInstance().getByKey(order_no);
		if (order == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_QUERY_HISTORY_NO_ORDER_ERROR, "Query History No Order error", null);
			Log.error(this, method, "Get Order Inforamtion Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			user.setReportProcessErrorCode(errorInfo.getErrorCode());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.credit_query_no_order_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (!order.getIdnBan().equals(user.getUserIdentification())) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_QUERY_HISTORY_NO_ORDER_ERROR, 
						"Order("+order.getOrderNo()+") IDN("+order.getIdnBan()+") and Login User("+user.getUserIdentification()+") not consistent", null);
			Log.error(this, method, "Order IDN not consistent Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			user.setReportProcessErrorCode(errorInfo.getErrorCode());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.credit_query_no_order_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (order.getInvoice() == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_QUERY_HISTORY_ORDER_HAS_NO_INVOICE, "Order has no Invoice", null);
			Log.error(this, method, "Order has no invoice Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			user.setReportProcessErrorCode(errorInfo.getErrorCode());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.info.order_no_invoice");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (order.getInvoice().getMethod() == InvoiceMethod.InvoiceDonate) {
			//add by dajun, 20180814, to refresh all npo list by post
			InvoiceAdapterCollector.getInstance().refreshNpoList();
			
			InvoiceDonate donate = InvoiceAdapter.getInstance().getNpoByLoveCode(order.getInvoice().getNpoCode());
			order.getInvoice().setNpoName(donate.name());
		}
		if (order.getInvoice().getMethod() == InvoiceMethod.InvoiceJCIC &&
			order.getInvoice().getInvoiceNo() != null &&
			order.getInvoice().getInvoiceCreateDate() != null) {
			WinnerInvoice winner = WinnerInvoiceDao.getInstance().getByInvoice(order.getInvoice().getInvoiceCreateDate().getDateDisplay(),
													    order.getInvoice().getInvoiceNo());
			if (winner != null) {
				String invoiceMonth = winner.getInvoiceMonth();
				int year = Integer.parseInt(winner.getInvoiceYear()) + 1911;
				int month = Integer.parseInt(invoiceMonth.substring(invoiceMonth.length()-2)) + 2;
				if (month > 12) { month -= 12; year++; }
				MyDate noticeDate = MyDate.parseDateString(String.format("%1$04d%2$02d%3$02d", year, month, 5));
				order.getInvoice().setInvoiceWinnerNoticeDate(noticeDate);
			}
		}
		user.setReportProcessErrorCode(0);
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_ORDER, order);
		result.setOutputResult(resultMap);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.quickretrieval.jcic.server.action.EndUserBaseAction#doService(java.lang.String, com.quickretrieval.server.control.RequestWrapper, com.quickretrieval.server.control.ResponseWrapper)
	 */
	@Override
	protected EndUserServiceResult doService(String serviceName, RequestWrapper request, ResponseWrapper response) {
		if (serviceName.equalsIgnoreCase(PAYMENT_WITH_INPUT_BILL_SERVICE_NAME)) {
			return doPaymentWithInputBill(request);
		}
		if (serviceName.equalsIgnoreCase(PAYMENT_WITH_ORDER_SERVICE_NAME)) {
			return doPaymentWithOrder(request);
		}
		if (serviceName.equalsIgnoreCase(PAYMENT_NOTIFY_SERVICE_NAME)) {
			return doPaymentNotify(request);
		}
		if (serviceName.equalsIgnoreCase(PAYMENT_CUP_NOTIFY_SERVICE_NAME)) {
			return doPaymentCUPNotify(request);
		}
		if (serviceName.equalsIgnoreCase(PAYMENT_QUERY_ORDER_HISTORY_SERVICE_NAME)) {
			return doQueryHistoryOrders(request);
		}
		if (serviceName.equalsIgnoreCase(PAYMENT_QUEYR_ORDER_INVOICE_SERVICE_NAME)) {
			return doQueryOrderInvoice(request);
		}
		return null;
	}

}
