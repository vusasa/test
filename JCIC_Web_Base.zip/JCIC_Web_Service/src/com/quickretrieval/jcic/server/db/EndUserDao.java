/**
 * 
 */
package com.quickretrieval.jcic.server.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.quickretrieval.common.utils.MyDate;
import com.quickretrieval.server.log.Log;
import com.quickretrieval.server.dao.DatabaseUtil;

/**
 * @author BruceHuang
 * This Class implement the Persistence access for Age of End-User
 */
public class EndUserDao  {
	
	private static final String TABLE_NAME = "JCIC.VA404T"; // Original Table Name: ?
	
	
	private static final String sql_GetAageByIDN = 
			"select BIRTH_DATE "+
				"from "+TABLE_NAME+" where IDN = ? ";
	
	private static EndUserDao defaultInstance = null;
		
	public static EndUserDao getInstance() {
		if (defaultInstance == null) {
			defaultInstance = new EndUserDao();
		}
		return defaultInstance;
	}
	

	public MyDate getAageByIDN(String idn) {
		// Modify by 何政東, 20180928, get VAconnections 
		Connection dbcon = DatabaseUtil.getInstance().getVAConnection();
		if (dbcon == null) return null;
		PreparedStatement preStmt = null;
		ResultSet result = null;
		MyDate birthDate = null;
		try  {
			preStmt = dbcon.prepareStatement(sql_GetAageByIDN);
			preStmt.setString(1, idn);
			Log.debug(this, "getAageByIDN", "SQL='"+sql_GetAageByIDN+"'");
			result = preStmt.executeQuery();
			if (result.next()) {
				String value = result.getString(1);
				if (value != null) value = value.trim();
				if (value != null && value.length() >= 6) {
					if (value.length() > 7) value = value.substring(value.length()-7);
					if (value.length() == 6 ) value = "0"+value;
					birthDate = MyDate.parseMinguoDateString(value);
				}
			}
		} catch (SQLException ex) {
			Log.error(this, "getAageByIDN", ex);
		} 
		if (result != null) 
			try { result.close(); } catch (Exception e) {}
		if (preStmt != null) 
			try { preStmt.close(); } catch (Exception e) {}
		// Modify by 何政東, 20180928, close VAconnections 
		DatabaseUtil.getInstance().closeVAConnection(dbcon);
		return birthDate;
	}		
		
}
