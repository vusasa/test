package com.quickretrieval.server.log;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.quickretrieval.common.utils.MyDate;
import com.quickretrieval.server.properties.SystemProperties;

public class Log  {
		
	private static final Class<?> LOG_TAG = Log.class;
	
	private static final String		PROPERTY_LOG4J_RESOURCE = "Log.Log4j.path";
	private static final String		PROPERTY_LOG4J_ROOT_PATH = "log4j.appender.ROOT.File";
	private static final int		QUEUE_SIZE = 4096;
	
	public static final int	LOG_LEVEL_ALL = LocalLog.LOG_LEVEL_ALL;
	public static final int	LOG_LEVEL_DEBUG = LocalLog.LOG_LEVEL_DEBUG;
	public static final int	LOG_LEVEL_INFO = LocalLog.LOG_LEVEL_INFO;
	public static final int	LOG_LEVEL_WARN = LocalLog.LOG_LEVEL_WARN;
	public static final int	LOG_LEVEL_ERROR = LocalLog.LOG_LEVEL_ERROR;
	public static final int	LOG_LEVEL_FATAL = LocalLog.LOG_LEVEL_FATAL;
	private static final boolean			Log4jEnable = true;
	
	private static boolean			Initialized = false;
	private static boolean 			Log4jInitialed = false;
	protected static int			runningLogLevel = LOG_LEVEL_ALL;	
	protected static String			contextApplication = "Default";
	// Remove by 何政東, 20181113, unsupported log server
	// private static boolean			tcpMode = false;
	private static BlockingQueue<List<String>> logMessageQueue = null;
	// Remove by 何政東, 20181113, unsupported log server
	// private static LogClientThread logClientThread = null;
	// private static LogServerClientTCP  logClientTCPThread = null;
	
	private static Properties getLog4JProperties(String filePath) {
		InputStream input  = null;
		try {
			input = new FileInputStream(filePath);
			Properties properties = new Properties();
			properties.load(input);
			try { input.close(); } catch (Exception e) {};
			return properties;
		} catch (Exception ex) {
			System.out.println("Load Log4J Properties() exception:"+ex.getMessage());
			ex.printStackTrace(System.out);
			if (input != null) try { input.close(); } catch (Exception e) {}
			return null;
		}
	}
	
	private static void initialLog4J() {
		// Initial Log4J for same used Library
		if (!Log4jInitialed  && SystemProperties.isInitialized()) {
			String log4Config = SystemProperties.getInstance().getApplicationPath(PROPERTY_LOG4J_RESOURCE);
			if (log4Config == null) {
				System.out.println("Log: initialLog4J: log4jconfig not found for System Property("+PROPERTY_LOG4J_RESOURCE+")");
				return;
			}
			Properties log4jProperties = getLog4JProperties(log4Config);
			if (log4jProperties == null) {
				Log4jInitialed = true;
				return;
			}
			String log4jFilePath = SystemProperties.getInstance().getRealLogBasePath()+ "Log4j.log";
			log4jProperties.setProperty(PROPERTY_LOG4J_ROOT_PATH, log4jFilePath);
			System.out.println("Log: initialLog4j: log4jconfig="+log4Config+", ROOT_FILE="+log4jFilePath);			
			// System.getProperties().setProperty("log4j.configuration", log4Config);
			PropertyConfigurator.configure(log4jProperties);
			Log4jInitialed = true;
		}
	}
		
	@SuppressWarnings("unused")
	private static void outLog4jMessage(int logLevel, Logger logger, String message) {
		switch (logLevel) {
			case LOG_LEVEL_DEBUG:
				logger.debug(message);
				break;
			case LOG_LEVEL_INFO:
				logger.info(message);
				break;
			case LOG_LEVEL_WARN:
				logger.warn(message);
				break;
			case LOG_LEVEL_ERROR:
				logger.error(message);
				break;
			case LOG_LEVEL_FATAL:
				logger.fatal(message);
				break;
			default:
				return;
		}
	}
	
	@SuppressWarnings("unused")
	private static synchronized void outLog4j(int logLevel, String className, List<String> messages) {
		if (!Log4jEnable || !Log4jInitialed || logLevel < runningLogLevel || className == null || messages == null) return;
		Logger logger = Logger.getLogger(className);
		for (int i = 0; i < messages.size(); i++) {
			String message = messages.get(i);
			outLog4jMessage(logLevel, logger, message);
		}
	}

	private static void writeLogToServer(List<String> logMessages) {
		if (Initialized && logMessageQueue != null) {
			try {
				if (!logMessageQueue.offer(logMessages)) {
					LocalLog.warning(LOG_TAG, "writeLogToServer", "Put message to queue failed(FULL)");
				}
			} catch (Exception ex) {
				LocalLog.warning(LOG_TAG, "writeLogToServer", "Put message to queue exception:"+ex.toString());
				LocalLog.warning(LOG_TAG, "writeLogToSerfver", ex);
			}
		}
	}
	
	protected static void initialize() {
		if (!Initialized && SystemProperties.isInitialized()) {
			String logMethod = "initialize";
			try {
				initialLog4J();
			} catch (Exception e) {
				e.printStackTrace(System.out);
			}
			LocalLog.initial(contextApplication);
			runningLogLevel = LocalLog.getLogLevel();
			if (logMessageQueue == null) {
				try {
					logMessageQueue = new ArrayBlockingQueue<List<String>>(QUEUE_SIZE, true);
				} catch (Exception ex) {
					LocalLog.error(LOG_TAG, logMethod, "Create Message Queue exception:"+ex.toString());
					LocalLog.error(LOG_TAG, logMethod, ex);
					return;
				}
			}
			// Remove by 何政東, 20181113, unsupported log server
			// if (logClientThread == null) {
			// try {
			// if (tcpMode) {
			// logClientThread = new LogServerClientTCP(contextApplication,
			// logMessageQueue);
			// } else {
			// logClientThread = new LogServerClientUDP(contextApplication,
			// logMessageQueue);
			// }
			// logClientThread.start();
			// } catch (Exception ex) {
			// LocalLog.error(LOG_TAG, logMethod, "Create Log Client Thread
			// exception:"+ex.toString());
			// LocalLog.error(LOG_TAG, logMethod, ex);
			// return;
			// }
			// }
			Initialized = true;
			LocalLog.debug(LOG_TAG, "initialize", "Initialized level="+runningLogLevel+", contextApplication="+contextApplication);
		}
	}
	
	protected static void out(int logLevel, String className, String title, String message) {
		if (!SystemProperties.isInitialized()) {
			SystemoutLog.out(logLevel, className, title, message);
			return;
		}
		initialize();
		if (logLevel < runningLogLevel) return;
		List<String> logMessages = LocalLog.getLogMessages(logLevel, className, title, message);
		MyDate now = new MyDate();
		LocalLog.out(now, logMessages);
		outLog4j(logLevel, className, logMessages);
		writeLogToServer(logMessages);
	}
	
	protected static void out(int logLevel, String className, String title, Throwable ex) {
		if (!SystemProperties.isInitialized()) {
			SystemoutLog.out(logLevel, className, title, ex);
			return;
		}
		initialize();
		if (logLevel < runningLogLevel) return;
		List<String> logMessages = LocalLog.getLogMessages(logLevel, className, title, ex);
		MyDate now = new MyDate();
		LocalLog.out(now, logMessages);
		outLog4j(logLevel, className, logMessages);
		writeLogToServer(logMessages);
	}
	
	protected static void out(int logLevel, String className, String title, byte[] bytes) {
		if (!SystemProperties.isInitialized()) {
			SystemoutLog.out(logLevel, className, title, bytes);
			return;
		}
		initialize();
		if (logLevel < runningLogLevel) return;
		List<String> logMessages = LocalLog.getLogMessages(logLevel, className, title, bytes);
		MyDate now = new MyDate();
		LocalLog.out(now, logMessages);
		outLog4j(logLevel, className, logMessages);
		writeLogToServer(logMessages);
	}
	
	public static void Initial(String application) {
		// LocalLog.debug(LOG_TAG, logMethod, "invoked");
		contextApplication = application;
		initialize();
	}
	
	public static void shutdown() {
		// Remove by 何政東, 20181113, unsupported log server
		// if (logClientThread != null) logClientThread.shutdown();
		if (logMessageQueue != null) logMessageQueue.clear();
		logMessageQueue = null;
		LocalLog.shutdown();
	}
	
	public static int[] getLogLevels() {
		return LocalLog.getLogLevels();
	}
	
	public static String[] getLogLevelNames() {
		return LocalLog.getLogLevelNames();
	}
	
	public static int	getLogLevelByName(String levelName) {
		return LocalLog.getLogLevelByName(levelName);
	}

	public static void debug(Object tag, String title, byte[] data) {
		Log.out(LOG_LEVEL_DEBUG, tag.getClass().getName(), title, data);
	}
	
	public static void debug(Class<?> objClass, String title, byte[] data) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_DEBUG, className, title, data);
	}
	
	public static void info(Object tag, String title, byte[] data) {
		Log.out(LOG_LEVEL_INFO, tag.getClass().getName(), title, data);
	}
	
	public static void info(Class<?> objClass, String title, byte[] data) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_INFO, className, title, data);
	}
	
	public static void warning(Object tag, String title, byte[] data) {
		Log.out(LOG_LEVEL_WARN, tag.getClass().getName(), title, data);
	}
	
	public static void warning(Class<?> objClass, String title, byte[] data) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_WARN, className, title, data);
	}
	
	public static void error(Object tag, String title, byte[] data) {
		Log.out(LOG_LEVEL_ERROR, tag.getClass().getName(), title, data);
	}
	
	public static void error(Class<?> objClass, String title, byte[] data) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_ERROR, className, title, data);
	}
	
	public static void fatal(Object tag, String title, byte[] data) {
		Log.out(LOG_LEVEL_FATAL, tag.getClass().getName(), title, data);
	}
	
	public static void fatal(Class<?> objClass, String title, byte[] data) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_FATAL, className, title, data);
	}

	public static void debug(Object tag, String title, String  message) {
		Log.out(LOG_LEVEL_DEBUG, tag.getClass().getName(), title, message);
	}
	
	public static void debug(Class<?> objClass, String title, String  message) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_DEBUG, className, title, message);
	}
	
	public static void info(Object tag, String title, String message) {
		Log.out(LOG_LEVEL_INFO, tag.getClass().getName(), title, message);
	}
	
	public static void info(Class<?> objClass, String title, String message) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_INFO, className, title, message);
	}
	
	public static void warning(Object tag, String title, String message) {
		Log.out(LOG_LEVEL_WARN, tag.getClass().getName(), title, message);
	}
	
	public static void warning(Class<?> objClass, String title, String message) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_WARN, className, title, message);
	}
	
	public static void error(Object tag, String title, String message) {
		Log.out(LOG_LEVEL_ERROR, tag.getClass().getName(), title, message);
	}
	
	public static void error(Class<?> objClass, String title, String message) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_ERROR, className, title, message);
	}
	
	public static void fatal(Object tag, String title, String message) {
		Log.out(LOG_LEVEL_FATAL, tag.getClass().getName(), title, message);
	}
	
	public static void fatal(Class<?> objClass, String title, String message) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_FATAL, className, title, message);
	}
	
	public static void debug(Object tag, String title, Throwable e) {
		Log.out(LOG_LEVEL_DEBUG, tag.getClass().getName(), title, e);
	}
	
	public static void debug(Class<?> objClass, String title, Throwable e) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_DEBUG, className, title, e);
	}
	
	public static void info(Object tag, String title, Throwable e) {
		Log.out(LOG_LEVEL_INFO, tag.getClass().getName(), title, e);
	}
	
	public static void info(Class<?> objClass, String title, Throwable e) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_INFO, className, title, e);
	}
	
	public static void warning(Object tag, String title, Throwable e) {
		Log.out(LOG_LEVEL_WARN, tag.getClass().getName(), title, e);
	}
	
	public static void warning(Class<?> objClass, String title, Throwable e) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_WARN, className, title, e);
	}
	
	public static void error(Object tag, String title, Throwable e) {
		Log.out(LOG_LEVEL_ERROR, tag.getClass().getName(), title, e);
	}
	
	public static void error(Class<?> objClass, String title, Throwable e) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_ERROR, className, title, e);
	}
	
	public static void fatal(Object tag, String title, Throwable e) {
		Log.out(LOG_LEVEL_FATAL, tag.getClass().getName(), title, e);
	}
	
	public static void fatal(Class<?> objClass, String title, Throwable e) {
		String className = null;
		if (objClass == null) {
			className = new RuntimeException().getStackTrace()[1].getClassName();
		} else {
			className = objClass.getName();
		}
		Log.out(LOG_LEVEL_FATAL, className, title, e);
	}
	
}
