/**
 * 
 */
package com.quickretrieval.server.dao;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.quickretrieval.server.log.Log;
import com.quickretrieval.server.properties.SystemProperties;

/**
 * @author BruceHuang
 * This Class implement the Database Common Utility Methods.
 */
public class DatabaseUtil {

	// Add by 何政東, 20180928, add properties for VA database
	private static final String PROPERTY_VA_DATA_SOURCE = "va.database.resource";
	private static final String PROPERTY_VA_DATABASE_CHARSET = "va.database.charset";
	private static final String PROPERTY_DATA_SOURCE = "database.resource";
	private static final String PRPERTY_APPLICATION_PLATFORM = "server.platform";
	private static final String PROPERTY_DATABASE_CHARSET = "database.charset";
	private static final String DEFAULT_DATABASE_CHARSET = "UTF-8";
	private static final String SQL_SERVER_PRODUCT_NAME = "microsoft";
	private static final String MYSQL_PRODUCT_NAME = "mysql";
	private static final String DB2_PRODUCT_NAME = "db2";
	private static DataSource dataSource = null;
	// Add by 何政東, 20180928, add datasource for VA database
	private static DataSource dataSource_va = null;
	private static int		  database_product = 0;
	private static String	  database_charset = null;
	
	private static DatabaseUtil defaultInstance = null;

	// Supported Application Server Define
	public static final String APPLICATION_PLATFORM_TOMCAT = "tomcat";
	public static final String APPLICATION_PLATFORM_WEBSPHERE = "webshpere";
	
	// Supported Database Productions
	public static final int		DATABASE_PRODUCT_MYSQL = 1;
	public static final int		DATABASE_PRODUCT_MSSQL = 2;
	public static final int		DATABASE_PRODUCT_DB2 = 3;
	
	public static DatabaseUtil getInstance() {
		if (defaultInstance == null) {
			defaultInstance = new DatabaseUtil();
		}
		return defaultInstance;
	}

	private boolean getDataSource() {
		InitialContext context = null;
		// Context envContext = null;
		boolean result = true;
		try {
			if (dataSource == null) {
				String dataSourceName = SystemProperties.getInstance().getStringProperty(PROPERTY_DATA_SOURCE, null);
				if (dataSourceName == null) {
					throw new NamingException("Cannot found Database Resource Property:"+PROPERTY_DATA_SOURCE);
				}
				database_charset = SystemProperties.getInstance().getStringProperty(PROPERTY_DATABASE_CHARSET, DEFAULT_DATABASE_CHARSET); 
				String platform = SystemProperties.getInstance().getStringProperty(PRPERTY_APPLICATION_PLATFORM, APPLICATION_PLATFORM_TOMCAT);
				if (platform.equalsIgnoreCase(APPLICATION_PLATFORM_WEBSPHERE)) {
					// For WebSphere
					java.util.Properties parms = new java.util.Properties(); 
					parms.setProperty(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
					//Create the Initial Naming Context
					context = new javax.naming.InitialContext(parms);
					dataSource = (DataSource) context.lookup("java:comp/env/"+dataSourceName);
				} else {
					context = new InitialContext();
					/* envContext = (Context) context.lookup("java:comp/env");
					dataSource = (DataSource) envContext.lookup(dataSourceName); */
					dataSource = (DataSource) context.lookup("java:comp/env/"+dataSourceName);
				}
				Log.debug(this, "getDataSource", "DataSource got.");
				Connection dbcon = null;
				try {
					dbcon = dataSource.getConnection();
					String dbProduct = dbcon.getMetaData().getDatabaseProductName();
					dbProduct = dbProduct.toLowerCase();
				    Log.debug(this, "getDataSource", "Database Product="+dbProduct);
					if (dbProduct.indexOf(DB2_PRODUCT_NAME) >= 0) {
						Log.debug(this, "getDataSource", "using DB2 Server");
						database_product = DATABASE_PRODUCT_DB2;
					}
					else 
					if (dbProduct.indexOf(SQL_SERVER_PRODUCT_NAME) >= 0) {
						Log.debug(this, "getDataSource", "using Microsoft SQL Server");
						database_product = DATABASE_PRODUCT_MSSQL;
					} else
					if (dbProduct.indexOf(MYSQL_PRODUCT_NAME) >= 0){
						Log.debug(this, "getDataSource", "using MySQL");
						database_product = DATABASE_PRODUCT_MYSQL;
					} else {
						Log.debug(this, "getDataSource", "Cannot recognize Database Product, using Microsoft SQL Server");
						database_product = DATABASE_PRODUCT_MSSQL;
					}
					dbcon.close();
				} catch (Exception ex) {
					if (dbcon != null) try { dbcon.close(); } catch (Exception e) {}
					Log.error(this, "getDataSource", ex);
					database_product = DATABASE_PRODUCT_MSSQL; // Default Database is MS-SQL;
				}
			}
		} catch (NamingException e) {
			Log.error(this, "getDataSource", e);
			result = false;
		}
		try {
			// if (envContext != null) envContext.close();
			if (context != null) context.close();
		} catch (Exception e) {}
		return result;
	}

	// Add by 何政東, 20180928, add get datasource for VA database
	private boolean getVADataSource() {
		InitialContext context = null;
		// Context envContext = null;
		boolean result = true;
		try {
			if (dataSource_va == null) {
				String dataSourceName = SystemProperties.getInstance().getStringProperty(PROPERTY_VA_DATA_SOURCE, null);
				if (dataSourceName == null) {
					throw new NamingException("Cannot found Database Resource Property:"+PROPERTY_VA_DATA_SOURCE);
				}
				database_charset = SystemProperties.getInstance().getStringProperty(PROPERTY_VA_DATABASE_CHARSET, DEFAULT_DATABASE_CHARSET); 
				String platform = SystemProperties.getInstance().getStringProperty(PRPERTY_APPLICATION_PLATFORM, APPLICATION_PLATFORM_TOMCAT);
				if (platform.equalsIgnoreCase(APPLICATION_PLATFORM_WEBSPHERE)) {
					// For WebSphere
					java.util.Properties parms = new java.util.Properties(); 
					parms.setProperty(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
					//Create the Initial Naming Context
					context = new javax.naming.InitialContext(parms);
					dataSource_va = (DataSource) context.lookup("java:comp/env/"+dataSourceName);
				} else {
					context = new InitialContext();
					/* envContext = (Context) context.lookup("java:comp/env");
					dataSource = (DataSource) envContext.lookup(dataSourceName); */
					dataSource_va = (DataSource) context.lookup("java:comp/env/"+dataSourceName);
				}
				Log.debug(this, "getVADataSource", "DataSource got.");
				Connection dbcon = null;
				try {
					dbcon = dataSource_va.getConnection();
					String dbProduct = dbcon.getMetaData().getDatabaseProductName();
					dbProduct = dbProduct.toLowerCase();
				    Log.debug(this, "getVADataSource", "Database Product="+dbProduct);
					if (dbProduct.indexOf(DB2_PRODUCT_NAME) >= 0) {
						Log.debug(this, "getVADataSource", "using DB2 Server");
						database_product = DATABASE_PRODUCT_DB2;
					}
					else 
					if (dbProduct.indexOf(SQL_SERVER_PRODUCT_NAME) >= 0) {
						Log.debug(this, "getVADataSource", "using Microsoft SQL Server");
						database_product = DATABASE_PRODUCT_MSSQL;
					} else
					if (dbProduct.indexOf(MYSQL_PRODUCT_NAME) >= 0){
						Log.debug(this, "getVADataSource", "using MySQL");
						database_product = DATABASE_PRODUCT_MYSQL;
					} else {
						Log.debug(this, "getVADataSource", "Cannot recognize Database Product, using Microsoft SQL Server");
						database_product = DATABASE_PRODUCT_MSSQL;
					}
					dbcon.close();
				} catch (Exception ex) {
					if (dbcon != null) try { dbcon.close(); } catch (Exception e) {}
					Log.error(this, "getVADataSource", ex);
					database_product = DATABASE_PRODUCT_MSSQL; // Default Database is MS-SQL;
				}
			}
		} catch (NamingException e) {
			Log.error(this, "getVADataSource", e);
			result = false;
		}
		try {
			// if (envContext != null) envContext.close();
			if (context != null) context.close();
		} catch (Exception e) {}
		return result;
	}
	
	public String getDatabaseCharset() {
		getDataSource();
		return database_charset;
	}
	
	public boolean isMSSQL() {
		getDataSource();
		if (database_product == DATABASE_PRODUCT_MSSQL) return true;
		return false;
	}
	
	public boolean isMySQL() {
		getDataSource();
		if (database_product == DATABASE_PRODUCT_MYSQL) return true;
		return false;
	}
	
	public boolean isDB2() {
		getDataSource();
		if (database_product == DATABASE_PRODUCT_DB2) return true;
		return false;
	}
	
	private static int used_connections = 0;
	// Add by 何政東, 20180928, add used connections for VA database
	private static int used_va_connections = 0;
	
	public synchronized Connection getConnection() {
		if (!getDataSource()) return null;
		try {
			Connection connection = dataSource.getConnection();
			used_connections++;
			Log.debug(this, "getConnection", "A database connection got (connections="+used_connections+").");
			return connection;
		} catch (Exception e) {
			Log.error(this, "getConnection", "Connections: "+used_connections+",  Exception:"+e.getMessage());
			Log.error(this, "getConnection", e);
		}
		return null;
	}

	// Add by 何政東, 20180928, add get connection for VA database
	public synchronized Connection getVAConnection() {
		if (!getVADataSource()) return null;
		try {
			Connection connection = dataSource_va.getConnection();
			used_va_connections++;
			Log.debug(this, "getVAConnection", "A database connection got (connections="+used_va_connections+").");
			return connection;
		} catch (Exception e) {
			Log.error(this, "getVAConnection", "Connections: "+used_va_connections+",  Exception:"+e.getMessage());
			Log.error(this, "getVAConnection", e);
		}
		return null;
	}
	
	public void closeConnection(Connection connection) {
		if (connection != null) {
			try { connection.close(); } catch (Exception e) {}
			used_connections--;
			Log.debug(this, "getConnection", "A database connection closed (connections="+used_connections+").");
		}
	}

	// Add by 何政東, 20180928, add counter connections for VA database
	public void closeVAConnection(Connection connection) {
		if (connection != null) {
			try { connection.close(); } catch (Exception e) {}
			used_va_connections--;
			Log.debug(this, "closeVAConnection", "A database connection closed (connections="+used_va_connections+").");
		}
	}
/*
	public java.sql.Date convertDateToSqlDate(java.util.Date date) {
		if (date == null) return null;
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		return sqlDate;
	}

	public java.sql.Timestamp convertDateToSqlTimestamp(java.util.Date date) {
		if (date == null) return null;
		java.sql.Timestamp sqlDate = new java.sql.Timestamp(date.getTime());
		return sqlDate;
	}
	
	public java.util.Date convertSqlDateToDate(java.sql.Date sqlDate) {
		return sqlDate;
	}
*/	
	public String getSubStringByEncodeByteLegnth(String string, int maxLength) {
		if (string == null) return null;
		if (maxLength <= 0) return "";
		try {
			byte[] bytes = string.getBytes(this.getDatabaseCharset());
			if (bytes.length <= maxLength) return string;
			ByteArrayInputStream byteInput = new ByteArrayInputStream(bytes, 0, maxLength);
			InputStreamReader reader = new InputStreamReader(byteInput, this.getDatabaseCharset());
			char[] characters = new char[string.length()];
			int reads = reader.read(characters, 0, characters.length);
			// Log.debug(this, "getSubStringByEncodeByteLegnth", "read "+reads+" characters from string("+string.length()+"), bytes("+maxLength+")");
			return new String(characters, 0, reads);
		} catch (Exception ex) {
			Log.error(this, "getSubStringByEncodeByteLegnth", "Exception:"+ex.getMessage());
			Log.error(this, "getSubStringByEncodeByteLegnth", ex);
			return string;
		}
	}
	
	public boolean checkStringFieldLength(String fieldValue, int maxLength) {
		if (fieldValue == null || fieldValue.length() <= maxLength) return true;
		try {
			if (fieldValue.getBytes(this.getDatabaseCharset()).length <= maxLength) return true;
			return false;
		} catch (Exception ex) {
			Log.error(this, "checkStringFieldLength", "Encode Exception:"+ex.getMessage());
			return false;
		}
	}
	
	public boolean checkBlobFieldLength(byte[] fieldValue, long maxLength) {
		if (fieldValue == null || fieldValue.length <= maxLength) return true;
		return false;
	}

}
