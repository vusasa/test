/**
 * 
 */
package com.quickretrieval.jcic.server.action;

// Add by 何政東, 20181204, for CSRF token
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.quickretrieval.common.utils.FormatCheckUtil;
import com.quickretrieval.common.utils.MyBase64;
import com.quickretrieval.common.utils.MyDate;
import com.quickretrieval.common.utils.QRUUID;
import com.quickretrieval.server.log.Log;
import com.quickretrieval.server.properties.SystemProperties;
import com.quickretrieval.jcic.server.adapter.InvoiceAdapter;
import com.quickretrieval.jcic.server.adapter.LoginSessionControl;
import com.quickretrieval.jcic.server.db.UserJcicTokenDao;
import com.quickretrieval.jcic.server.em.JcicTokenStatus;
import com.quickretrieval.jcic.server.entity.EndUser;
import com.quickretrieval.jcic.server.entity.EndUserServiceResult;
import com.quickretrieval.jcic.server.entity.Transaction;
import com.quickretrieval.jcic.server.entity.UserErrorInfo;
import com.quickretrieval.jcic.server.entity.UserJcicToken;
import com.quickretrieval.server.adapter.SequenceControl;
import com.quickretrieval.server.control.RequestWrapper;
import com.quickretrieval.server.control.ResponseWrapper;
import com.quickretrieval.server.dao.QueryResult;
import com.quickretrieval.server.entity.ErrorInfo;
import com.quickretrieval.server.entity.Sequence;

/**
 * 這個 Class 提供用戶註冊電子發票-聯徵載具服務功能。
 * @author BruceHuang
 */
public class JCICTokenService extends EndUserBaseAction {

	/**
	 * Default Serialized Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	// Action Services
	private static final String QUERY_TOKEN_SERVICE_NAME = "QueryToken.do";
	private static final String REGISTER_TOKEN_SERVICE_NAME = "RegisterToken.do";
	private static final String REGISTER_TOKEN_INPUT_SERVICE_NAME = "RegisterTokenInput.do";
	private static final String UPDATE_TOKEN_SERVICE_NAME = "UpdateToken.do";
	private static final String UPDATE_TOKEN_INPUT_SERVICE_NAME = "UpdateTokenInput.do";
	private static final String REVOKE_TOKEN_SERVICE_NAME = "RevokeToken.do";
	private static final String SUBSUME_TOKEN_SERVICE_NAME = "SubsumeToken.do";
	private static final String SUBSUME_TOKEN_BACK_SERVICE_NAME = "SubsumeBack.service";
	
	// System Configuration Properties
	private static final String PROPERTY_SERVICE_EXTERNAL_URL = "service.external.url";
	
	// System Sequence 
	private static final String JCIC_TOKEN_CARD_SEQUENCE_NAME = "JcicTokenCard";
	
	// Request Parameters
	private static final String PARAMETER_NAME = "name";
	private static final String PARAMETER_EMAIL = "email";
	private static final String PARAMETER_PHONE = "phone";
	private static final String PARAMETER_ADDRESS = "address";
	//Add by 何政東, 2018/07/20, zip code parameter
	private static final String PARAMETER_ZIP_CODE = "zip_code";
	// Response Data Parameters
	private static final String RESPONSE_DATA_USER = "user";
	private static final String RESPONSE_DATA_JCIC_TOKEN = "jcic_token";
	@SuppressWarnings("unused")
	private static final String RESPONSE_DATA_REDIRECT_URL = "redirect";
	private static final String RESPONSE_DATA_AUTO_NEXT_SERVICE = "auto_next_service";
	private static final String RESPONSE_DATA_CARD_BAN = "card_ban";
	private static final String RESPONSE_DATA_CARD_NO1 = "card_no1";
	private static final String RESPONSE_DATA_CARD_NO2 = "card_no2";
	private static final String RESPONSE_DATA_CARD_TYPE = "card_type";
	private static final String RESPONSE_DATA_CARD_TOKEN = "card_token";
	private static final String RESPONSE_DATA_BACK_URL = "back_url";
	private static final String RESPONSE_DATA_SUBSUME_URL = "subsume_url";
	
	// Add by 何政東, 20181204, set CSRF token
	private static final String CSRF_TOKEN_TAG = "csrf_token";
	
	private String generateCardSequence() {
		String method = "generateCardSequence";
		Sequence sequence = null;
		synchronized (this) {
			sequence = SequenceControl.requestNextSequence(JCIC_TOKEN_CARD_SEQUENCE_NAME);
		}
		if (sequence == null) {
			Log.error(this, method, "Get Next Card No for JCIC Token failed");
			return null;
		}
		String sequenceString = "JCIC"+String.format("%s%04d", sequence.getDate().getMinguoDateString(), sequence.getSerialNo());
		return sequenceString;
	}
	
	/**
	 * 這個 Method 提供「查詢聯徵載具」的服務功能，查詢用戶目前已註冊的聯徵載具資訊。
	 * @param request 服務功能請求訊息
	 * @return 返回服務功能結果
	 */
	private EndUserServiceResult doQueryToken(RequestWrapper request) {
		String method = "doQueryToken";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		result.setCatalog(Transaction.CATALOG_JCIC_TOKEN);
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		// Read User current registered JCIC Token Information
		UserJcicToken tokenInfo = UserJcicTokenDao.getInstance().getByIdnBan(user.getUserIdentification());
		if (tokenInfo == null || 
            tokenInfo.getStatus() == null || tokenInfo.getStatus() == JcicTokenStatus.TokenNone ||
			tokenInfo.getStatus() == JcicTokenStatus.TokenRevoked) {
			tokenInfo = null;
		} else {
			if (tokenInfo.getStatus() != JcicTokenStatus.TokenSubsumed) {
				ErrorInfo error = new ErrorInfo();
				String bigPlatformUrl = InvoiceAdapter.getInstance().getBigPlatformUrl(error);
				Log.debug(this, method, "BigPlatformUrl:"+bigPlatformUrl);
				if (bigPlatformUrl == null) {
					errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_GENERATE_SUBSUME_URL_ERROR, error.getErrorMessage(), null);
					Log.error(this, method, "Get Subsume URL Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
					result.setResultFlag(false);
					result.setErrorMessage("quickcode.error.jcic_token_generate_subsumed_url_error");
					result.setErrorInfo(errorInfo);
					return result;
				}
				Log.debug(this, method, "subsume_url="+bigPlatformUrl);
				String serviceDomain = getExternalServiceDomain(request);
				if (serviceDomain == null) {
					errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_GENERATE_SUBSUME_DATA_ERROR, "Get External Service Domain Error", null);
					Log.error(this, method, "Get External Service Domian Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
					result.setResultFlag(false);
					result.setErrorMessage("quickcode.error.jcic_token_generate_subsumed_data_error");
					result.setErrorInfo(errorInfo);
					return result;
				}
				// Generate Information for JCIC Token Subsume
				String subsumeToken = null;
				String card_ban = null;
				String card_no1 = null;
				String card_no2 = null;
				String card_type = null;
				String back_url = null;
				try {
					subsumeToken = QRUUID.getInstance().getNextUUID().toString().toUpperCase();
					card_ban = InvoiceAdapter.getInstance().getJcicBan();
					card_no1 = MyBase64.encodeBase64String(tokenInfo.getCardNo().getBytes("ISO-8859-1"));
					card_no2 = card_no1;
					card_type = MyBase64.encodeBase64String(InvoiceAdapter.getInstance().getJcicTokenType().getBytes("ISO-8859-1"));
					back_url = "https://"+serviceDomain+"/"+SUBSUME_TOKEN_BACK_SERVICE_NAME;
					tokenInfo.setSubsumeToken(subsumeToken);
				} catch (Exception ex) {
					errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_GENERATE_SUBSUME_DATA_ERROR, "Generate Subsume Data Error", null);
					Log.error(this, method, "Generate Token Subsume Data exception:"+ex.getMessage());
					result.setResultFlag(false);
					result.setErrorMessage("quickcode.error.jcic_token_generate_subsumed_data_error");
					result.setErrorInfo(errorInfo);
					return result;
				}
				if (!UserJcicTokenDao.getInstance().update(tokenInfo)) {
					errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_DB_ERROR, "Update to Database Error", null);
					Log.error(this, method, "Update to Database Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
					result.setResultFlag(false);
					result.setErrorInfo(errorInfo);
					return result;
				}
				Log.debug(this, method, RESPONSE_DATA_CARD_BAN+"="+card_ban+"&"
						  +RESPONSE_DATA_CARD_NO1+"="+card_no1
						  +"&"+RESPONSE_DATA_CARD_NO2+"="+card_no2
						  +"&"+RESPONSE_DATA_CARD_TYPE+"="+card_type
						  +"&"+RESPONSE_DATA_CARD_TOKEN+"="+subsumeToken
						  +"&"+RESPONSE_DATA_BACK_URL+"="+back_url);
				resultMap.put(RESPONSE_DATA_CARD_BAN, card_ban);
				resultMap.put(RESPONSE_DATA_CARD_NO1, card_no1);
				resultMap.put(RESPONSE_DATA_CARD_NO2, card_no2);
				resultMap.put(RESPONSE_DATA_CARD_TYPE, card_type);
				resultMap.put(RESPONSE_DATA_CARD_TOKEN, subsumeToken);
				resultMap.put(RESPONSE_DATA_BACK_URL, back_url);
				resultMap.put(RESPONSE_DATA_SUBSUME_URL, bigPlatformUrl);
			}
		}
		resultMap.put(RESPONSE_DATA_USER, user);
		// Modify by 何政東, 20181205, set CSRF token
		if (tokenInfo != null) {
			resultMap.put(RESPONSE_DATA_JCIC_TOKEN, tokenInfo);
			resultMap.put(CSRF_TOKEN_TAG, this.setSessionCSRFToken(request));
		}
		result.setOutputResult(resultMap);
		return result;
	}
	
	/**
	 * 這個 Method 提供註冊／更新「聯徵載具」產生資料輸入頁面服務功能。
	 * @param request 服務功能請求訊息
	 * @return 返回服務功能結果
	 */
	private EndUserServiceResult doRegisterTokenInput(RequestWrapper request) {
		String method = "doRegisterTokenInput";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_JCIC_TOKEN);
		// Get/Check Login User
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		// Read User current registered JCIC Token Information
		UserJcicToken tokenInfo = UserJcicTokenDao.getInstance().getByIdnBan(user.getUserIdentification());
		if (tokenInfo != null && tokenInfo.getStatus() != null && 
			(tokenInfo.getStatus() != JcicTokenStatus.TokenNone && tokenInfo.getStatus() == JcicTokenStatus.TokenRevoked)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_ALREADY_REGISTER, "User already Registered", null);
			Log.error(this, method, "User already Registered Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Setup Result
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_USER, user);
		// Add by 何政東, 20181205, set CSRF token
		resultMap.put(CSRF_TOKEN_TAG, this.setSessionCSRFToken(request));
		result.setOutputResult(resultMap);
		return result;
	}
	
	@SuppressWarnings("unused")
	private boolean checkExistValidJcicTokenByCardNo(String cardNo, String userIdn) {
		// String method = "getValidJcicTokenByEmail";
		Map<String, Object> conditions = new HashMap<>();
		conditions.put(UserJcicTokenDao.QUERY_CONDITION_CARD_NO, cardNo);
		QueryResult<UserJcicToken> queryResult = UserJcicTokenDao.getInstance().query(conditions, 0, 0);
		if (queryResult == null) return false;
		UserJcicToken[] matchTokens = queryResult.getResult();
		if (matchTokens == null || matchTokens.length < 1) return false;
		for (int i = 0; i < matchTokens.length; i++) {
			UserJcicToken token = matchTokens[i];
			if (token != null && token.getCardNo().equalsIgnoreCase(cardNo) &&
				!token.getIdnBan().equalsIgnoreCase(userIdn)) return true;
			if (token == null || token.getStatus() == null || token.getStatus() == JcicTokenStatus.TokenNone ||
				token.getStatus() == JcicTokenStatus.TokenRevoked) continue;
			if (token.getIdnBan().equalsIgnoreCase(userIdn)) continue;
			return true;
		}
		return false;
	}
	
	/**
	 * 這個 Method 提供註冊「聯徵載具」的服務功能。
	 * 本功能檢查用戶輸入的註冊資料（名稱、Email、電話、地址）是否符合格式，並新增一筆用戶的「聯徵載具」資訊。
	 * 用戶註冊「聯徵載具」時，系統自動設定一個載具號碼。
	 * @param request 服務功能請求訊息
	 * @return 返回服務功能結果
	 */
	private EndUserServiceResult doRegisterToken(RequestWrapper request) {
		String method = "doRegisterToken";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_JCIC_TOKEN);
		// Get/Check Login User
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Add by 何政東, 20181204, Check CSRF token exist
		if (!this.checkSubmitCSRFToken(request)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		// Get Request Parameters
		String token_name = request.getStringParameter(PARAMETER_NAME, null);
		String token_email = request.getStringParameter(PARAMETER_EMAIL, null);
		String token_phone = request.getStringParameter(PARAMETER_PHONE, null);
		String token_address = request.getStringParameter(PARAMETER_ADDRESS, null);
		//Add by 何政東, 2018/07/20, zip code parameter
		String token_zip_code = request.getStringParameter(PARAMETER_ZIP_CODE, null);
		if (token_name == null || !FormatCheckUtil.isNameFormat(token_name, 60)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_NAME, "Invalid Name Format", null);
			Log.error(this, method, "Invalid name format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_user_name");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (token_email == null || !FormatCheckUtil.isEmailAddressFormat(token_email, 80)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_EMAIL, "Invalid email address format", null);
			Log.warning(this, method, "Invalid email address format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_email");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (token_phone == null || !FormatCheckUtil.isPhoneFormat(token_phone, 26)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_PHONE, "Invalid phone format", null);
			Log.error(this, method, "Invalid phone format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_user_phone");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (token_address == null || !FormatCheckUtil.isAddressFormat(token_address, 100)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_ADDRESS, "Invalid address format", null);
			Log.error(this, method, "Invalid address format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_user_address");
			result.setErrorInfo(errorInfo);
			return result;
		}
		//Add by 何政東, 2018/07/20, check zip code parameter
		if (token_zip_code == null || !FormatCheckUtil.isNumber(token_zip_code) || (token_zip_code.length()!=3 && token_zip_code.length()!=5)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_ZIP_CODE, "Invalid zip code format", null);
			Log.error(this, method, "Invalid zip code format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_user_zip_code");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Get User's JCIC Token Info exist or not
		UserJcicToken tokenInfo = UserJcicTokenDao.getInstance().getByIdnBan(user.getUserIdentification());
		if (tokenInfo != null && tokenInfo.getStatus() != null &&
			(tokenInfo.getStatus() != JcicTokenStatus.TokenNone && tokenInfo.getStatus() != JcicTokenStatus.TokenRevoked)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_ALREADY_REGISTER, "Already register jcic token", null);
			Log.error(this, method, "JCIC Token Already Register Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_already_register");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Setup new User JCIC Token object
		MyDate date = new MyDate();
		boolean newToken = false;
		if (tokenInfo == null) {
			tokenInfo = new UserJcicToken();
			tokenInfo.setIdnBan(user.getUserIdentification());
			tokenInfo.setCardNo(this.generateCardSequence());
			newToken = true;
		}
		tokenInfo.setEmail(token_email);
		tokenInfo.setName(token_name);
		tokenInfo.setPhone(token_phone);
		//Add by 何政東, 2018/07/23, set zip code
		tokenInfo.setZipCode(token_zip_code);
		tokenInfo.setAddress(token_address);
		tokenInfo.setResigsterTime(date);
		tokenInfo.setUpdateTime(date);
		tokenInfo.setStatus(JcicTokenStatus.TokenRegistered);
		if (newToken) {
			if (!UserJcicTokenDao.getInstance().insert(tokenInfo)) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_DB_ERROR, "Insert to Database Error", null);
				Log.error(this, method, "Insert to Database Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(errorInfo);
				return result;
			}
		} else {
			if (!UserJcicTokenDao.getInstance().update(tokenInfo)) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_DB_ERROR, "Update to Database Error", null);
				Log.error(this, method, "Update to Database Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorInfo(errorInfo);
				return result;
			}			
		}
		// setup result
		/*
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_USER, user);
		if (tokenInfo != null) resultMap.put(RESPONSE_DATA_JCIC_TOKEN, tokenInfo);
		result.setOutputResult(resultMap);
		return result;
		*/
		return doQueryToken(request);
	}
	
	/**
	 * 這個 Method 提供註冊／更新「聯徵載具」產生資料輸入頁面服務功能。
	 * @param request 服務功能請求訊息
	 * @return 返回服務功能結果
	 */
	private EndUserServiceResult doUpdateTokenInput(RequestWrapper request) {
		String method = "doUpdateTokenInput";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_JCIC_TOKEN);
		// Get/Check Login User
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		// Read User current registered JCIC Token Information
		UserJcicToken tokenInfo = UserJcicTokenDao.getInstance().getByIdnBan(user.getUserIdentification());
		if (tokenInfo == null || tokenInfo.getStatus() == null
			|| tokenInfo.getStatus() == JcicTokenStatus.TokenNone || tokenInfo.getStatus() == JcicTokenStatus.TokenRevoked) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_REGISTER, "User not register", null);
			Log.error(this, method, "User not Register Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Setup Result
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_USER, user);
		resultMap.put(RESPONSE_DATA_JCIC_TOKEN, tokenInfo);
		// Add by 何政東, 20181205, set CSRF token
		resultMap.put(CSRF_TOKEN_TAG, this.setSessionCSRFToken(request));
		result.setOutputResult(resultMap);
		return result;
	}

	/**
	 * 這個 Method 提供變更「聯徵載具」的服務功能。
	 * 本功能檢查用戶輸入的更新資料（名稱、Email、電話、地址）是否符合格式，並更新用戶的「聯徵載具」資訊。
	 * @param request 服務功能請求訊息
	 * @return 返回服務功能結果
	 */
	private EndUserServiceResult doUpdateToken(RequestWrapper request) {
		String method = "doUpdateToken";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_JCIC_TOKEN);
		// Get/Check Login User
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_SETUP_EMAIL_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Add by 何政東, 20181204, Check CSRF token exist
		if (!this.checkSubmitCSRFToken(request)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		// Get Request Parameters
		String token_name = request.getStringParameter(PARAMETER_NAME, null);
		String token_email = request.getStringParameter(PARAMETER_EMAIL, null);
		String token_phone = request.getStringParameter(PARAMETER_PHONE, null);
		String token_address = request.getStringParameter(PARAMETER_ADDRESS, null);
		//Add by 何政東, 2018/07/23, zip code parameter
		String token_zip_code = request.getStringParameter(PARAMETER_ZIP_CODE, null);
		if (token_name == null || !FormatCheckUtil.isNameFormat(token_name, 60)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_NAME, "Invalid Name Format", null);
			Log.error(this, method, "Invalid name format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_user_name");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (token_email == null || !FormatCheckUtil.isEmailAddressFormat(token_email, 80)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_EMAIL, "Invalid email address format", null);
			Log.warning(this, method, "Invalid email address format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_email");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (token_phone == null || !FormatCheckUtil.isPhoneFormat(token_phone, 26)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_PHONE, "Invalid phone format", null);
			Log.error(this, method, "Invalid phone format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_user_phone");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (token_address == null || !FormatCheckUtil.isAddressFormat(token_address, 100)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_ADDRESS, "Invalid address format", null);
			Log.error(this, method, "Invalid address format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_user_address");
			result.setErrorInfo(errorInfo);
			return result;
		}
		//Add by 何政東, 2018/07/23, check zip code parameter
		if (token_zip_code == null || !FormatCheckUtil.isNumber(token_zip_code) || (token_zip_code.length()!=3 && token_zip_code.length()!=5)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_INVALID_ZIP_CODE, "Invalid zip code format", null);
			Log.error(this, method, "Invalid zip code format Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_token_user_zip_code");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Get User's JCIC Token Info
		UserJcicToken tokenInfo = UserJcicTokenDao.getInstance().getByIdnBan(user.getUserIdentification());
		if (tokenInfo == null || tokenInfo.getStatus() == null || 
			tokenInfo.getStatus() == JcicTokenStatus.TokenNone || tokenInfo.getStatus() == JcicTokenStatus.TokenRevoked) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_REGISTER, "Not register jcic token", null);
			Log.error(this, method, "JCIC Token Not Register Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_not_register");
			result.setErrorInfo(errorInfo);
			return result;
		}
		/*
		// Check is Email already used by Other User
		boolean isEmailUsed = this.checkExistValidJcicTokenByCardNo(token_email, user.getUserIdentification());
		if (isEmailUsed) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_EMAIL_ALREADY_USED, "Email already registered jcic token", null);
			Log.error(this, method, "JCIC Token Already Registered Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_email_already_register");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// If Email has been Changed and Status is Subsumed, then reset to Status to Registered
		if (!token_email.equalsIgnoreCase(tokenInfo.getCardNo()) && tokenInfo.getStatus() == JcicTokenStatus.TokenSubsumed) {
			tokenInfo.setStatus(JcicTokenStatus.TokenRegistered);
		}
		*/
		// Setup new User JCIC Token object
		MyDate date = new MyDate();
		tokenInfo.setEmail(token_email);
		tokenInfo.setName(token_name);
		tokenInfo.setPhone(token_phone);
		tokenInfo.setAddress(token_address);
		//Add by 何政東, 2018/07/23, set zip code
		tokenInfo.setZipCode(token_zip_code);
		tokenInfo.setUpdateTime(date);
		if (!UserJcicTokenDao.getInstance().update(tokenInfo)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_DB_ERROR, "Update to Database Error", null);
			Log.error(this, method, "Update to Database Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Setup Result
		/*
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_USER, user);
		if (tokenInfo != null) resultMap.put(RESPONSE_DATA_JCIC_TOKEN, tokenInfo);
		result.setOutputResult(resultMap);
		return result;
		*/
		return doQueryToken(request);
	}
	
	/**
	 * 這個 Method 提供註銷「聯徵載具」的服務功能。
	 * 本功能將用戶的「聯徵載具」資訊狀態更新為「已註銷」。
	 * @param request 服務功能請求訊息
	 * @return 返回服務功能結果
	 */
	@SuppressWarnings("unused")
	private EndUserServiceResult doRevokeToken(RequestWrapper request) {
		String method = "doRevokeToken";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Setup Service Result
		result.setCatalog(Transaction.CATALOG_JCIC_TOKEN);
		// Get/Check Login User
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		// Get User's JCIC Token Info
		UserJcicToken tokenInfo = UserJcicTokenDao.getInstance().getByIdnBan(user.getUserIdentification());
		if (tokenInfo == null || tokenInfo.getStatus() == null || 
			tokenInfo.getStatus() == JcicTokenStatus.TokenNone || tokenInfo.getStatus() == JcicTokenStatus.TokenRevoked) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_REGISTER, "Not register jcic token", null);
			Log.error(this, method, "JCIC Token Not Register Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_not_register");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Setup new User JCIC Token object
		MyDate date = new MyDate();
		tokenInfo.setUpdateTime(date);
		tokenInfo.setStatus(JcicTokenStatus.TokenRevoked);
		if (!UserJcicTokenDao.getInstance().update(tokenInfo)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_DB_ERROR, "Update to Database Error", null);
			Log.error(this, method, "Update to Database Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Setup Result
		/*
		result.setResultFlag(true);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_USER, user);
		if (tokenInfo != null) resultMap.put(RESPONSE_DATA_JCIC_TOKEN, tokenInfo);
		result.setOutputResult(resultMap);
		return result;
		*/
		return doQueryToken(request);
	}
	
	
	private String getExternalServiceDomain(RequestWrapper request) {
		String method = "getExternalServiceDomain";
	    String requestDomain = request.getServerName()+":"+request.getServerPort()+request.getContextPath();
	    String serviceDomain = SystemProperties.getInstance().getStringProperty(PROPERTY_SERVICE_EXTERNAL_URL, requestDomain);
	    if (serviceDomain != null && serviceDomain.trim().length() > 0) {
	    	return serviceDomain.trim();
	    }
	    Log.error(this, method, "External Service Domain System Properties("+PROPERTY_SERVICE_EXTERNAL_URL+") not defined");
	    return null;
	}
	
	/**
	 * 這個 Method 提供「歸戶聯徵載具」的服務功能，將用戶已註冊的聯徵載具資訊導向電子發票大平台進行歸戶。
	 * @param request 服務功能請求訊息
	 * @return 返回服務功能結果
	 */
	private EndUserServiceResult doSubsumeToken(RequestWrapper request) {
		String method = "doSubsumeToken";
		EndUserServiceResult result = new EndUserServiceResult();
		UserErrorInfo errorInfo = new UserErrorInfo();
		result.setCatalog(Transaction.CATALOG_JCIC_TOKEN);
		HttpSession session = request.getSession(false);
		EndUser user = this.getSessionUser(request);
		// Check Session exist
		if (user == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_LOGIN, "User not Login", null);
			Log.warning(this, method, "Check Login User Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_login");
			result.setErrorInfo(errorInfo);
			return result;
		}
		LoginSessionControl.updateLoginUser(session,  user);
		result.setUser(user);
		result.setCertType(user.getCertType());
		// Read User current registered JCIC Token Information
		UserJcicToken tokenInfo = UserJcicTokenDao.getInstance().getByIdnBan(user.getUserIdentification());
		if (tokenInfo == null || tokenInfo.getStatus() == null || tokenInfo.getStatus() == JcicTokenStatus.TokenNone ||
			tokenInfo.getStatus() == JcicTokenStatus.TokenRevoked) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_NOT_REGISTER, "Not register jcic token", null);
			Log.error(this, method, "JCIC Token Not Register Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_not_register");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (tokenInfo.getStatus() == JcicTokenStatus.TokenSubsumed) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_ALREADY_SUBSUMED, "Jcic token already Subsumed", null);
			Log.error(this, method, "JCIC Token Already Subsumed Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_already_subsumed");
			result.setErrorInfo(errorInfo);
			return result;
		}
		/*
		String subsumeUrl = InvoiceAdapter.getInstance().getSubsumeRedirectUrl(tokenInfo, SUBSUME_TOKEN_BACK_SERVICE_NAME);
		Log.debug(this, method, "subsumeUrl="+subsumeUrl);
		if (subsumeUrl == null || tokenInfo.getSubsumeToken() == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_GENERATE_SUBSUME_URL_ERROR, "Jcic token generate Subsume URL error", null);
			Log.error(this, method, "JCIC Token Generate Subsume URL Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_generate_subsumed_url_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		*/
		ErrorInfo error = new ErrorInfo();
		String bigPlatformUrl = InvoiceAdapter.getInstance().getBigPlatformUrl(error);
		Log.debug(this, method, "BigPlatformUrl:"+bigPlatformUrl);
		if (bigPlatformUrl == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_GENERATE_SUBSUME_URL_ERROR, error.getErrorMessage(), null);
			Log.error(this, method, "Get Subsume URL Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_generate_subsumed_url_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		String serviceDomain = getExternalServiceDomain(request);
		if (serviceDomain == null) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_GENERATE_SUBSUME_DATA_ERROR, "Get External Service Domain Error", null);
			Log.error(this, method, "Get External Service Domian Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_generate_subsumed_data_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// Generate Information for JCIC Token Subsume
		String subsumeToken = null;
		String card_ban = null;
		String card_no1 = null;
		String card_no2 = null;
		String card_type = null;
		String back_url = null;
		try {
			subsumeToken = QRUUID.getInstance().getNextUUID().toString().toUpperCase();
			card_ban = InvoiceAdapter.getInstance().getJcicBan();
			card_no1 = MyBase64.encodeBase64String(tokenInfo.getCardNo().getBytes("ISO-8859-1"));
			card_no2 = card_no1;
			card_type = MyBase64.encodeBase64String(InvoiceAdapter.getInstance().getJcicTokenType().getBytes("ISO-8859-1"));
			back_url = "https://"+serviceDomain+"/"+SUBSUME_TOKEN_BACK_SERVICE_NAME;
			tokenInfo.setSubsumeToken(subsumeToken);
		} catch (Exception ex) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_GENERATE_SUBSUME_DATA_ERROR, "Generate Subsume Data Error", null);
			Log.error(this, method, "Generate Token Subsume Data exception:"+ex.getMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.jcic_token_generate_subsumed_data_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (!UserJcicTokenDao.getInstance().update(tokenInfo)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_JCIC_TOKEN_DB_ERROR, "Update to Database Error", null);
			Log.error(this, method, "Update to Database Error("+errorInfo.getErrorCode()+"), Message="+errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			return result;
		}
		Log.debug(this, method, RESPONSE_DATA_CARD_BAN+"="+card_ban+"&"
				  +RESPONSE_DATA_CARD_NO1+"="+card_no1
				  +"&"+RESPONSE_DATA_CARD_NO2+"="+card_no2
				  +"&"+RESPONSE_DATA_CARD_TYPE+"="+card_type
				  +"&"+RESPONSE_DATA_CARD_TOKEN+"="+subsumeToken
				  +"&"+RESPONSE_DATA_BACK_URL+"="+back_url);
		result.setResultFlag(true);
		result.setErrorMessage("quickcode.info.connect_to_bigplatform");
		// result.setErrorMessage("quickcode.info.connecting_to_bigplatform");
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put(RESPONSE_DATA_USER, user);
		resultMap.put(RESPONSE_DATA_CARD_BAN, card_ban);
		resultMap.put(RESPONSE_DATA_CARD_NO1, card_no1);
		resultMap.put(RESPONSE_DATA_CARD_NO2, card_no2);
		resultMap.put(RESPONSE_DATA_CARD_TYPE, card_type);
		resultMap.put(RESPONSE_DATA_CARD_TOKEN, subsumeToken);
		resultMap.put(RESPONSE_DATA_BACK_URL, back_url);
		if (tokenInfo != null) resultMap.put(RESPONSE_DATA_JCIC_TOKEN, tokenInfo);
		resultMap.put(RESPONSE_DATA_AUTO_NEXT_SERVICE, bigPlatformUrl);
		result.setOutputResult(resultMap);
		return result;
	}

	// Add by 何政東, 20181204, set CSRF token
	private String setSessionCSRFToken(RequestWrapper request) {
		SecureRandom rnd = new SecureRandom();
		long rndValue = rnd.nextLong();
		String tokenValue = Long.toString(rndValue);
		this.setSessionInfo(request, CSRF_TOKEN_TAG, tokenValue);
		return tokenValue;
	}
	
	// Add by 何政東, 20181204, validate CSRF token
	private boolean checkSubmitCSRFToken(RequestWrapper request) {
		String method = "checkSubmitCSRFToken";
		Log.debug(this, method, "invoked.");
		String input_token = request.getStringParameter(CSRF_TOKEN_TAG, null);
		String session_token = this.getSessionInfo(request, CSRF_TOKEN_TAG, String.class);
		if (input_token == null || session_token == null || !input_token.equals(session_token)) {
			Log.debug(this, method, "verify CSRF token failed");
			return false;
		}
		Log.debug(this, method, "verify CSRF token success");
		return true;
	}

	/* (non-Javadoc)
	 * @see com.quickretrieval.jcic.server.action.EndUserBaseAction#doService(java.lang.String, javax.servlet.http.RequestWrapper, javax.servlet.http.ResponseWrapper)
	 */
	@Override
	protected EndUserServiceResult doService(String serviceName, RequestWrapper request, ResponseWrapper response) {
		// long service_begin_time = System.currentTimeMillis();
		EndUserServiceResult result = null;
		if (serviceName.equalsIgnoreCase(QUERY_TOKEN_SERVICE_NAME)) {
			result = doQueryToken(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(REGISTER_TOKEN_INPUT_SERVICE_NAME)) {
			result = doRegisterTokenInput(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(UPDATE_TOKEN_INPUT_SERVICE_NAME)) {
			result = doUpdateTokenInput(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(REGISTER_TOKEN_SERVICE_NAME)) {
			result = doRegisterToken(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(UPDATE_TOKEN_SERVICE_NAME)) {
			result = doUpdateToken(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(REVOKE_TOKEN_SERVICE_NAME)) {
			// result = doRevokeToken(request);
			// return result;
		}
		if (serviceName.equalsIgnoreCase(SUBSUME_TOKEN_SERVICE_NAME)) {
			result = doSubsumeToken(request);
			return result;
		}
		Log.error(this, "doService", "service("+serviceName+") not found"); 
		return null;
	}
}
