/**
 * 
 */
package com.quickretrieval.jcic.server.action;

import com.quickretrieval.server.log.Log;
import com.quickretrieval.server.properties.SystemProperties;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.quickretrieval.common.utils.FormatCheckUtil;
import com.quickretrieval.common.utils.HttpClient;
import com.quickretrieval.common.utils.JSONUtility;
import com.quickretrieval.common.utils.MyDate;
import com.quickretrieval.jcic.server.adapter.LoginSessionControl;
import com.quickretrieval.jcic.server.db.AnnotationDao;
import com.quickretrieval.jcic.server.em.StatusResponse;
import com.quickretrieval.jcic.server.entity.Annotation;
import com.quickretrieval.jcic.server.entity.AnnotationRecord;
import com.quickretrieval.jcic.server.entity.EndUser;
import com.quickretrieval.jcic.server.entity.EndUserServiceResult;
// Add by 何政東, 20190107, catalog for online annotation
import com.quickretrieval.jcic.server.entity.Transaction;
import com.quickretrieval.jcic.server.entity.UserErrorInfo;
import com.quickretrieval.jcic.server.security.TwcaPkiProvider;
import com.quickretrieval.locale.LocaleResource;
import com.quickretrieval.security.CipherProvider;
import com.quickretrieval.server.control.RequestWrapper;
import com.quickretrieval.server.control.ResponseWrapper;
import com.quickretrieval.server.db.SysParameterPersistence;
import com.quickretrieval.server.entity.ErrorInfo;

/**
 * @author 何政東 這個 Class 實現線上註記的各項使用者操作功能業務邏輯
 */
public class OnlineAnnotationManager extends EndUserBaseAction {

	/**
	 * Default Serialized Version ID
	 */
	private static final long serialVersionUID = 1L;

	private static final String ANNOTATION_INFO_SERVICE_NAME = "AnnotationInfo.do";
	private static final String ANNOTATION_CREATE_INPUT_SERVICE_NAME = "AnnotationCreateInput.do";
	private static final String ANNOTATION_CREATE_SERVICE_NAME = "AnnotationCreate.do";
	private static final String ANNOTATION_REVOKE_INPUT_SERVICE_NAME = "AnnotationRevokeInput.do";
	private static final String ANNOTATION_REVOKE_SERVICE_NAME = "AnnotationRevoke.do";

	private static final String SYSTEM_PARAMETER_KEY_API_AUTH = "API_AUTH";
	private static final String PROPERTY_ANNOTATION_SERVICE_IP = "host.domain";
	private static final String PROPERTY_ANNOTATION_SERVICE_URL = "Annotation.service.url";

	private static final String KEY_ANNOTATION_LIST = "annotationList";

	private static final String KEY_TIMESTAMP = "timestamp";
	private static final String KEY_AUTHWORD = "authword";
	private static final String KEY_DAO_METHOD = "dao_method";

	private static final String KEY_ENTITY_ANNOTATION_LIST = "entity_annotation_list";
	private static final String KEY_ENTITY_ANNOTATION_RECORD_LIST = "entity_annotation_record_list";

	private static final String KEY_IDN = "idn";
	private static final String KEY_ANNOTATION_CREATE_REASON = "annotation_create_reason";
	private static final String KEY_ANNOTATION_NOTE = "annotation_note";
	private static final String KEY_ANNOTATION_NOTE_SIGNATURE = "annotation_note_signature";
	private static final String KEY_ANNOTATION_MAINCODE = "annotation_maincode";
	private static final String KEY_ANNOTATION_DETAIL_ITEM = "annotation_detail_item";
	private static final String KEY_TIME_LIMIT_YEAR = "time_limit_year";
	private static final String KEY_TIME_LIMIT_MONTH = "time_limit_month";
	private static final String KEY_TIME_LIMIT_DATE = "time_limit_date";
	private static final String KEY_CHANGE_YEAR = "change_year";
	private static final String KEY_CHANGE_MONTH = "change_month";
	private static final String KEY_CHANGE_DATE = "change_date";

	private static final String KEY_ANNOTATION_REVOKE_REASON = "annotation_revoke_reason";

	private static final String DAO_METHOD_QUERY_NOT_EXPIRED_ANNOTATION = "queryNotExpiredAnnotation";
	private static final String DAO_METHOD_INSERT = "insert";
	private static final String DAO_METHOD_REVOKE = "revoke";

	private static final String MESSAGE_KEY_NOTE_VICTIM = "quickcode.info.annotation_note_victim";
	private static final String MESSAGE_KEY_NOTE_ID_CARD_CHANGED_PART_1 = "quickcode.info.annotation_note_victim_id_card_changed_part1";
	private static final String MESSAGE_KEY_NOTE_ID_CARD_CHANGED_PART_2 = "quickcode.info.annotation_note_victim_id_card_changed_part2";
	private static final String MESSAGE_KEY_NOTE_FINANCIAL_CARD_CHECK = "quickcode.info.annotation_note_financial_card_check";
	private static final String MESSAGE_KEY_NOTE_NEVER_APPLICATION_CARD_FOREVER = "quickcode.info.annotation_note_never_application_card_forever";
	private static final String MESSAGE_KEY_NOTE_NEVER_APPLICATION_CARD_PART1 = "quickcode.info.annotation_note_never_application_card_part1";
	private static final String MESSAGE_KEY_NOTE_NEVER_APPLICATION_CARD_PART2 = "quickcode.info.annotation_note_never_application_card_part2";
	private static final String MESSAGE_KEY_YEAR = "quickcode.info.annotation_note_year";
	private static final String MESSAGE_KEY_MONTH = "quickcode.info.annotation_note_month";
	private static final String MESSAGE_KEY_DATE = "quickcode.info.annotation_note_date";

	private static final String DEFAULT_CONTENT_TYPE = "text/json; charset=UTF-8";

	private JSONObject annotationToJSON(JSONObject inputJSON, Annotation annotation) {
		JSONObject result = inputJSON;
		if (result == null)
			result = new JSONObject();
		if (annotation == null)
			return result;
		result.put(Annotation.KEY_IDN_BAN, annotation.getIdnBan());
		// result.put(Annotation.KEY_IDN_MARK, annotation.getIdnMark());
		result.put(Annotation.KEY_MAINCODE, annotation.getMaincode());
		result.put(Annotation.KEY_SUBCODE, annotation.getSubcode());
		// result.put(Annotation.KEY_SOURCE, annotation.getSource());
		result.put(Annotation.KEY_SOURCE_BANK, annotation.getSourceBank());
		result.put(Annotation.KEY_DATA_YYY, annotation.getDataYyy());
		result.put(Annotation.KEY_DATA_MM, annotation.getDataMm());
		result.put(Annotation.KEY_DATA_DD, annotation.getDataDd());
		result.put(Annotation.KEY_NOTE, annotation.getNote());
		result.put(Annotation.KEY_DOWNTYPE, annotation.getDowntype());
		result.put(Annotation.KEY_DOWN_YYY, annotation.getDownYyy());
		result.put(Annotation.KEY_DOWN_MM, annotation.getDownMm());
		result.put(Annotation.KEY_DOWN_DD, annotation.getDownDd());
		result.put(Annotation.KEY_BANK_CODE, annotation.getBankCode());
		result.put(Annotation.KEY_ACCOUNT_NUM, annotation.getAccountNum());
		result.put(Annotation.KEY_BEG_YYY, annotation.getBegYyy());
		result.put(Annotation.KEY_BEG_MM, annotation.getBegMm());
		result.put(Annotation.KEY_END_YYY, annotation.getEndYyy());
		result.put(Annotation.KEY_END_MM, annotation.getEndMm());
		return result;
	}

	private JSONObject annotationRecordToJSON(JSONObject inputJSON, AnnotationRecord annotationRecord) {
		JSONObject result = inputJSON;
		if (result == null)
			result = new JSONObject();
		if (annotationRecord == null)
			return result;
		result.put(AnnotationRecord.KEY_STATUS, annotationRecord.getStatus());
		result.put(AnnotationRecord.KEY_DEL_REASON, annotationRecord.getDelReason());
		result.put(AnnotationRecord.KEY_NOTE_SIGNATURE, annotationRecord.getNoteSignature());
		return result = annotationToJSON(result, annotationRecord);
	}

	private Annotation jsonToAnnotation(JSONObject inputJSON) {
		if (inputJSON == null)
			return null;
		Annotation result = new Annotation();
		result.setIdnBan(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_IDN_BAN));
		// result.setIdnMark(JSONUtility.getStringParameter(inputJSON,
		// Annotation.KEY_IDN_MARK));
		result.setMaincode(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_MAINCODE));
		result.setSubcode(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_SUBCODE));
		// result.setSource(JSONUtility.getStringParameter(inputJSON,
		// Annotation.KEY_SOURCE));
		result.setSourceBank(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_SOURCE_BANK));
		result.setDataYyy(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_DATA_YYY));
		result.setDataMm(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_DATA_MM));
		result.setDataDd(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_DATA_DD));
		result.setNote(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_NOTE));
		result.setDowntype(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_DOWNTYPE));
		result.setDownYyy(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_DOWN_YYY));
		result.setDownMm(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_DOWN_MM));
		result.setDownDd(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_DOWN_DD));
		result.setBankCode(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_BANK_CODE));
		result.setAccountNum(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_ACCOUNT_NUM));
		result.setBegYyy(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_BEG_YYY));
		result.setBegMm(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_BEG_MM));
		result.setEndYyy(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_END_YYY));
		result.setEndMm(JSONUtility.getStringParameter(inputJSON, Annotation.KEY_END_MM));
		return result;
	}

	@SuppressWarnings("unchecked")
	private EndUserServiceResult doAnnotationInfo(RequestWrapper request) {
		String method = "doAnnotationInfo";
		Log.debug(this, method, "invoked.");
		EndUserServiceResult result = new EndUserServiceResult();
		Map<String, Object> outputResult = new HashMap<String, Object>();
		result.setOutputResult(outputResult);

		// Check Session exist
		EndUser endUser = this.getSessionUser(request);
		if (endUser == null) {
			Log.error(this, method, "Login User not found");
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_ANNOTATION_NOT_LOGIN));
			return result;
		}
		LoginSessionControl.updateLoginUser(request.getSession(false), endUser);
		result.setUser(endUser);
		result.setCertType(endUser.getCertType());
		// set output result user
		outputResult.put("user", endUser);

		// set custom message
		JSONObject requestPacket = new JSONObject();
		String nowMinguoDate = new MyDate().getMinguoDateString();
		requestPacket.put(KEY_DAO_METHOD, DAO_METHOD_QUERY_NOT_EXPIRED_ANNOTATION);
		requestPacket.put(AnnotationDao.KEY_IDN_BAN, endUser.getUserIdentification());
		requestPacket.put(AnnotationDao.KEY_DOWN_YYY, nowMinguoDate.substring(0, 3));
		requestPacket.put(AnnotationDao.KEY_DOWN_MM, nowMinguoDate.substring(3, 5));
		requestPacket.put(AnnotationDao.KEY_DOWN_DD, nowMinguoDate.substring(5, 7));
		// connect to the internal system
		result = connectToInternal(result, requestPacket);
		if (result != null) {
			Object resultObject = result.getOutputResult();
			if (resultObject != null && new HashMap<String, Object>().getClass().isInstance(resultObject)) {
				outputResult = (Map<String, Object>) result.getOutputResult();
				if (outputResult != null) {
					Object annotationListObject = outputResult.get(KEY_ANNOTATION_LIST);
					if (annotationListObject != null
							&& new LinkedList<Annotation>().getClass().isInstance(annotationListObject))
						this.setSessionInfo(request, ANNOTATION_INFO_SERVICE_NAME, annotationListObject);
				}
			}
		}
		return result;
	}

	private EndUserServiceResult doAnnotationCreateInput(RequestWrapper request) {
		String method = "doAnnotationCreateInput";
		Log.debug(this, method, "invoked.");
		EndUserServiceResult result = new EndUserServiceResult();
		Map<String, Object> outputResult = new HashMap<String, Object>();
		result.setOutputResult(outputResult);
		UserErrorInfo errorInfo = new UserErrorInfo();

		// Check Session exist
		EndUser endUser = this.getSessionUser(request);
		if (endUser == null) {
			Log.error(this, method, "Login User not found");
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_ANNOTATION_NOT_LOGIN));
			return result;
		}
		LoginSessionControl.updateLoginUser(request.getSession(false), endUser);
		result.setUser(endUser);
		result.setCertType(endUser.getCertType());
		// set output result user
		outputResult.put("user", endUser);

		// get input parameter
		@SuppressWarnings("unchecked")
		List<Annotation> annotationList = this.getSessionInfo(request, ANNOTATION_INFO_SERVICE_NAME,
				new LinkedList<Annotation>().getClass());
		// check input parameter
		if (annotationList != null && !annotationList.isEmpty()) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_NOT_EMPTY_ERROR, "annotationList should be empty", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// set output result
		result.setResultFlag(true);
		outputResult.put("reasons", Annotation.SUBCODE_ALLOWABLE_KEYS);
		return result;
	}

	private EndUserServiceResult doAnnotationCreate(RequestWrapper request) {
		String method = "doAnnotationCreate";
		Log.debug(this, method, "invoked.");
		EndUserServiceResult result = new EndUserServiceResult();
		Map<String, Object> outputResult = new HashMap<String, Object>();
		result.setOutputResult(outputResult);
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Add by 何政東, 20190107, catalog for online annotation
		result.setCatalog(Transaction.CATALOG_ONLINE_ANNOTATION);
		// Check Session exist
		EndUser endUser = this.getSessionUser(request);
		if (endUser == null) {
			Log.error(this, method, "Login User not found");
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_ANNOTATION_NOT_LOGIN));
			return result;
		}
		LoginSessionControl.updateLoginUser(request.getSession(false), endUser);
		result.setUser(endUser);
		result.setCertType(endUser.getCertType());
		// set output result user
		outputResult.put("user", endUser);
		// get input parameter
		String idn = StringUtils.trimToNull(request.getStringParameter(KEY_IDN, null));
		String note_signature = StringUtils.trimToNull(request.getStringParameter(KEY_ANNOTATION_NOTE_SIGNATURE, null));
		String reason = StringUtils.trimToNull(request.getStringParameter(KEY_ANNOTATION_CREATE_REASON, null));
		String maincode = StringUtils.trimToNull(request.getStringParameter(KEY_ANNOTATION_MAINCODE, null));
		String down_yyy = null;
		String down_mm = null;
		String down_dd = null;
		String change_yyy = null;
		String change_mm = null;
		String change_dd = null;
		String downtype = Annotation.DOWNTYPE_UNLIMITED;
		int detail_item = request.getIntParameter(KEY_ANNOTATION_DETAIL_ITEM, 0);
		String note = null;
		// check input parameter
		if (!idn.equals(endUser.getUserIdentification())) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "invalid IDN", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (detail_item == 1) {
			note = LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_NOTE_VICTIM, null);
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR,
					"get message properties:" + MESSAGE_KEY_NOTE_VICTIM + " failed", null);
		} else if (detail_item == 2) {
			change_yyy = StringUtils.trimToNull(request.getStringParameter(KEY_CHANGE_YEAR, null));
			change_mm = StringUtils.trimToNull(request.getStringParameter(KEY_CHANGE_MONTH, null));
			change_dd = StringUtils.trimToNull(request.getStringParameter(KEY_CHANGE_DATE, null));
			MyDate changeTime = MyDate.parseMinguoDateString(change_yyy + change_mm + change_dd);
			if (changeTime == null || changeTime.getTime() > new MyDate().getTime()) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "Input Date is invalid", null);
				Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
						+ "), Message=" + errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
				result.setErrorInfo(errorInfo);
				return result;
			}
			note = LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_NOTE_ID_CARD_CHANGED_PART_1, null);
			note += change_yyy + LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_YEAR, null);
			note += change_mm + LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_MONTH, null);
			note += change_dd + LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_DATE, null);
			note += LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_NOTE_ID_CARD_CHANGED_PART_2, null);
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR,
					"get message properties:" + MESSAGE_KEY_NOTE_ID_CARD_CHANGED_PART_1 + " or " + MESSAGE_KEY_YEAR
							+ " or " + MESSAGE_KEY_MONTH + " or " + MESSAGE_KEY_DATE + " or "
							+ MESSAGE_KEY_NOTE_ID_CARD_CHANGED_PART_2 + " failed",
					null);
		} else if (detail_item == 3) {
			note = LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_NOTE_FINANCIAL_CARD_CHECK, null);
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR,
					"get message properties:" + MESSAGE_KEY_NOTE_FINANCIAL_CARD_CHECK + " failed", null);
		} else if (detail_item == 4) {
			note = LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_NOTE_NEVER_APPLICATION_CARD_FOREVER, null);
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR,
					"get message properties:" + MESSAGE_KEY_NOTE_NEVER_APPLICATION_CARD_FOREVER + " failed", null);
		} else if (detail_item == 5) {
			down_yyy = StringUtils.trimToNull(request.getStringParameter(KEY_TIME_LIMIT_YEAR, null));
			down_mm = StringUtils.trimToNull(request.getStringParameter(KEY_TIME_LIMIT_MONTH, null));
			down_dd = StringUtils.trimToNull(request.getStringParameter(KEY_TIME_LIMIT_DATE, null));
			MyDate downTime = MyDate.parseMinguoDateString(down_yyy + down_mm + down_dd);
			if (downTime == null || downTime.getTime() < new MyDate().getTime()) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "Input Date is invalid", null);
				Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
						+ "), Message=" + errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
				result.setErrorInfo(errorInfo);
				return result;
			}
			downtype = Annotation.DOWNTYPE_LIMITED;
			note = LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_NOTE_NEVER_APPLICATION_CARD_PART1, null);
			note += down_yyy + LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_YEAR, null);
			note += down_mm + LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_MONTH, null);
			note += down_dd + LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_DATE, null);
			note += LocaleResource.getLocaleMesasge(null, MESSAGE_KEY_NOTE_NEVER_APPLICATION_CARD_PART2, null);
			// set down date to next day
			downTime = downTime.getNextDateBeginTime();
			String nextMinguoDateString = downTime.getMinguoDateString();
			down_yyy = nextMinguoDateString.substring(0, 3);
			down_mm = nextMinguoDateString.substring(3, 5);
			down_dd = nextMinguoDateString.substring(5, 7);
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR,
					"get message properties:" + MESSAGE_KEY_NOTE_NEVER_APPLICATION_CARD_PART1 + " or "
							+ MESSAGE_KEY_YEAR + " or " + MESSAGE_KEY_MONTH + " or " + MESSAGE_KEY_DATE + " or "
							+ MESSAGE_KEY_NOTE_NEVER_APPLICATION_CARD_PART2 + " failed",
					null);
		} else {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "detail_item is invalid", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// set output result detail item
		outputResult.put("detailItem", detail_item);
		// get input note
		String signNote = request.getStringParameter(KEY_ANNOTATION_NOTE, null);
		if (StringUtils.isBlank(note) || note.indexOf("null") >= 0) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (StringUtils.isBlank(signNote) || !signNote.equals(note)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "Note not equals to SignNote", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// set output result note
		outputResult.put("note", note);
		// Setup TWCA PKI Security Module
		TwcaPkiProvider twcaSecurity = null;
		ErrorInfo error = new ErrorInfo();
		try {
			twcaSecurity = new TwcaPkiProvider(error);
		} catch (Exception ex) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_SIGNATURE_VERIFY_ERROR,
					"Failure to get security class instance", null);
			Log.error(this, method,
					"Setup TWCA Security Error(" + errorInfo.getErrorCode() + "), Message="
							+ errorInfo.getSubErrorMessage() + ", InternalErrorCode(" + error.getErrorCode() + "), "
							+ "InternalErrorMessage(" + error.getErrorMessage() + ")");
			Log.error(this, method, ex);
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			result.setErrorMessage("quickcode.error.input.signature_verify_failed");
			return result;
		}
		// verify signature
		if (!twcaSecurity.verifyPKCS7Signature(note_signature, idn + signNote, error)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_SIGNATURE_VERIFY_ERROR,
					"Failure to verify PKCS7 signature", null);
			Log.error(this, method,
					"TWCA Security Error(" + errorInfo.getErrorCode() + "), Message=" + errorInfo.getSubErrorMessage()
							+ ", InternalErrorCode(" + error.getErrorCode() + "), " + "InternalErrorMessage("
							+ error.getErrorMessage() + ")");
			result.setResultFlag(false);
			result.setErrorInfo(errorInfo);
			result.setErrorMessage("quickcode.error.input.signature_verify_failed");
			return result;
		}
		// set entity
		String nowMinguoDate = new MyDate().getMinguoDateString();
		Annotation annotation = new Annotation();
		annotation.setIdnBan(endUser.getUserIdentification());
		// annotation.setIdnMark(Annotation.IDN_MARK_DEFAULT);
		annotation.setMaincode(maincode);
		annotation.setSubcode(reason);
		// annotation.setSource(Annotation.SOURCE_DEFAULT);
		annotation.setSourceBank(endUser.getUserIdentification());
		annotation.setDataYyy(nowMinguoDate.substring(0, 3));
		annotation.setDataMm(nowMinguoDate.substring(3, 5));
		annotation.setDataDd(nowMinguoDate.substring(5, 7));
		annotation.setNote(note);
		annotation.setDowntype(downtype);
		annotation.setDownYyy(down_yyy);
		annotation.setDownMm(down_mm);
		annotation.setDownDd(down_dd);
		if (!annotation.checkValidate()) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_ENTITY_PARAMETER_ERROR,
					"Annotation.checkValidate() failed", null);
			Log.error(this, method, "An Error Occurred, When Check Entity Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_entity_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		AnnotationRecord annotationRecord = annotation.convertToRecord();
		annotationRecord.setStatus(AnnotationRecord.STATUS_ADD);
		annotationRecord.setNoteSignature(note_signature.trim());
		if (!annotationRecord.checkValidate()) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_ENTITY_PARAMETER_ERROR,
					"AnnotationRecord.checkValidate() failed", null);
			Log.error(this, method, "An Error Occurred, When Check Entity Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_entity_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// set custom message
		JSONObject requestPacket = new JSONObject();
		requestPacket.put(KEY_DAO_METHOD, DAO_METHOD_INSERT);
		// set Annotation
		requestPacket = annotationToJSON(requestPacket, annotation);
		// set AnnotationRecord
		requestPacket = annotationRecordToJSON(requestPacket, annotationRecord);
		// connect to the internal system
		result = connectToInternal(result, requestPacket);
		return result;
	}

	private EndUserServiceResult doAnnotationRevokeInput(RequestWrapper request) {
		String method = "doAnnotationRevokeInput";
		Log.debug(this, method, "invoked.");
		EndUserServiceResult result = new EndUserServiceResult();
		Map<String, Object> outputResult = new HashMap<String, Object>();
		result.setOutputResult(outputResult);
		UserErrorInfo errorInfo = new UserErrorInfo();
		// get input parameter
		@SuppressWarnings("unchecked")
		List<Annotation> annotationList = this.getSessionInfo(request, ANNOTATION_INFO_SERVICE_NAME,
				new LinkedList<Annotation>().getClass());
		// check input parameter
		if (annotationList == null || annotationList.isEmpty()) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "annotationList is empty", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// set annotation list from session
		outputResult.put(KEY_ANNOTATION_LIST, annotationList);
		// set annotation list in session
		this.setSessionInfo(request, ANNOTATION_REVOKE_INPUT_SERVICE_NAME, annotationList);
		// Check Session exist
		EndUser endUser = this.getSessionUser(request);
		if (endUser == null) {
			Log.error(this, method, "Login User not found");
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_ANNOTATION_NOT_LOGIN));
			return result;
		}
		LoginSessionControl.updateLoginUser(request.getSession(false), endUser);
		result.setUser(endUser);
		result.setCertType(endUser.getCertType());
		// set output result user
		outputResult.put("user", endUser);
		// set output result
		result.setResultFlag(true);
		outputResult.put("reasons", AnnotationRecord.DEL_REASON_ALLOWABLE_KEYS);
		return result;
	}

	private EndUserServiceResult doAnnotationRevoke(RequestWrapper request) {
		String method = "doAnnotationRevoke";
		Log.debug(this, method, "invoked.");
		EndUserServiceResult result = new EndUserServiceResult();
		Map<String, Object> outputResult = new HashMap<String, Object>();
		result.setOutputResult(outputResult);
		UserErrorInfo errorInfo = new UserErrorInfo();
		// Add by 何政東, 20190107, catalog for online annotation
		result.setCatalog(Transaction.CATALOG_ONLINE_ANNOTATION);
		// Check Session exist
		EndUser endUser = this.getSessionUser(request);
		if (endUser == null) {
			Log.error(this, method, "Login User not found");
			result.setResultFlag(false);
			result.setErrorInfo(new UserErrorInfo(UserErrorInfo.ERROR_CODE_ANNOTATION_NOT_LOGIN));
			return result;
		}
		LoginSessionControl.updateLoginUser(request.getSession(false), endUser);
		result.setUser(endUser);
		result.setCertType(endUser.getCertType());
		// set output result user
		outputResult.put("user", endUser);

		// get input parameter
		@SuppressWarnings("unchecked")
		List<Annotation> SessionAnnotationList = this.getSessionInfo(request, ANNOTATION_REVOKE_INPUT_SERVICE_NAME,
				new LinkedList<Annotation>().getClass());
		String note_signature = StringUtils.trimToNull(request.getStringParameter(KEY_ANNOTATION_NOTE_SIGNATURE, null));
		Log.info(this, method, "note_signature:" + note_signature);
		String reason = StringUtils.trimToNull(request.getStringParameter(KEY_ANNOTATION_REVOKE_REASON, null));
		// check input parameter
		if (StringUtils.isBlank(note_signature)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "note_signature is empty", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		String[] note_signature_array = null;
		try {
			note_signature_array = note_signature.split(",");
		} catch (Exception e) {
			Log.error(this, method, "Exception:" + e.getMessage());
			Log.error(this, method, e);
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "note_signature not in a correct format",
					null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (note_signature_array == null || note_signature_array.length != SessionAnnotationList.size()) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "incomplete note_signature", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (StringUtils.isBlank(reason)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "reason is empty", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (SessionAnnotationList == null || SessionAnnotationList.isEmpty()) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "SessionAnnotationList is empty", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// set output result annotation list
		outputResult.put("annotationList", SessionAnnotationList);
		// MyDate now = new MyDate();
		JSONArray annotationList = new JSONArray();
		JSONArray annotationRecordList = new JSONArray();
		for (int i = 0; i < SessionAnnotationList.size(); i++) {
			// package Annotation and AnnotationRecord Entity
			JSONObject annotationJSONObject = new JSONObject();
			JSONObject annotationRecordJSONObject = new JSONObject();
			Annotation annotation = SessionAnnotationList.get(i);
			// Setup TWCA PKI Security Module
			TwcaPkiProvider twcaSecurity = null;
			ErrorInfo error = new ErrorInfo();
			try {
				twcaSecurity = new TwcaPkiProvider(error);
			} catch (Exception ex) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_SIGNATURE_VERIFY_ERROR,
						"Failure to get security class instance", null);
				Log.error(this, method,
						"Setup TWCA Security Error(" + errorInfo.getErrorCode() + "), Message="
								+ errorInfo.getSubErrorMessage() + ", InternalErrorCode(" + error.getErrorCode() + "), "
								+ "InternalErrorMessage(" + error.getErrorMessage() + ")");
				Log.error(this, method, ex);
				result.setResultFlag(false);
				result.setErrorInfo(errorInfo);
				result.setErrorMessage("quickcode.error.input.signature_verify_failed");
				return result;
			}
			// verify signature
			if (!twcaSecurity.verifyPKCS7Signature(note_signature_array[i].trim(),
					annotation.getIdnBan() + annotation.getNote(), error)) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_SIGNATURE_VERIFY_ERROR,
						"Failure to verify PKCS7 signature", null);
				Log.error(this, method,
						"TWCA Security Error(" + errorInfo.getErrorCode() + "), Message="
								+ errorInfo.getSubErrorMessage() + ", InternalErrorCode(" + error.getErrorCode() + "), "
								+ "InternalErrorMessage(" + error.getErrorMessage() + ")");
				result.setResultFlag(false);
				result.setErrorInfo(errorInfo);
				result.setErrorMessage("quickcode.error.input.signature_verify_failed");
				return result;
			}
			// annotation.setDownYyy(String.valueOf(now.getMinguoYear()));
			// annotation.setDownMm(String.valueOf(now.getMonth() + 1));
			// annotation.setDownDd(String.valueOf(now.getDate()));
			if (!annotation.checkValidate()) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_ENTITY_PARAMETER_ERROR,
						"Annotation.checkValidate() failed", null);
				Log.error(this, method, "An Error Occurred, When Check Entity Parameter(" + errorInfo.getErrorCode()
						+ "), Message=" + errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorMessage("quickcode.error.online_annotation_entity_parameter_error");
				result.setErrorInfo(errorInfo);
				return result;
			}
			AnnotationRecord annotationRecord = annotation.convertToRecord();
			annotationRecord.setStatus(AnnotationRecord.STATUS_DELETE);
			annotationRecord.setDelReason(reason);
			annotationRecord.setNoteSignature(note_signature_array[i].trim());
			if (!annotationRecord.checkValidate()) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_ENTITY_PARAMETER_ERROR,
						"AnnotationRecord.checkValidate() failed", null);
				Log.error(this, method, "An Error Occurred, When Check Entity Parameter(" + errorInfo.getErrorCode()
						+ "), Message=" + errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorMessage("quickcode.error.online_annotation_entity_parameter_error");
				result.setErrorInfo(errorInfo);
				return result;
			}
			// set Annotation to JSON Object
			annotationJSONObject = annotationToJSON(annotationJSONObject, annotation);
			annotationList.put(annotationJSONObject);
			// set AnnotationRecord to JSON Object
			annotationRecordJSONObject = annotationRecordToJSON(annotationJSONObject, annotationRecord);
			annotationRecordList.put(annotationRecordJSONObject);
		}
		// set custom message
		JSONObject requestPacket = new JSONObject();
		requestPacket.put(KEY_DAO_METHOD, DAO_METHOD_REVOKE);
		requestPacket.put(KEY_ENTITY_ANNOTATION_LIST, annotationList);
		requestPacket.put(KEY_ENTITY_ANNOTATION_RECORD_LIST, annotationRecordList);
		// connect to the internal system
		result = connectToInternal(result, requestPacket);
		return result;
	}

	@SuppressWarnings("unchecked")
	private EndUserServiceResult connectToInternal(EndUserServiceResult result, JSONObject requestPacket) {
		String method = "connectToInternal";
		UserErrorInfo errorInfo = new UserErrorInfo();
		Map<String, Object> outputResult = null;
		if (result != null) {
			Object resultObject = result.getOutputResult();
			if (resultObject != null && new HashMap<String, Object>().getClass().isInstance(resultObject))
				outputResult = (Map<String, Object>) result.getOutputResult();
			else {
				outputResult = new HashMap<String, Object>();
				result.setOutputResult(outputResult);
			}
		} else {
			result = new EndUserServiceResult();
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PARAMETER_ERROR, "result is null", null);
			Log.error(this, method, "An Error Occurred, When Check Input Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_parameter_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		String authWord = null;
		try {
			authWord = SysParameterPersistence.getInstance().getSystemParameterByKey("API_AUTH").getValue();
		} catch (Exception e) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR,
					"get system parameter:" + SYSTEM_PARAMETER_KEY_API_AUTH + " failed", null);
			Log.error(this, method, "An Error Occurred, When Get System Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_internal_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		if (StringUtils.isBlank(authWord)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR,
					"get system parameter:" + SYSTEM_PARAMETER_KEY_API_AUTH + " failed", null);
			Log.error(this, method, "An Error Occurred, When Get System Parameter(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_internal_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		String nowDateTimeMilliString = new MyDate().getDateTimeMilliString();
		String verify = nowDateTimeMilliString + authWord;
		String verifyHash = CipherProvider.getInstance().messageHashBase64(2, verify.getBytes(StandardCharsets.UTF_8));
		requestPacket.put(KEY_TIMESTAMP, nowDateTimeMilliString);
		requestPacket.put(KEY_AUTHWORD, verifyHash);
		Log.debug(this, method, "requestPacket.toString = " + requestPacket.toString());
		// send post request
		String ip = SystemProperties.getInstance().getStringProperty(PROPERTY_ANNOTATION_SERVICE_IP, null);
		if (StringUtils.isBlank(ip)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR,
					"get property:" + PROPERTY_ANNOTATION_SERVICE_IP + " failed", null);
			Log.error(this, method, "An Error Occurred, When Get Properties(" + errorInfo.getErrorCode() + "), Message="
					+ errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_internal_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		String url = SystemProperties.getInstance().getStringProperty(PROPERTY_ANNOTATION_SERVICE_URL, null);
		if (StringUtils.isBlank(url)) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR,
					"get property:" + PROPERTY_ANNOTATION_SERVICE_URL + " failed", null);
			Log.error(this, method, "An Error Occurred, When Get Properties(" + errorInfo.getErrorCode() + "), Message="
					+ errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_internal_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		try {
			url = String.format(url, ip);
		} catch (Exception e) {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_PROPERTY_ERROR, "insert property:"
					+ PROPERTY_ANNOTATION_SERVICE_IP + " into property:" + PROPERTY_ANNOTATION_SERVICE_URL + " failed",
					null);
			Log.error(this, method, "An Error Occurred, When Format String Properties(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			Log.error(this, method, e);
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_internal_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		Log.debug(this, method, "post url :" + url);
		HttpClient httpClient = new HttpClient(url);
		httpClient.sendRequest(requestPacket.toString(), DEFAULT_CONTENT_TYPE, null);
		// Modify by 何政東, 20181107, Remove validate content-type
		// get response
		// String contentType = httpClient.getResponseContentType();
		// check content type
		// if (contentType != null && contentType.equals(DEFAULT_CONTENT_TYPE)) {
		String content = httpClient.getStringResponse();
		Log.debug(this, method, "response content:" + content);
		// check content
		if (!StringUtils.isBlank(content)) {
			JSONObject responsePacket = null;
			try {
				responsePacket = new JSONObject(content);
			} catch (Exception e) {
				errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_INTERNAL_ERROR, "response not a json format", null);
				Log.error(this, method, "An Internal System Error Occurred, When Internal Processes("
						+ errorInfo.getErrorCode() + "), Message=" + errorInfo.getSubErrorMessage());
				result.setResultFlag(false);
				result.setErrorMessage("quickcode.error.online_annotation_internal_error");
				result.setErrorInfo(errorInfo);
				return result;
			}
			String statusCode = JSONUtility.getStringParameter(responsePacket, StatusResponse.KEY_STATUS_CODE);
			String statusMessage = JSONUtility.getStringParameter(responsePacket, StatusResponse.KEY_STATUS_MESSAGE);
			// check status code
			if (!StringUtils.isBlank(statusCode) && statusCode.equals(StatusResponse.OK.getStatusCode())) {
				String dao_method = JSONUtility.getStringParameter(requestPacket, KEY_DAO_METHOD);
				if (StringUtils.isBlank(dao_method)) {
					errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_INTERNAL_ERROR, "dao_method is empty", null);
					Log.error(this, method, "An Internal System Error Occurred, When Internal Processes("
							+ errorInfo.getErrorCode() + "), Message=" + errorInfo.getSubErrorMessage());
					result.setResultFlag(false);
					result.setErrorMessage("quickcode.error.online_annotation_internal_error");
					result.setErrorInfo(errorInfo);
					return result;
				}
				if (dao_method.equalsIgnoreCase(DAO_METHOD_QUERY_NOT_EXPIRED_ANNOTATION)) {
					// get annotation list if exist
					JSONArray annotationListJSONArray = JSONUtility.getArrayParameter(responsePacket,
							KEY_ANNOTATION_LIST);
					List<Annotation> annotationList = null;
					if (annotationListJSONArray != null) {
						annotationList = new LinkedList<Annotation>();
						for (int i = 0; i < annotationListJSONArray.length(); i++)
							if (annotationListJSONArray.getJSONObject(i) != null) {
								JSONObject annotationListJSONObject = annotationListJSONArray.getJSONObject(i);
								// set response Annotation
								Annotation annotation = jsonToAnnotation(annotationListJSONObject);
								// add Annotation to list
								annotationList.add(annotation);
							}
					}
					if (annotationList != null) {
						// set output result annotation list
						result.setResultFlag(true);
						outputResult.put(KEY_ANNOTATION_LIST, annotationList);
						Log.debug(this, method, "annotationList.toString() = " + annotationList.toString());
					} else {
						errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_INTERNAL_ERROR, "annotationList is null",
								null);
						Log.error(this, method, "An Error Occurred, When Check Annotation List From Response Content("
								+ errorInfo.getErrorCode() + "), Message=" + errorInfo.getSubErrorMessage());
						result.setResultFlag(false);
						result.setErrorMessage("quickcode.error.online_annotation_internal_error");
						result.setErrorInfo(errorInfo);
						return result;
					}
				} else
					result.setResultFlag(true);
			} else {
				if (StringUtils.isBlank(statusCode)) {
					errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_INTERNAL_ERROR, "status response is empty", null);
					Log.error(this, method, "An Internal System Error Occurred, When Internal Processes("
							+ errorInfo.getErrorCode() + "), Message=" + errorInfo.getSubErrorMessage());
					result.setResultFlag(false);
					result.setErrorMessage("quickcode.error.online_annotation_internal_error");
					result.setErrorInfo(errorInfo);
					return result;
				} else {
					if (FormatCheckUtil.isNumber(statusCode)) {
						errorInfo.set(Integer.parseInt(statusCode), statusMessage, null);
						Log.error(this, method,
								"An Error Occurred, When Calling A Database Method:"
										+ DAO_METHOD_QUERY_NOT_EXPIRED_ANNOTATION + "(" + errorInfo.getErrorCode()
										+ "), Message=" + errorInfo.getSubErrorMessage());
						result.setResultFlag(false);
						result.setErrorMessage("quickcode.error.online_annotation_db_error");
						result.setErrorInfo(errorInfo);
						return result;
					} else {
						errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_INTERNAL_ERROR,
								"status code = " + statusCode + ", status message = " + statusMessage, null);
						Log.error(this, method, "An Internal System Error Occurred, When Internal Processes("
								+ errorInfo.getErrorCode() + "), Message=" + errorInfo.getSubErrorMessage());
						result.setResultFlag(false);
						result.setErrorMessage("quickcode.error.online_annotation_internal_error");
						result.setErrorInfo(errorInfo);
						return result;
					}
				}
			}
		} else {
			errorInfo.set(UserErrorInfo.ERROR_CODE_ANNOTATION_INTERNAL_ERROR, "content is empty", null);
			Log.error(this, method, "An Error Occurred, When Check Response Content(" + errorInfo.getErrorCode()
					+ "), Message=" + errorInfo.getSubErrorMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.online_annotation_internal_error");
			result.setErrorInfo(errorInfo);
			return result;
		}
		// } else {
		// errorInfo.set(
		// UserErrorInfo.ERROR_CODE_ANNOTATION_INTERNAL_ERROR, "contentType = "
		// + httpClient.getResponseContentType() + ", contentType should be:" +
		// DEFAULT_CONTENT_TYPE,
		// null);
		// Log.error(this, method, "An Error Occurred, When Check Response ContentType("
		// + errorInfo.getErrorCode()
		// + "), Message=" + errorInfo.getSubErrorMessage());
		// result.setResultFlag(false);
		// result.setErrorMessage("quickcode.error.online_annotation_internal_error");
		// result.setErrorInfo(errorInfo);
		// return result;
		// }
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.quickretrieval.jcic.server.action.EndUserBaseAction#doService(java.lang.
	 * String, javax.servlet.http.RequestWrapper,
	 * javax.servlet.http.ResponseWrapper)
	 */
	@Override
	protected EndUserServiceResult doService(String serviceName, RequestWrapper request, ResponseWrapper response) {
		EndUserServiceResult result = null;
		if (serviceName.equalsIgnoreCase(ANNOTATION_INFO_SERVICE_NAME)) {
			result = doAnnotationInfo(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(ANNOTATION_CREATE_INPUT_SERVICE_NAME)) {
			result = doAnnotationCreateInput(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(ANNOTATION_CREATE_SERVICE_NAME)) {
			result = doAnnotationCreate(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(ANNOTATION_REVOKE_INPUT_SERVICE_NAME)) {
			result = doAnnotationRevokeInput(request);
			return result;
		}
		if (serviceName.equalsIgnoreCase(ANNOTATION_REVOKE_SERVICE_NAME)) {
			result = doAnnotationRevoke(request);
			return result;
		}
		Log.error(this, "doService", "service(" + serviceName + ") not found");
		return null;
	}

}
