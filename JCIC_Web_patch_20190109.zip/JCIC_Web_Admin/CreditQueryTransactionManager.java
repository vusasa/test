/**
 * 
 */
package com.quickretrieval.jcic.server.action;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.oreilly.servlet.MultipartRequest;
import com.quickretrieval.common.utils.FileUtility;
import com.quickretrieval.common.utils.MyDate;
import com.quickretrieval.server.log.Log;
import com.quickretrieval.common.utils.XMLUtility;
import com.quickretrieval.jcic.report.datasource.CreditTransDataSource;
import com.quickretrieval.jcic.report.datasource.CreditTransStatisDataSource;
import com.quickretrieval.jcic.server.adapter.CreditReportPDFAdapter;
import com.quickretrieval.jcic.server.adapter.CreditReportProcedure;
import com.quickretrieval.jcic.server.adapter.ServerPDFAdapter;
import com.quickretrieval.jcic.server.control.JCICBaseAction;
import com.quickretrieval.jcic.server.control.JCICServiceResult;
import com.quickretrieval.jcic.server.db.ReasonDao;
import com.quickretrieval.jcic.server.db.TransactionPersistence;
import com.quickretrieval.jcic.server.entity.CreditReport;
import com.quickretrieval.jcic.server.entity.Reason;
import com.quickretrieval.jcic.server.entity.TransStatisRecord;
import com.quickretrieval.jcic.server.entity.Transaction;
import com.quickretrieval.server.adapter.DownloadFilePathGenerator;
import com.quickretrieval.server.adapter.JasperReportAdapter;
import com.quickretrieval.server.adapter.PageHandler;
import com.quickretrieval.server.adapter.TempFilePathGenerator;
import com.quickretrieval.server.control.RequestWrapper;
import com.quickretrieval.server.control.ResponseWrapper;
import com.quickretrieval.server.dao.QueryResult;
import com.quickretrieval.server.entity.User;
import com.quickretrieval.server.properties.SystemProperties;

/**
 * @author BruceHuang
 * 這個 Class 實現 信用報告交易管理 的各項操作功能業務邏輯
 */
public class CreditQueryTransactionManager extends JCICBaseAction {
	
	/**
	 * Default Serialized Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	private static final String QUERY_CREDIT_TRANSACITON_INPUT_SERVICE_NAME = "QueryCreditTransactionInput.do";
	private static final String STATISTIC_CREDIT_TRANSACTION_SERVICE_NAME = "StatisCreditTransaction.do";
	private static final String PRINT_STATISTIC_CREDIT_TRANSACTION_SERVICE_NAME = "PrintStatisCreditTransaction.do";
	private static final String QUERY_CREDIT_TRANSACTION_SERVICE_NAME = "QueryCreditTransaction.do";
	private static final String QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME = "QueryCreditTransactionPage.do";
	private static final String PRINT_CREDIT_TRANSACTION_SERVICE_NAME = "PrintCreditTransaction.do";
	private static final String SHOW_CREDIT_TRANSACTION_INFO_SERVICE_NAME = "ShowCreditTransactionInfo.do";
	private static final String PRINT_CREDIT_TRANSACTION_INFO_SERVICE_NAME = "PrintCreditTransactionInfo.do";
	private static final String EXPORT_CREDIT_TRANSACTION_SERVICE_NAME = "ExportCreditTransaction.do";
	private static final String REMOVE_CREDIT_TRANSACTION_SERVICE_NAME = "RemoveCreditTransaction.do";
	private static final String IMPORT_CREDIT_TRANSACTION_SERVICE_NAME = "ImportCreditTransaction.do";	
	private static final String GET_CREDIT_REPORT_PDF_SERVICE_NAME = "GetCreditReportPDF.do";
	
	// System Properties
	private static final String PROPERTY_EXPORT_PATH = "download.exports";
	private static final String PROPERTY_IMPORT_PATH = "upload.imports";
	// Export/Import XML Tag Definition
	private static final String TAG_DOCUMENT = "CREDIT_TRANSACTION";
	private static final String TAG_TRANSACTION = "TRANSACTION";
	private static final String TAG_INPUT = "INPUT";
	private static final String TAG_OUTPUT = "OUTPUT";
	private static final String TAG_DATALINK = "DATALINK";
	private static final String TAG_CERTIFICATE = "CERTIFICATE";
	private static final String TAG_SIGNATURE = "SIGNATURE";
	// Export/Import XML Attribute Definition
	private static final String ATTR_TIME = "time";
	private static final String ATTR_CATALOG = "catalog";
	private static final String ATTR_USER_TYPE = "user_type";
	private static final String ATTR_USER_ID = "user_id";
	private static final String ATTR_FUNCTION = "function";
	private static final String ATTR_RESULT = "result";
	private static final String ATTR_CERT_TYPE = "cert_type";
	private static final String ATTR_CERT_SERIAL = "cert_serial";
	private static final String ATTR_CERT_ISSUER = "cert_issuer";
	private static final String ATTR_CERT_SUBJECT = "cert_subject";
	private static final String ATTR_CERT_EXPIRE_TIME = "cert_expire_time";
	
	private static final String QUERY_REPORT_TEMPLATE = "CreditTransListReport.jasper";
	private static final String DETAIL_REPORT_TEMPLATE = "CreditDetailReport.jasper";
	private static final String STATIS_REPORT_TEMPLATE = "CreditTranStatisReport.jasper";
	private static final String PROPERTY_DOWNLOAD_REPORT_PATH = "Report.Download.path";
	
	private static final String FUNCTION_CREDIT_REPORT_GENERATE = "CreditReportGenerate.do";
	private static final String FUNCTION_CREDIT_REPORT_DECRYPT = "CreditQueryReportRead.do";
	private static final String FUNCTION_CREDIT_REPORT_LOGIN = "CreditQueryLogin.do";
	
	// Request Parameter
	private static final String PARAMETER_USER_ID = "user_id";
	private static final String PARAMETER_SERVICE_NAME = "service_name";
	private static final String PARAMETER_RESULT = "result";
	private static final String PARAMETER_DEVICE_TYPE = "device_type";
	private static final String PARAMETER_CERTIFICATE_TYPE = "cert_type";
	private static final String PARAMETER_REASON = "reason";
	private static final String PARAMETER_REMARK = "remark";
	private static final String PARAMETER_BEGIN_DATE = "begin_date";
	private static final String PARAMETER_END_DATE = "end_date";
	private static final String PARAMETER_BEGIN_TIME = "begin_time";
	private static final String PARAMETER_END_TIME = "end_time";
	private static final String PARAMETER_TRANSACTION_ID = "transactionID";
	private static final String PARAMETER_TRANSACTION_DATE = "transaction_date";
	private static final String PARAMETER_PAGE_NUMBER = "pageNumber";

	// Request Parameter Constant Define
	private static final String RESULT_VALUE_ALL = "all";
	private static final String RESULT_VALUE_SUCCEED = "succeed";
	private static final String RESULT_VALUE_FAILED = "failed";
	// Query PAGE Size Definition
	private static final int	DEFAULT_PAGE_SIZE = 20;
	private static final int	DEFAULT_LIST_PAGES = 5;
	// Input/Output Buffer Size
	private static final int	EXPORT_BUFFER_SIZE = 100;
	
	private void setSessionQueryInfo(String serviceName, RequestWrapper request, PageHandler page) {
		// Initial a Query Info
		Map<String, Object> queryInfo = 
				super.initialQueryInfo(serviceName, page);
		queryInfo.put(PARAMETER_USER_ID, request.getStringParameter(PARAMETER_USER_ID, null));
		queryInfo.put(PARAMETER_SERVICE_NAME, request.getStringParameter(PARAMETER_SERVICE_NAME, null));
		Integer device_type = (Integer)request.getIntParameter(PARAMETER_DEVICE_TYPE, -1);
		Integer cert_type = (Integer)request.getIntParameter(PARAMETER_CERTIFICATE_TYPE, 0);
		if (device_type >= 0) queryInfo.put(PARAMETER_DEVICE_TYPE, device_type);
		if (cert_type > 0) queryInfo.put(PARAMETER_CERTIFICATE_TYPE, cert_type);
		String result_str = request.getStringParameter(PARAMETER_RESULT, RESULT_VALUE_ALL);
		Boolean result = null;
		if (result_str.equalsIgnoreCase(RESULT_VALUE_SUCCEED)) {
			result = new Boolean(true);
		} else
		if (result_str.equalsIgnoreCase(RESULT_VALUE_FAILED)) {
			result = new Boolean(false);
		}
		if (result != null) queryInfo.put(PARAMETER_RESULT, result);
		MyDate toDay = new MyDate();
		queryInfo.put(PARAMETER_BEGIN_TIME, request.getDateTimeParameter(PARAMETER_BEGIN_DATE, PARAMETER_BEGIN_TIME, toDay.getDayBeginTime()));
		queryInfo.put(PARAMETER_END_TIME, request.getDateTimeParameter(PARAMETER_END_DATE, PARAMETER_END_TIME, toDay.getDayEndTime()));
		
		super.setSessionQueryInfo(request, queryInfo);
	}
	
	private Map<String, Object> getSessionQueryInfo(String serviceName, RequestWrapper request) {
		// QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME
		Map<String, Object> queryInfo = super.getSessionQueryInfo(request, serviceName);
		return queryInfo;
	}
	
	private String getSessionQueryInfoString(Map<String, Object> queryInfo) {
		String user_id = (String) queryInfo.get(PARAMETER_USER_ID);
		String service_name = (String) queryInfo.get(PARAMETER_SERVICE_NAME);
		Boolean trans_result = (Boolean) queryInfo.get(PARAMETER_RESULT);
		MyDate begin_time = (MyDate) queryInfo.get(PARAMETER_BEGIN_TIME);
		MyDate end_time = (MyDate) queryInfo.get(PARAMETER_END_TIME);
		Integer device_type = (Integer) queryInfo.get(PARAMETER_DEVICE_TYPE);
		Integer cert_type = (Integer) queryInfo.get(PARAMETER_CERTIFICATE_TYPE);
		return 	  PARAMETER_USER_ID+"="+(user_id==null?"":user_id)+"; "
				+ PARAMETER_SERVICE_NAME+"="+(service_name==null?"":service_name)+"; "
				+ PARAMETER_RESULT+"="+(trans_result==null?"":trans_result)+"; "
				+ PARAMETER_DEVICE_TYPE+"="+((device_type == null || device_type < 0)?"":device_type)+";"
				+ PARAMETER_CERTIFICATE_TYPE+"="+((cert_type == null || cert_type <= 0)?"":cert_type)+";"
				+ PARAMETER_BEGIN_DATE+"="+(begin_time==null?"":begin_time.getDateTimeDisplay())+"; "
				+ PARAMETER_END_DATE+"="+(end_time==null?"":end_time.getDateTimeDisplay());
	}
	/*
	private void setSessionStatisInfo(RequestWrapper request, PageHandler page) {
		// Initial a Query Info
		Map<String, Object> queryInfo = 
				super.initialQueryInfo(STATISTIC_CREDIT_TRANSACTION_SERVICE_NAME, page);
		queryInfo.put(PARAMETER_USER_ID, request.getStringParameter(PARAMETER_USER_ID, null));
		queryInfo.put(PARAMETER_BEGIN_DATE, request.getBeginDateParameter(PARAMETER_BEGIN_DATE, new MyDate()));
		queryInfo.put(PARAMETER_END_DATE, request.getEndDateParameter(PARAMETER_END_DATE, new MyDate()));
		super.setSessionQueryInfo(request, queryInfo);
	}
	
	private Map<String, Object> getSessionStatisInfo(RequestWrapper request) {
		Map<String, Object> queryInfo = super.getSessionQueryInfo(request, STATISTIC_CREDIT_TRANSACTION_SERVICE_NAME);
		return queryInfo;
	}
	*/
	private <T> T getQueryInfoParameter(Map<String, Object> queryInfo, String parameter, T defaultValue, Class<T> objClass) {
		if (queryInfo == null || parameter == null) return defaultValue;
		Object obj = queryInfo.get(parameter);
		if (obj == null) return defaultValue;
		if (!objClass.isInstance(obj)) return defaultValue;
		@SuppressWarnings("unchecked")
		T value = (T) obj;
		return value;
	}
	
	private String getManagerReasonName(String reasonCode) {
		if (reasonCode == null) return null;
		Reason reason = ReasonDao.getInstance().getByCode(Reason.REASON_TYPE_MANAGEMENT_CREDIT_REPORT, reasonCode);
		if (reason == null) return null;
		return reason.getName()+"("+reason.getCode()+")";
	}
	
	private static final int	FIRST_YEAR = 2015;
	private static final int	MAX_STATIS_QUERY_CROSS_YEARS = 0;
	private static final int	TRANSACTION_KEEP_YEARS = 5;
	private static final int	MAX_QUERY_MONTHS_WITHOUT_ID = 2;
		
	/*
	 * 
	 */
	private JCICServiceResult doStatisCreditQueryTransaction(RequestWrapper request) {
		
		JCICServiceResult result = new JCICServiceResult();
		// Get Request Parameters
		String user_id = request.getStringParameter(PARAMETER_USER_ID, null);
		Integer device_type = request.getIntParameter(PARAMETER_DEVICE_TYPE, -1);
		Integer cert_type = request.getIntParameter(PARAMETER_CERTIFICATE_TYPE, 0);
		MyDate today = new MyDate();
		MyDate begin_time = request.getDateTimeParameter(PARAMETER_BEGIN_DATE, PARAMETER_BEGIN_TIME, today.getDayBeginTime());
		MyDate end_time = request.getDateTimeParameter(PARAMETER_END_DATE, PARAMETER_END_TIME, today.getDayEndTime());
		if (user_id != null) user_id = user_id.toUpperCase();
		// setup Input String
		result.setInputString(request.getParametersString());
		Log.debug(this, "doStatisCreditQueryTransaction", "input("+result.getInputString()+")");
		// Check Input Parameters
		if (begin_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.begin_time_invalid");
			return result;
		}
		if (end_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.end_time_invalid");
			return result;
		}
		// Initial PageHandler
		PageHandler page = new PageHandler(DEFAULT_PAGE_SIZE, DEFAULT_LIST_PAGES);
		setSessionQueryInfo(QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME, request, page);
		if (begin_time.getTime() > end_time.getTime()) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_time_duration_invalid");
			return result;
		}
		int nowYear = new MyDate().getYear(); 
		int firstQueryYear = nowYear - TRANSACTION_KEEP_YEARS + 1;
		if (firstQueryYear < FIRST_YEAR) firstQueryYear = FIRST_YEAR;
		if (begin_time.getYear() < firstQueryYear) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_begin_date_too_early");
			return result;
		}
		if (end_time.getYear() > nowYear) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_end_date_too_late");
			return result;
		}
		if (end_time.getYear() > (begin_time.getYear()+MAX_STATIS_QUERY_CROSS_YEARS)) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.statis_duration_cross_year");
			return result;
		}
		TransStatisRecord  total_record = TransactionPersistence.getInstance()
					.queryStatisticTotalByCondition(begin_time, end_time, Transaction.CATALOG_CREDIT_REPORT, 
								FUNCTION_CREDIT_REPORT_LOGIN, FUNCTION_CREDIT_REPORT_GENERATE, FUNCTION_CREDIT_REPORT_DECRYPT, 
								user_id, device_type, cert_type, null);
		if (total_record == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.database_access_failed");
			return result;
		}
		// Query Matched Credit Report Transaction
		QueryResult<TransStatisRecord> queryResult = 
				TransactionPersistence.getInstance()
						.queryStatisticByCondition(begin_time, end_time, Transaction.CATALOG_CREDIT_REPORT, 
								FUNCTION_CREDIT_REPORT_LOGIN, FUNCTION_CREDIT_REPORT_GENERATE, FUNCTION_CREDIT_REPORT_DECRYPT,
								user_id, device_type, cert_type, null);
		if (queryResult == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.database_access_failed");
			return result;
		}
		
		/*
		// Compute Total
		TransStatisRecord[] records = queryResult.getResult();
		TransStatisRecord   total_record = new TransStatisRecord();
		if (records != null) {
			for (int i = 0; i < records.length; i++) {
				TransStatisRecord record = records[i];
				if (record == null) continue;
				total_record.setLoginSucceedCount(total_record.getLoginSucceedCount()+record.getLoginSucceedCount());
				total_record.setLoginFailedCount(total_record.getLoginFailedCount()+record.getLoginFailedCount());
				total_record.setLoginUsers(total_record.getLoginUsers()+record.getLoginUsers());
				total_record.setReportSucceedCount(total_record.getReportSucceedCount()+record.getReportSucceedCount());
				total_record.setReportFailedCount(total_record.getReportFailedCount()+record.getReportFailedCount());
				total_record.setReportUsers(total_record.getReportUsers()+record.getReportUsers());
			}
		}
		*/
		
		// Setup the Query Information into Session
		page.bindPages(queryResult.getTotal(), 1);
		// setSessionQueryInfo(STATISTIC_CREDIT_TRANSACTION_SERVICE_NAME, request, page);

		// Set queried consents and page information to Result
		Map<String, Object> outputResult = new HashMap<String, Object>();
		outputResult.put("device", device_type);
		outputResult.put("cert_type", cert_type);
		outputResult.put("begin_time", begin_time.getDateTimeDisplay());
		outputResult.put("end_time", end_time.getDateTimeDisplay());
		outputResult.put("records", queryResult.getResult());
		outputResult.put("total", total_record);
		outputResult.put("page", page);
		result.setResultFlag(true);
		result.setOutputResult(outputResult);
		return result;
	}

	/*
	 * 
	 */
	private JCICServiceResult doPrintStatisticCreditQueryTransaction(RequestWrapper request) {
		
		JCICServiceResult result = new JCICServiceResult();
		// Get QueryInfo from Session
		Map<String, Object> queryInfo = getSessionQueryInfo(QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME, request);
		if (queryInfo == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.page_query_no_info");
			return result;
		}
		PageHandler page = super.getSessionQueryPage(queryInfo);
		if (page == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.page_query_no_page");
			return result;
		}
		getSessionQueryInfoString(queryInfo);
		// Get Query Condition from QueryInfo
		String user_id = this.getQueryInfoParameter(queryInfo, PARAMETER_USER_ID, null, String.class);
		Integer device_type = this.getQueryInfoParameter(queryInfo, PARAMETER_DEVICE_TYPE, -1, Integer.class);
		Integer cert_type = this.getQueryInfoParameter(queryInfo, PARAMETER_CERTIFICATE_TYPE, 0, Integer.class);
		MyDate begin_time = this.getQueryInfoParameter(queryInfo, PARAMETER_BEGIN_TIME, null, MyDate.class);
		MyDate end_time = this.getQueryInfoParameter(queryInfo, PARAMETER_END_TIME, null, MyDate.class);
		if (user_id != null) user_id = user_id.toUpperCase();
		// setup Input String
		result.setInputString(getSessionQueryInfoString(queryInfo));		
		// Check Request Parameters
		if (begin_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.begin_time_invalid");
			return result;
		}
		if (end_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.end_time_invalid");
			return result;
		}
		if (begin_time.getTime() > end_time.getTime()) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_time_duration_invalid");
			return result;
		}
		int nowYear = new MyDate().getYear();
		int firstQueryYear = nowYear - TRANSACTION_KEEP_YEARS + 1;
		if (firstQueryYear < FIRST_YEAR) firstQueryYear = FIRST_YEAR;
		if (begin_time.getYear() < firstQueryYear) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_begin_date_too_early");
			return result;
		}
		if (end_time.getYear() > nowYear) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_end_date_too_late");
			return result;
		}
		if (end_time.getYear() > (begin_time.getYear()+MAX_STATIS_QUERY_CROSS_YEARS)) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.statis_duration_cross_year");
			return result;
		}
		// Query Credit Transactions by input parameters.
		CreditTransStatisDataSource dataSource = new CreditTransStatisDataSource();
		if (!dataSource.getDataSourceByCondition(begin_time, end_time, Transaction.CATALOG_CREDIT_REPORT,
										 FUNCTION_CREDIT_REPORT_LOGIN, FUNCTION_CREDIT_REPORT_GENERATE, FUNCTION_CREDIT_REPORT_DECRYPT,
										 user_id, device_type, cert_type, null, null)) {
			// setup Input String
			Log.error(this, "doPrintStatisticCreditQueryTransaction", "getDataSourceCondition("+PARAMETER_USER_ID+"="+user_id
								 +", "+PARAMETER_DEVICE_TYPE+"="+device_type
								 +", "+PARAMETER_CERTIFICATE_TYPE+"="+cert_type
								 +", "+PARAMETER_BEGIN_TIME+"="+begin_time.getDateTimeDisplay()
								 +", "+PARAMETER_END_TIME+"="+end_time.getDateTimeDisplay()
								 +", Catalog="+Transaction.CATALOG_CREDIT_REPORT
								 +", Function="+FUNCTION_CREDIT_REPORT_GENERATE
								 +") failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.transaction_not_found");
			return result;
		}
		// Get Download Report Directory Path
		String reportFilePath = DownloadFilePathGenerator.getInstance().getDownloadFilePath();
		if (reportFilePath == null) {
			Log.error(this, "doPrintStatisticCreditQueryTransaction", "Generate download file path failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.export_report_pdf_failed");
			return result;
		}
		reportFilePath += ".pdf";
		// Create Report PDF for Consent Detail Information
		// Generate Report to Report File
		JasperReportAdapter reportAdapter = new JasperReportAdapter();
		reportAdapter.setLanguage("zh_TW");
		reportAdapter.setTemplate(STATIS_REPORT_TEMPLATE);
		if (!reportAdapter.fillReport(dataSource)) {
			Log.error(this, "doPrintStatisticCreditQueryTransaction", "fillReport failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.generate_report_failed");
			return result;
		}
		if (!reportAdapter.exportToPdfFile(reportFilePath)) {
			Log.error(this, "doPrintStatisticCreditQueryTransaction", "Export report to PDF failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.export_report_pdf_failed");
			return result;
		}
		reportAdapter.clean();
		String reportFileName = DownloadFilePathGenerator.getFileNameFromPath(reportFilePath);
		Log.debug(this, "doPrintStatisticCreditQueryTransaction", "PDF report generated.");
		this.setFileOwner(request, reportFileName, reportFileName, reportFileName, true);
		result.setResultFlag(true);
		result.setOutputResult(reportFileName);
		return result;				
	}

	private boolean getReportReadRight(RequestWrapper request) {
		return this.checkServiceAccessRight(request, GET_CREDIT_REPORT_PDF_SERVICE_NAME);
	}
	
	// Modify by 何政東, 20190107, Add transaction functions for online annotation
	private static final String[] CreditTransactionFunctions = {
		"CreditQueryLogin.do", "CreditQueryHistory.do", "CreditReportGenerate.do", "CreditQueryReportRead.do", "CreditQueryLogout.do",
		"SetupMailUpdate.do", "SetupMailDelete.do", "AnnotationCreate.do", "AnnotationRevoke.do"
	};

	private JCICServiceResult doQueryCreditQueryTransactionInput(RequestWrapper request) {
		JCICServiceResult result = new JCICServiceResult();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Map<String, Object> queryInfo = getSessionQueryInfo(QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME, request);
		if (queryInfo != null) {
			String user_id = (String) queryInfo.get(PARAMETER_USER_ID);
			String service_name = (String) queryInfo.get(PARAMETER_SERVICE_NAME);
			Boolean trans_result = (Boolean) queryInfo.get(PARAMETER_RESULT);
			MyDate begin_time = (MyDate) queryInfo.get(PARAMETER_BEGIN_TIME);
			MyDate end_time = (MyDate) queryInfo.get(PARAMETER_END_TIME);
			Integer device_type = (Integer) queryInfo.get(PARAMETER_DEVICE_TYPE);
			Integer cert_type = (Integer) queryInfo.get(PARAMETER_CERTIFICATE_TYPE);
			if (user_id != null) resultMap.put(PARAMETER_USER_ID, user_id);
			if (service_name != null) resultMap.put(PARAMETER_SERVICE_NAME, service_name);
			if (trans_result != null) resultMap.put(PARAMETER_RESULT, trans_result);
			if (begin_time != null) resultMap.put(PARAMETER_BEGIN_TIME, begin_time);
			if (end_time != null) resultMap.put(PARAMETER_END_TIME, end_time);
			if (device_type != null) resultMap.put(PARAMETER_DEVICE_TYPE, device_type);
			if (cert_type != null) resultMap.put(PARAMETER_CERTIFICATE_TYPE, cert_type);
			
		}
		resultMap.put("Functions", CreditTransactionFunctions);
		result.setResultFlag(true);
		result.setOutputResult(resultMap);
		return result;
	}
	
	/*
	 * 
	 */
	private JCICServiceResult doQueryCreditQueryTransaction(RequestWrapper request) {
		
		JCICServiceResult result = new JCICServiceResult();
		// Get Request Parameters
		String user_id = 	request.getStringParameter(PARAMETER_USER_ID, null);
		String service_name = request.getStringParameter(PARAMETER_SERVICE_NAME, null);
		String trans_result_str = request.getStringParameter(PARAMETER_RESULT, RESULT_VALUE_ALL);
		Integer	device_type = request.getIntParameter(PARAMETER_DEVICE_TYPE, -1);
		Integer cert_type = request.getIntParameter(PARAMETER_CERTIFICATE_TYPE, 0);
		MyDate begin_time = request.getDateTimeParameter(PARAMETER_BEGIN_DATE, PARAMETER_BEGIN_TIME, null);
		MyDate end_time = request.getDateTimeParameter(PARAMETER_END_DATE, PARAMETER_END_TIME, null);
		if (user_id != null) user_id = user_id.toUpperCase();
		// setup Input String
		result.setInputString(request.getParametersString());
		Log.debug(this, "doQueryCreditQueryTransaction", "input("+result.getInputString()+")");
		// Check Input Parameters
		if (service_name != null) {
			service_name = service_name.trim();
			if (service_name.length() < 1) service_name = null;
		}
		if (begin_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.begin_date_invalid");
			return result;
		}
		if (end_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.end_date_invalid");
			return result;
		}
		// Initial PageHandler
		PageHandler page = new PageHandler(DEFAULT_PAGE_SIZE, DEFAULT_LIST_PAGES);
		setSessionQueryInfo(QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME, request, page);
		if (begin_time.getTime() > end_time.getTime()) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_time_duration_invalid");
			return result;
		}
		int nowYear = new MyDate().getYear();
		int firstQueryYear = nowYear - TRANSACTION_KEEP_YEARS + 1;
		if (firstQueryYear < FIRST_YEAR) firstQueryYear = FIRST_YEAR;
		if (begin_time.getYear() < firstQueryYear) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_begin_date_too_early");
			return result;
		}
		if (end_time.getYear() > nowYear) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_end_date_too_late");
			return result;
		}
		if (user_id == null || user_id.length() < 1) {
			int months = end_time.getMonth() - begin_time.getMonth() + ((end_time.getYear() - begin_time.getYear()) * 12);
			if (months > MAX_QUERY_MONTHS_WITHOUT_ID ||
				(months == MAX_QUERY_MONTHS_WITHOUT_ID && end_time.getDate() > begin_time.getDate())) {
				result.setResultFlag(false);
				result.setErrorMessage("quickcode.error.input.query_duration_too_long_without_id");
				return result;
			}
		}
		Boolean trans_result = null;
		if (trans_result_str.equalsIgnoreCase(RESULT_VALUE_SUCCEED)) {
			trans_result = new Boolean(true);
		} else
		if (trans_result_str.equalsIgnoreCase(RESULT_VALUE_FAILED)) {
			trans_result = new Boolean(false);
		}
		
		// Query Credit Report Transactions
		Map<String, Object> conditions = new HashMap<String, Object>();
		conditions.put(TransactionPersistence.QUERY_CONDITION_USER_ID, user_id);
		conditions.put(TransactionPersistence.QUERY_CONDITION_FUNCTION, service_name);
		conditions.put(TransactionPersistence.QUERY_CONDITION_RESULT, trans_result);
		conditions.put(TransactionPersistence.QUERY_CONDITION_BEGIN_TIME, begin_time);
		conditions.put(TransactionPersistence.QUERY_CONDITION_END_TIME, end_time);
		if (device_type >= 0) conditions.put(TransactionPersistence.QUERY_CONDITION_DEVICE_TYPE, device_type);
		if (cert_type > 0) conditions.put(TransactionPersistence.QUERY_CONDITION_CERTIFICATE_TYPE, cert_type);
		// conditions.put(TransactionPersistence.QUERY_CONDITION_CATALOG, Transaction.CATALOG_CREDIT_REPORT);
		QueryResult<Transaction> queryResult = TransactionPersistence.getInstance().query(conditions, 0, page.getPageSize());
		if (queryResult == null || queryResult.getTotal() < 1 || queryResult.getResult() == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.no_transaction");
			return result;
		}
		result.setResultFlag(true);
		result.setOutputString("Get Total "+queryResult.getTotal()+" Transactions");

		// Setup the Query Information into Session
		page.bindPages(queryResult.getTotal(), 1);
		// setSessionQueryInfo(QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME, request, page);
		// Set queried consents and page information to Result
		Map<String, Object> outputResult = new HashMap<String, Object>();
		outputResult.put("transactions", queryResult.getResult());
		outputResult.put("page", page);
		result.setOutputResult(outputResult);
		return result;
	}

	/*
	 * 
	 */
	private JCICServiceResult doQueryCreditQueryTransactionPage(RequestWrapper request) {
		
		JCICServiceResult result = new JCICServiceResult();
		// Get QueryInfo from Session
		Map<String, Object> queryInfo = getSessionQueryInfo(QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME, request);
		if (queryInfo == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.page_query_no_info");
			return result;
		}
		PageHandler page = super.getSessionQueryPage(queryInfo);
		if (page == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.page_query_no_page");
			return result;
		}
		// Get Service Parameters: page
		int targetPage = request.getIntParameter(PARAMETER_PAGE_NUMBER, page.getCurrentPage());
		page.setCurrentPage(targetPage);
		result.setInputString(this.getSessionQueryInfoString(queryInfo)+"; "+PARAMETER_PAGE_NUMBER+"="+targetPage);
		
		Log.debug(this, "doQueryCreditQueryTransactionPage", "currentPage="+page.getCurrentPage()+", pageStartRow="+page.getPageStartRow()+", pageRows="+page.getPageRows());
		// Get Query Condition from QueryInfo
		String user_id = this.getQueryInfoParameter(queryInfo, PARAMETER_USER_ID, null, String.class);
		String service_name = this.getQueryInfoParameter(queryInfo, PARAMETER_SERVICE_NAME, null, String.class);
		Boolean trans_result = this.getQueryInfoParameter(queryInfo, PARAMETER_RESULT, null, Boolean.class);
		MyDate begin_time = this.getQueryInfoParameter(queryInfo, PARAMETER_BEGIN_TIME, null, MyDate.class);
		MyDate end_time = this.getQueryInfoParameter(queryInfo, PARAMETER_END_TIME, null, MyDate.class);
		Integer device_type = this.getQueryInfoParameter(queryInfo, PARAMETER_DEVICE_TYPE, -1, Integer.class);
		Integer cert_type = this.getQueryInfoParameter(queryInfo, PARAMETER_CERTIFICATE_TYPE, 0, Integer.class);
		
		// Check Request Parameters
		if (service_name != null) {
			service_name = service_name.trim();
			if (service_name.length() < 1) service_name = null;
		}
		if (begin_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.begin_date_invalid");
			return result;
		}
		if (end_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.end_date_invalid");
			return result;
		}
		if (begin_time.getTime() > end_time.getTime()) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_time_duration_invalid");
			return result;
		}
		int nowYear = new MyDate().getYear();
		int firstQueryYear = nowYear - TRANSACTION_KEEP_YEARS + 1;
		if (firstQueryYear < FIRST_YEAR) firstQueryYear = FIRST_YEAR;
		if (begin_time.getYear() < firstQueryYear) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_begin_date_too_early");
			return result;
		}
		if (end_time.getYear() > nowYear) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.query_end_date_too_late");
			return result;
		}
		if (user_id == null || user_id.length() < 1) {
			int months = end_time.getMonth() - begin_time.getMonth() + ((end_time.getYear() - begin_time.getYear()) * 12);
			if (months > MAX_QUERY_MONTHS_WITHOUT_ID ||
				(months == MAX_QUERY_MONTHS_WITHOUT_ID && end_time.getDate() > begin_time.getDate())) {
				result.setResultFlag(false);
				result.setErrorMessage("quickcode.error.input.query_duration_too_long_without_id");
				return result;
			}
		}
		// Query Credit Report Transactions
		Map<String, Object> conditions = new HashMap<String, Object>();
		conditions.put(TransactionPersistence.QUERY_CONDITION_USER_ID, user_id);
		conditions.put(TransactionPersistence.QUERY_CONDITION_FUNCTION, service_name);
		conditions.put(TransactionPersistence.QUERY_CONDITION_RESULT, trans_result);
		conditions.put(TransactionPersistence.QUERY_CONDITION_BEGIN_TIME, begin_time);
		conditions.put(TransactionPersistence.QUERY_CONDITION_END_TIME, end_time);
		if (device_type >= 0) conditions.put(TransactionPersistence.QUERY_CONDITION_DEVICE_TYPE, device_type);
		if (cert_type > 0) conditions.put(TransactionPersistence.QUERY_CONDITION_CERTIFICATE_TYPE, cert_type);
		// conditions.put(TransactionPersistence.QUERY_CONDITION_CATALOG, Transaction.CATALOG_CREDIT_REPORT);
		QueryResult<Transaction> queryResult = TransactionPersistence.getInstance().query(conditions, page.getPageStartRow(), page.getPageSize());
		if (queryResult == null || queryResult.getTotal() < 1 || queryResult.getResult() == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.no_transaction");
			return result;
		}
		result.setResultFlag(true);
		result.setOutputString("Get Page "+queryResult.getResult().length+" Transactions");

		// Setup the Query Information into Session
		page.bindPages(queryResult.getTotal(), targetPage);
		super.setSessionQueryPage(request, QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME, page);
		// Set queried users and page information to Result
		Map<String, Object> outputResult = new HashMap<String, Object>();
		outputResult.put("transactions", queryResult.getResult());
		outputResult.put("page", page);
		result.setOutputResult(outputResult);

		return result;
	}

	/*
	 * 
	 */
	private JCICServiceResult doPrintCreditQueryTransaction(RequestWrapper request) {
		
		JCICServiceResult result = new JCICServiceResult();
		// Get QueryInfo from Session
		Map<String, Object> queryInfo = getSessionQueryInfo(QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME, request);
		if (queryInfo == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.page_query_no_info");
			return result;
		}
		// Get Query Condition from QueryInfo
		String user_id = this.getQueryInfoParameter(queryInfo, PARAMETER_USER_ID, null, String.class);
		String service_name = this.getQueryInfoParameter(queryInfo, PARAMETER_SERVICE_NAME, null, String.class);
		Boolean trans_result = this.getQueryInfoParameter(queryInfo, PARAMETER_RESULT, null, Boolean.class);
		MyDate begin_time = this.getQueryInfoParameter(queryInfo, PARAMETER_BEGIN_TIME, null, MyDate.class);
		MyDate end_time = this.getQueryInfoParameter(queryInfo, PARAMETER_END_TIME, null, MyDate.class);
		Integer device_type = this.getQueryInfoParameter(queryInfo, PARAMETER_DEVICE_TYPE, -1, Integer.class);
		Integer cert_type = this.getQueryInfoParameter(queryInfo, PARAMETER_CERTIFICATE_TYPE, 0, Integer.class);
		result.setInputString(this.getSessionQueryInfoString(queryInfo));
		// Check Request Parameters
		if (begin_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.begin_date_invalid");
			return result;
		}
		if (end_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.end_date_invalid");
			return result;
		}		
		
		// Query Credit Transactions by input parameters.
		CreditTransDataSource dataSource = new CreditTransDataSource();
		Map<String, Object> conditions = new HashMap<String, Object>();
		conditions.put(TransactionPersistence.QUERY_CONDITION_USER_ID, user_id);
		conditions.put(TransactionPersistence.QUERY_CONDITION_FUNCTION, service_name);
		conditions.put(TransactionPersistence.QUERY_CONDITION_RESULT, trans_result);
		conditions.put(TransactionPersistence.QUERY_CONDITION_BEGIN_TIME, begin_time);
		conditions.put(TransactionPersistence.QUERY_CONDITION_END_TIME, end_time);
		if (device_type >= 0) conditions.put(TransactionPersistence.QUERY_CONDITION_DEVICE_TYPE, device_type);
		if (cert_type > 0) conditions.put(TransactionPersistence.QUERY_CONDITION_CERTIFICATE_TYPE, cert_type);
		// conditions.put(TransactionPersistence.QUERY_CONDITION_CATALOG, Transaction.CATALOG_CREDIT_REPORT);
		if (!dataSource.getDataSourceByCondition(conditions)) {
			// setup Input String
			Log.error(this, "doPrintCreditQueryTransaction", "getDataSourceCondition("+PARAMETER_USER_ID+"="+user_id
								 +", "+PARAMETER_SERVICE_NAME+"="+service_name
								 +", "+PARAMETER_RESULT+"="+(trans_result==null?"":trans_result)
								 +", "+PARAMETER_DEVICE_TYPE+"="+((device_type < 0)?"":device_type)
								 +", "+PARAMETER_CERTIFICATE_TYPE+"="+((cert_type <= 0)?"":cert_type)
								 +", "+PARAMETER_BEGIN_TIME+"="+begin_time.getDateTimeDisplay()
								 +", "+PARAMETER_END_TIME+"="+end_time.getDateTimeDisplay()
								 // +", Catalog="+Transaction.CATALOG_CREDIT_REPORT
								 +") failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.transaction_not_found");
			return result;
		}
		// Get Download Report Directory Path
		String downloadPath = SystemProperties.getInstance().getApplicationPath(PROPERTY_DOWNLOAD_REPORT_PATH);
		if (downloadPath == null || downloadPath.length() < 1) {
			Log.error(this, "doPrintCreditQueryTransaction", "Not define Download Report Directory Path Property:"+PROPERTY_DOWNLOAD_REPORT_PATH);
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.export_report_pdf_failed");
			return result;
		}
		if (downloadPath.charAt(downloadPath.length()-1) != '/') {
			downloadPath = downloadPath + "/";
		}
		// Create Report PDF for Consent Detail Information
		String reportFileName = UUID.randomUUID().toString() + ".pdf";
		String reportFilePath = downloadPath + reportFileName;
		// Generate Report to Report File
		JasperReportAdapter reportAdapter = new JasperReportAdapter();
		reportAdapter.setLanguage("zh_TW");
		reportAdapter.setTemplate(QUERY_REPORT_TEMPLATE);
		if (!reportAdapter.fillReport(dataSource)) {
			Log.error(this, "doPrintCreditQueryTransaction", "fillReport failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.generate_report_failed");
			return result;
		}
		if (!reportAdapter.exportToPdfFile(reportFilePath)) {
			Log.error(this, "doPrintCreditQueryTransaction", "Export report to PDF failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.export_report_pdf_failed");
			return result;
		}
		reportAdapter.clean();
		Log.debug(this, "doPrintCreditQueryTransaction", "PDF report generated.");
		this.setFileOwner(request, reportFileName, reportFileName, reportFileName, true);
		result.setResultFlag(true);
		result.setOutputResult(reportFileName);
		return result;				
	}
	
	/*
	 * 
	 */
	private JCICServiceResult doShowCreditQueryTransactionInfo(RequestWrapper request) {
		
		JCICServiceResult result = new JCICServiceResult();
		long transaction_id = request.getLongParameter(PARAMETER_TRANSACTION_ID, -1);
		MyDate transaction_date = request.getBeginDateParameter(PARAMETER_TRANSACTION_DATE, null);
		// setup Input String
		result.setInputString(request.getParametersString());
		Log.debug(this, "doShowCreditQueryTransactionInfo", "input("+result.getInputString()+")");
		// Check Input Parameters
		if (transaction_id <= 0) {
			Log.error(this, "doShowCreditQueryTransactionInfo", "input parameter transacitonID not found");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_transactionID");
			return result;			
		}
		if (transaction_date == null) {
			Log.error(this, "doShowCreditQueryTransactionInfo", "input parameter transaciton_date not found");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_transaction_date");
			return result;
		}
		// Query Transaction by transaction_id
		Transaction transaction = TransactionPersistence.getInstance().getById(transaction_id, transaction_date);
		if (transaction == null) {
			Log.error(this, "doShowCreditQueryTransactionInfo", "query Transaction by Id("+transaction_id+") not found or failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.transaction_not_found");
			return result;			
		}
		/*
		if (SIMULATION) {
			this.simuateTransaction(transaction);
		}
		*/
		// Get Transaction Reason Name
		if (transaction.getReasonCode() != null) {
			Reason reason = ReasonDao.getInstance().getByCode(Reason.REASON_TYPE_USER_REQUEST_CREDIT_REPORT, transaction.getReasonCode());
			if (reason != null) transaction.setReasonName(reason.getName());
		}
		// Get Reasons for Manager query Credit Report
		Reason[] reasons = ReasonDao.getInstance().getByType(Reason.REASON_TYPE_MANAGEMENT_CREDIT_REPORT);
		result.setResultFlag(true);
		result.setOutputString("ReportNo="+transaction.getDataID()+", Action="+transaction.getFunction());
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("transaction", transaction);
		resultMap.put("reasons", reasons);
		result.setOutputResult(resultMap);
		return result;
	}
	
	private CreditReport getCreditReport(User user, String report_no, String user_id, String reportFilePath, MyDate reportTime) {
		
		CreditReport report = null;
		// Get Report from Host using DB2 Store Procedure
		CreditReportProcedure procedure = CreditReportProcedure.getInstance();
		report = procedure.getPreviousCreditReport(report_no, user_id, null);
		if (report == null) {
			Log.error(this, "getCreditReprot", "Get Credit Report Text File failed");
			return null;
		}
		MyDate queryTime = new MyDate();
		String waterMarkText = queryTime.getDateTimeDisplay()+"    "+user.getAccount();
		CreditReportPDFAdapter adapter = new CreditReportPDFAdapter();
		if (!adapter.createCreditReportPdfForManager(report, reportFilePath, waterMarkText)) {
			Log.error(this, "getCreditReprot", "Create Credit Report PDF for Manager failed");
			return null;
		}
		return report;
	}
	
	private static boolean printInfoIncludeReport = false;

	/*
	 * 
	 */
	private JCICServiceResult doPrintCreditQueryTransactionInfo(RequestWrapper request) {
		
		JCICServiceResult result = new JCICServiceResult();
		long transaction_id = request.getLongParameter(PARAMETER_TRANSACTION_ID, -1);
		MyDate transaction_date = request.getBeginDateParameter(PARAMETER_TRANSACTION_DATE, null);
		// setup Input String
		result.setInputString(request.getParametersString());
		Log.debug(this, "doPrintCreditQueryTransactionInfo", "input("+result.getInputString()+")");
		// Check Input Parameters
		if (transaction_id <= 0 ){
			Log.error(this, "doPrintCreditQueryTransactionInfo", "invalid input parameter transaction_id("+transaction_id+")");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_transactionID");
			return result;			
		}
		if (transaction_date == null) {
			Log.error(this, "doShowCreditQueryTransactionInfo", "input parameter transaciton_date not found");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_transaction_date");
			return result;
		}
		// Query Transaction by ID, begin_time, end_time
		Transaction transaction = TransactionPersistence.getInstance().getById(transaction_id, transaction_date);
		if (transaction == null) {
			Log.error(this, "doPrintCreditQueryTransactionInfo", "query Transaction by Id("+transaction_id+") not found or failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.transaction_not_found");
			return result;			
		}
		/*
		if (SIMULATION) {
			this.simuateTransaction(transaction);
		}
		*/
		// Get Transaction Reason Name
		if (transaction.getReasonCode() != null) {
			Reason reason = ReasonDao.getInstance().getByCode(Reason.REASON_TYPE_USER_REQUEST_CREDIT_REPORT, transaction.getReasonCode());
			if (reason != null) transaction.setReasonName(reason.getName());
		}
		// Query Consents by input parameters.
		CreditTransDataSource dataSource = new CreditTransDataSource();
		Transaction[] sourceData = { transaction };
		dataSource.setDataArray(sourceData);
		JasperReportAdapter reportAdapter = new JasperReportAdapter();
		reportAdapter.setLanguage("zh_TW");
		reportAdapter.setTemplate(DETAIL_REPORT_TEMPLATE);
		if (!reportAdapter.fillReport(dataSource)) {
			Log.error(this, "doPrintCreditQueryTransactionInfo", "fillReport failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.generate_report_failed");
			return result;
		}
		// Get Download Report Directory Path
		String downloadFilePath = DownloadFilePathGenerator.getInstance().getDownloadFilePath();
		if (downloadFilePath == null) {
			Log.error(this, "doPrintCreditQueryTransactionInfo", "Generate Download File Path failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.export_report_pdf_failed");
			return result;
		}
		// Create Report PDF for Detail Information
		String pdfFilePath = downloadFilePath + ".pdf";
		if (!reportAdapter.exportToPdfFile(pdfFilePath)) {
			Log.error(this, "doPrintCreditQueryTransactionInfo", "Export report to PDF File("+pdfFilePath+") failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.export_report_pdf_failed");
			return result;
		}
		reportAdapter.clean();
		dataSource.closeDataSource();
		// Get Session Login user
		User user = this.getSessionUser(request);
		// Assign Result Report File Name
		String reportFilePath = pdfFilePath;
		// Check Print Information include Credit Report ? or User has Credit Report access right
		if (!printInfoIncludeReport || user == null || transaction.getDataID() == null || !this.getReportReadRight(request)) {
			// Print Information not include Credit Report Content 
			//       or Transaction has no associated Credit Report
			//       or User has no Credit Report access right
			String reportFileName = DownloadFilePathGenerator.getFileNameFromPath(reportFilePath);
			Log.debug(this, "doPrintCreditQueryTransactionInfo", "PDF report generated.");
			// Set File Owner to Session
			setFileOwner(request, reportFileName, reportFileName, reportFileName, true);
			result.setResultFlag(true);
			result.setOutputResult(reportFileName);
			return result;				
		}
		
		// Print Information should include 
		// Generate download Report file name and file path
		String tempFilePath = TempFilePathGenerator.getInstance().getTemporaryFilePath();
		if (tempFilePath == null) {
			Log.error(this, "doPrintCreditQueryTransactionInfo", "Generate Report Content tempoary file path failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.get_credit_report_failed");
			return result;
		}
		tempFilePath += ".pdf";
		// Get Credit Report PDF Blob Object
		if (getCreditReport(user, transaction.getDataID(), transaction.getUserId(), tempFilePath, transaction.getTime()) == null) {
			Log.error(this, "doPrintCreditQueryTransactionInfo", "Get Credit Report PDF Blob Object Error");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.get_credit_report_failed");
			return result;
		}
		/*
		DbBlobObject reportObject = null;
		try {
			reportObject = new DbBlobObject(tempFilePath);
			// if (reportObject == null || reportObject.getInputStream() == null) {
			if (reportObject == null || reportObject.getBytes() == null) { // for Tomcat 6.0
				// if (reportObject != null) reportObject.close();         // for Tomcat 6.0
				Log.error(this, "doPrintCreditQueryTransactionInfo", "Get Credit Report PDF Blob Object Error");
				result.setResultFlag(false);
				result.setErrorMessage("quickcode.error.get_credit_report_failed");
				return result;
			}
		} catch (Exception e) {
			Log.error(this, "doPrintCreditQueryTransactionInfo", "Get Credit Report PDF Blob Object exception:"+e.getLocalizedMessage());
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.get_credit_report_failed");
			return result;
		}
		*/
		// Generate New Report File Path
		reportFilePath = DownloadFilePathGenerator.getInstance().getDownloadFilePath() + ".pdf";

		// Append Consent PDF Content to Report
		// if (!ServerPDFAdapter.concatenatPDFs(reportFilePath, pdfFilePath, reportObject.getInputStream())) {
		String[] sourcePdfFiles = { pdfFilePath, tempFilePath };
		if (!ServerPDFAdapter.concatenatPDFs(reportFilePath, sourcePdfFiles)) { // for Tomcat 6.0
			FileUtility.removeFile(pdfFilePath);
			// reportObject.close();		// for Tomcat 6.0
			FileUtility.removeFile(tempFilePath);
			Log.error(this, "doPrintCreditQueryTransactionInfo", "Append Credit Report to Report("+reportFilePath+") failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.export_report_pdf_failed");
			return result;
		}
		FileUtility.removeFile(pdfFilePath);
		// reportObject.close();	// for Tomcat 6.0
		FileUtility.removeFile(tempFilePath);
		// Set Result information
		String reportFileName = DownloadFilePathGenerator.getFileNameFromPath(reportFilePath);
		Log.debug(this, "doPrintCreditQueryTransactionInfo", "PDF report generated.");
		// Set File Owner to Session
		setFileOwner(request, reportFileName, reportFileName, reportFileName, true);
		result.setResultFlag(true);
		result.setOutputString("ReportNo="+transaction.getDataID()+", Action="+transaction.getFunction());
		result.setOutputResult(reportFileName);
		return result;				
	}

	/*
	 * 
	 */
	private JCICServiceResult doGetCreditReportPDF(RequestWrapper request) {
		
		JCICServiceResult result = new JCICServiceResult();
		long transaction_id = request.getLongParameter(PARAMETER_TRANSACTION_ID, -1);
		MyDate transaction_date = request.getBeginDateParameter(PARAMETER_TRANSACTION_DATE, null);
		String reason = request.getStringParameter(PARAMETER_REASON, null);
		String remark = request.getStringParameter(PARAMETER_REMARK, null);
		// setup Input String
		result.setInputString(request.getParametersString());
		Log.debug(this, "doGetCreditReportPDF", "input("+result.getInputString()+")");

		// Check & Setup reason & remark to Result
		String reasonName = getManagerReasonName(reason);
		result.setReason(reasonName);
		result.setRemark(remark);
		if (reasonName == null) {
			Log.error(this, "doGetCreditReportPDF", "invalid input parameter reason("+reason+")");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_reason");
			return result;
		}
		if (remark == null || remark.trim().length() < 1) {
			Log.error(this, "doGetCreditReportPDF", "invalid input parameter remark("+remark+")");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_remark");
			return result;
		}
		
		// Get Session Login User
		User user = this.getSessionUser(request);
		if (user == null) {
			Log.error(this, "doGetCreditReportPDF", "Session Login user not found");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.not_login");
			return result;
		}
		
		// Check Transaction ID & Date Parameters
		if (transaction_id <= 0 ){
			Log.error(this, "doGetCreditReportPDF", "invalid input parameter transaction_id("+transaction_id+")");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_transactionID");
			return result;			
		}
		if (transaction_date == null) {
			Log.error(this, "doGetCreditReportPDF", "input parameter transaciton_date not found");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.invalid_transaction_date");
			return result;
		}
		// Query Transaction by ID, begin_time, end_time
		Transaction transaction = TransactionPersistence.getInstance().getById(transaction_id, transaction_date);
		if (transaction == null) {
			Log.error(this, "doGetCreditReportPDF", "query Transaction by Id("+transaction_id+") not found or failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.transaction_not_found");
			return result;			
		}

		// Generate Credit Report File Name and File Path
		String downloadFilePath = DownloadFilePathGenerator.getInstance().getDownloadFilePath();
		if (downloadFilePath == null) {
			Log.error(this, "doGetCreditReportPDF", "Generate Download Report File Path failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.get_credit_report_failed");
			return result;
		}
		String pdfFilePath = downloadFilePath + ".pdf";

		// Query Report by report_id
		if (getCreditReport(user, transaction.getDataID(), transaction.getUserId(), pdfFilePath, transaction.getTime()) == null) {
			Log.error(this, "doGetCreditReportPDF", "get Credit Report by Id("+transaction.getDataID()+") not found or failed");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.get_credit_report_failed");
			return result;						
		}
		String pdfFileName = DownloadFilePathGenerator.getFileNameFromPath(pdfFilePath);
		this.setFileOwner(request, pdfFileName, pdfFileName, pdfFileName, true);
		result.setResultFlag(true);
		result.setOutputString("ReportNo="+transaction.getDataID()+", Action="+transaction.getFunction());
		result.setOutputResult(pdfFileName);
		return result;
	}

	private JCICServiceResult doExportCreditQueryTransaction(RequestWrapper request) {
		Log.debug(this, "doExportCreditQueryTransaction", "invoked.");
		JCICServiceResult result = new JCICServiceResult();
		
		MyDate begin_time = request.getBeginDateParameter(PARAMETER_BEGIN_DATE, null);
		MyDate end_time = request.getEndDateParameter(PARAMETER_END_DATE, null);
		// set parameters to input string of result object
		result.setInputString(request.getParametersString());
		Log.debug(this, "doExportCreditQueryTransaction", "input("+result.getInputString()+")");
		// Parsing Request Parameters
		if (begin_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.begin_date_invalid");
			return result;
		}
		if (end_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.end_date_invalid");
			return result;
		}
		// Generate the Export File Path/Name
		String exportFName = "CREDIT_TRANSACTION_Export_"+begin_time.getDateString()+"_"+end_time.getDateString();
		String relative_exportFilePath = exportFName +".xml";
		String exportFilePath = SystemProperties.getInstance().getApplicationPath(PROPERTY_EXPORT_PATH) + relative_exportFilePath;
		int	startRow = 0; int exportRows = 0;
		OutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(exportFilePath);
			String outString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + "<"+TAG_DOCUMENT+">\r\n";
			outputStream.write(outString.getBytes("UTF-8"));
			while (true) {
				// Query Matched Consent Versions
				QueryResult<Transaction> queryResult = TransactionPersistence.getInstance()
																	.queryByCondition(begin_time, end_time, 0, 
																					  null, null, null, null, null, null, null, startRow, EXPORT_BUFFER_SIZE);
				if (queryResult == null) break;
				Transaction[] transactions = (Transaction[]) queryResult.getResult();
				// Write Transactions to XML Element one by one
				for (int i = 0; i < transactions.length; i++) {
					// Export Transaction Element Information
					outString = "<"+TAG_TRANSACTION+" "+ATTR_TIME+"=\""+transactions[i].getTime().getDateTimeDisplay()+"\" " +
								ATTR_CATALOG+"=\""+transactions[i].getCatalog()+"\" " +
								ATTR_USER_TYPE+"=\""+transactions[i].getUserType()+"\" " +
								ATTR_USER_ID+"=\""+transactions[i].getUserId()+"\" " +
								ATTR_FUNCTION+"=\""+transactions[i].getFunction()+"\" ";
					if (transactions[i].isResultSucceed()) {
						outString += ATTR_RESULT+"=\"1\" ";
					} else {
						outString += ATTR_RESULT+"=\"0\" ";
					}
					outString += " >\r\n";
					outputStream.write(outString.getBytes("UTF-8"));
					if (transactions[i].getInput() != null) {
						outString = "<"+TAG_INPUT+">"+transactions[i].getInput()+"</"+TAG_INPUT+">\r\n";
						outputStream.write(outString.getBytes("UTF-8"));
					}
					if (transactions[i].getOutput() != null) {
						outString = "<"+TAG_OUTPUT+">"+transactions[i].getOutput()+"</"+TAG_OUTPUT+">\r\n";
						outputStream.write(outString.getBytes("UTF-8"));
					}
					if (transactions[i].getDataLink() != null) {
						outString = "<"+TAG_DATALINK+">"+transactions[i].getDataLink()+"</"+TAG_DATALINK+">\r\n";
						outputStream.write(outString.getBytes("UTF-8"));
					}
					if (transactions[i].getCertSerial() != null || transactions[i].getCertSubject() != null) {
						outString = "<"+TAG_CERTIFICATE+" "+ATTR_CERT_TYPE+"=\""+transactions[i].getCertCertType()+"\"";
						if (transactions[i].getCertSerial() != null) {
							outString += " "+ATTR_CERT_SERIAL+"=\""+transactions[i].getCertSerial()+"\"";
						}
						if (transactions[i].getCertIssuer() != null) {
							outString += " "+ATTR_CERT_ISSUER+"=\""+transactions[i].getCertIssuer()+"\"";
						}
						if (transactions[i].getCertSubject() != null) {
							outString += " "+ATTR_CERT_SUBJECT+"=\""+transactions[i].getCertSubject()+"\"";
						}
						if (transactions[i].getCertExpireTime() != null) {
							outString += " "+ATTR_CERT_EXPIRE_TIME+"=\""+transactions[i].getCertExpireTimeString()+"\"";
						}
						outString +=  " >\r\n";
						outputStream.write(outString.getBytes("UTF-8"));
					}
					if (transactions[i].getSignature() != null) {
						outString = "<"+TAG_SIGNATURE+">"+Base64.encodeBase64String(transactions[i].getSignature())+"</"+TAG_SIGNATURE+">\r\n";
						outputStream.write(outString.getBytes("UTF-8"));
					}
					outString = "</"+TAG_TRANSACTION+">\r\n";
					outputStream.write(outString.getBytes("UTF-8"));
					outputStream.flush();	// Flush all information of this Audit Log to export
					exportRows++;
				}
				startRow += transactions.length;
			}
			// Write end Tag of
			outString = "</"+TAG_DOCUMENT+">\r\n";
			outputStream.write(outString.getBytes("UTF-8"));	
			outputStream.flush();
			outputStream.close(); outputStream = null;
		} catch (Exception e) {
			if (outputStream != null) try { outputStream.close(); } catch (Exception ex) {}
		}
		
		if (exportRows < 1) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.export_no_transaction");
			return result;
		}
		Log.debug(this, "doExportCreditQueryTransaction", "export "+exportRows+" transactions");
		// Set the number of removed Audit Log to result.
		result.setResultFlag(true);
		String[] arguments = { Integer.toString(exportRows) };
		Map<String, Object> messageMap = new HashMap<String, Object>();
		messageMap.put("key", "quickcode.info.transaction_export_message");
		messageMap.put("param", arguments);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("export_file", relative_exportFilePath);
		resultMap.put("message", messageMap);
		result.setOutputResult(resultMap);
		result.setOutputString(exportRows+" Transactions exported");
		return result;
	}
	
	/*
	 * 
	 */
	private JCICServiceResult doImportCreditQueryTransaction(RequestWrapper request) {
		
		JCICServiceResult result = new JCICServiceResult();		
		// Get the Text file upload directory path
		String importUploadDir = SystemProperties.getInstance().getApplicationPath(PROPERTY_IMPORT_PATH);
		result.setInputString(request.getParametersString());
		// Parsing the Multi-part request by Oreilly package.
		//		and setup the Upload file maximum size = 10 MB
		MultipartRequest theMultipartRequest = null;
		try {
			theMultipartRequest = 
					new MultipartRequest(request, importUploadDir, 10*1024*1024,"UTF-8");
		} catch (Exception e) {
			Log.debug(this, "doImportCreditQueryTransaction", e);
			result.setResultFlag(false);
			String[] arguments = { e.getLocalizedMessage() };
			result.setErrorMessage("quickcode.error.multipart_request_exception", arguments);
			return result;
		}
		// Get Upload Import Transaction XML File
		// check the Upload file parameter
		@SuppressWarnings("unchecked")
		Enumeration<String> files = theMultipartRequest.getFileNames();
		if (files == null || !files.hasMoreElements()) {
			Log.debug(this, "doImportCreditQueryTransaction", "Import file upload failed or No specified!");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.no_upload_file");
			return result;
		}
		// Get Upload file path
		String fieldName = files.nextElement();
		File file = theMultipartRequest.getFile(fieldName);
		if (file == null) {
			Log.debug(this, "doImportCreditQueryTransaction", "Import file upload failed or No specified!");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.no_upload_file");
			return result;			
		}
		// Parsing Import File to 
		Document importDocument = XMLUtility.parseFileToDocument(file);
		if (importDocument == null) {
			Log.error(this, "doImportCreditQueryTransaction", "import file not a XML");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.import_not_xml");
			return result;
		}
		Element docElement = importDocument.getDocumentElement();
		if (!docElement.getTagName().equalsIgnoreCase(TAG_DOCUMENT)) {
			Log.error(this, "doImportCreditQueryTransaction", "import file has not Document Element: "+TAG_DOCUMENT);
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.not_credit_transaction_import_file");
			return result;
		}
		ArrayList<Element> transElements = XMLUtility.getChildElementsByTag(docElement, TAG_TRANSACTION);
		if (transElements == null || transElements.size() < 1) {
			Log.error(this, "doImportCreditQueryTransaction", "import file has not Transaction Element("+TAG_TRANSACTION+")");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.import_has_no_transaction");
			return result;
		}
		int importRows = 0;
		for (int i = 0; i < transElements.size(); i++) {
			Transaction transaction = new Transaction();
			Element tranElement = transElements.get(i);
			String value_str = tranElement.getAttribute(ATTR_TIME);
			try {
				transaction.setTime(MyDate.parseDateTimeDisplay(value_str));
			} catch (Exception e) {
				Log.error(this, "doImportCreditQueryTransaction", " "+(i+1)+" transaction has no time or invalid time");
				continue;
			}
			value_str = tranElement.getAttribute(ATTR_CATALOG);
			try { 
				transaction.setCatalog(Integer.parseInt(value_str));
			} catch (Exception e) {
				Log.error(this, "doImportCreditQueryTransaction", " "+(i+1)+" transaction has no catalog or invalid catalog");
				continue;
			}
			value_str = tranElement.getAttribute(ATTR_USER_TYPE);
			try { 
				transaction.setUserType(Integer.parseInt(value_str));
			} catch (Exception e) {
				Log.error(this, "doImportCreditQueryTransaction", " "+(i+1)+" transaction has no user type or invalid user type");
				continue;
			}
			transaction.setUserId(tranElement.getAttribute(ATTR_USER_ID));
			transaction.setFunction(tranElement.getAttribute(ATTR_FUNCTION));
			value_str = tranElement.getAttribute(ATTR_RESULT);
			try { 
				int resultFlag = Integer.parseInt(value_str);
				if (resultFlag == 0) {
					transaction.setResultFlag(false);
				} else {
					transaction.setResultFlag(true);
				}
			} catch (Exception e) {
				Log.error(this, "doImportCreditQueryTransaction", " "+(i+1)+" transaction has result or invalid result");
				continue;
			}
			ArrayList<Element> childs = XMLUtility.getChildElement(tranElement);
			if (childs != null) {
				for (int j = 0; j < childs.size(); j++) {
					Element childElement = childs.get(j);
					if (childElement.getTagName().equalsIgnoreCase(TAG_INPUT)) {
						transaction.setInput(XMLUtility.getNodeText(childElement));
					} else 
					if (childElement.getTagName().equalsIgnoreCase(TAG_OUTPUT)) {
						transaction.setOutput(XMLUtility.getNodeText(childElement));
					} else
					if (childElement.getTagName().equalsIgnoreCase(TAG_DATALINK)) {
						transaction.setDataLink(XMLUtility.getNodeText(childElement));
					} else
					if (childElement.getTagName().equalsIgnoreCase(TAG_CERTIFICATE)) {
						String cert_type_str = childElement.getAttribute(ATTR_CERT_TYPE);
						try {
							transaction.setCertType(Integer.valueOf(cert_type_str));
						} catch (Exception e) {
							Log.error(this, "doImportCreditQueryTransaction", " "+(i+1)+" transaction has no cert type or invalid cert type");
						}
						String cert_serial = childElement.getAttribute(ATTR_CERT_SERIAL);
						if (cert_serial != null) transaction.setCertSerial(cert_serial);
						String cert_issuer = childElement.getAttribute(ATTR_CERT_ISSUER);
						if (cert_issuer != null) transaction.setCertSerial(cert_issuer);
						String cert_subject = childElement.getAttribute(ATTR_CERT_SUBJECT);
						if (cert_subject != null) transaction.setCertSubject(cert_subject);
						String cert_expire_str = childElement.getAttribute(ATTR_CERT_EXPIRE_TIME);
						if (cert_expire_str != null) {
							transaction.setCertExpireTime(MyDate.parseDateTimeDisplay(cert_expire_str));
						}
					} else
					if (childElement.getTagName().equalsIgnoreCase(TAG_SIGNATURE)) {
						String base64Signature = XMLUtility.getNodeText(childElement);
						transaction.setSignature(Base64.decodeBase64(base64Signature));
					}
				}
			}
			if (!TransactionPersistence.getInstance().insert(transaction)) {
				Log.error(this, "doImportCreditQueryTransaction:", " "+(i+1)+" transaction insert failed");
			} else {
				importRows++;
			}
		}
		if (importRows < 1) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.no_transaction_import");
			return result;
		}
		Log.error(this, "doImportCreditQueryTransaction", "import "+importRows+" transaction of "+transElements.size()+" in File");
		result.setResultFlag(true);
		String[] arguments = { Integer.toString(importRows), Integer.toString(transElements.size()) };
		result.setOutputResultMessage("quickcode.info.transaction_import_message", arguments);
		return result;
	}

	private JCICServiceResult doRemoveCreditQueryTransaction(RequestWrapper request) {
		Log.debug(this, "doRemoveCreditQueryTransaction", "invoked.");
		JCICServiceResult result = new JCICServiceResult();
		
		MyDate begin_time = request.getBeginDateParameter(PARAMETER_BEGIN_DATE, null);
		MyDate end_time = request.getEndDateParameter(PARAMETER_END_DATE, null);
		// set parameters to input string of result object
		result.setInputString(request.getParametersString());
		Log.debug(this, "doRemoveCreditQueryTransaction", "input("+result.getInputString()+")");
		// Check Request Parameters
		if (begin_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.begin_date_invalid");
			return result;
		}
		if (end_time == null) {
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.input.end_date_invalid");
			return result;
		}
		
		// Remove Transactions from database
		int removeRows = TransactionPersistence.getInstance().deleteByTime(begin_time, end_time, 0);
		// Check if any Audit Logs deleted or not.
		if (removeRows < 1) {
			Log.debug(this, "doRemoveCreditQueryTransaction", "Transactions not found, or delete failed!");
			result.setResultFlag(false);
			result.setErrorMessage("quickcode.error.remove_no_transacion");
			return result;
		}
		// Set the number of removed Transactions to result.
		result.setResultFlag(true);
		String[] arguments = { Integer.toString(removeRows) };
		result.setOutputResultMessage("quickcode.info.remove_transaction_succeed", arguments);
		result.setOutputString(removeRows+" Transactions removed");
		return result;
	}


	/* (non-Javadoc)
	 * @see com.quickretrieval.jcic.server.action.EndUserBaseAction#doService(java.lang.String, javax.servlet.http.RequestWrapper, javax.servlet.http.ResponseWrapper)
	 */
	@Override
	protected JCICServiceResult doService(String serviceName, RequestWrapper request, ResponseWrapper response) {
		
		if (serviceName.equalsIgnoreCase(QUERY_CREDIT_TRANSACITON_INPUT_SERVICE_NAME)) {
			return doQueryCreditQueryTransactionInput(request);
		}
		if (serviceName.equalsIgnoreCase(QUERY_CREDIT_TRANSACTION_SERVICE_NAME)) {
			return doQueryCreditQueryTransaction(request);
		}
		if (serviceName.equalsIgnoreCase(QUERY_CREDIT_TRANSACTION_PAGE_SERVICE_NAME)) {
			return doQueryCreditQueryTransactionPage(request);
		}
		if (serviceName.equalsIgnoreCase(PRINT_CREDIT_TRANSACTION_SERVICE_NAME)) {
			return doPrintCreditQueryTransaction(request);
		}
		if (serviceName.equalsIgnoreCase(STATISTIC_CREDIT_TRANSACTION_SERVICE_NAME)) {
			return doStatisCreditQueryTransaction(request);
		}
		if (serviceName.equalsIgnoreCase(PRINT_STATISTIC_CREDIT_TRANSACTION_SERVICE_NAME)) {
			return doPrintStatisticCreditQueryTransaction(request);
		}
		if (serviceName.equalsIgnoreCase(SHOW_CREDIT_TRANSACTION_INFO_SERVICE_NAME)) {
			return doShowCreditQueryTransactionInfo(request);
		}
		if (serviceName.equalsIgnoreCase(PRINT_CREDIT_TRANSACTION_INFO_SERVICE_NAME)) {
			return doPrintCreditQueryTransactionInfo(request);
		}
		if (serviceName.equalsIgnoreCase(EXPORT_CREDIT_TRANSACTION_SERVICE_NAME)) {
			return doExportCreditQueryTransaction(request);
		}
		if (serviceName.equalsIgnoreCase(REMOVE_CREDIT_TRANSACTION_SERVICE_NAME)) {
			return doRemoveCreditQueryTransaction(request);
		}
		if (serviceName.equalsIgnoreCase(IMPORT_CREDIT_TRANSACTION_SERVICE_NAME)) {
			return doImportCreditQueryTransaction(request);
		}
		if (serviceName.equalsIgnoreCase(GET_CREDIT_REPORT_PDF_SERVICE_NAME)) {
			return doGetCreditReportPDF(request);
		}
		Log.error(this, "doService", "service("+serviceName+") not found"); 
		return null;
	}

}
