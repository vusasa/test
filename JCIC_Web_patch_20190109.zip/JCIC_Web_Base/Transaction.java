/**
 * 
 */
package com.quickretrieval.jcic.server.entity;

import java.io.Serializable;

import org.apache.commons.codec.binary.Base64;

import com.quickretrieval.common.utils.FormatCheckUtil;
import com.quickretrieval.common.utils.MyDate;
import com.quickretrieval.jcic.server.em.ReportStatus;
import com.quickretrieval.security.SecurityProvider;
import com.quickretrieval.server.adapter.BankUtility;
import com.quickretrieval.server.log.Log;

/**
 * @author BruceHuang
 * 這個 Class處理一個使用者（客戶）的操作交易內容屬性與方法
 */
public class Transaction implements Serializable {

	/**
	 * Default Serialized Version ID
	 */
	private static final long serialVersionUID = 1L;
	
	private long	transaction_id = -1;			// 操作記錄唯一識別碼，由資料庫已順序產生
	private int		transaction_catalog = -1;		// 操作交易歸屬類別
	private MyDate	transaction_time = null;		// 操作日期時間
	private String  transaction_server_ip = null;	// 伺服器的 IP 位址
	private String  transaction_session_id = null;	// 操作客戶登入 SESSION ID
	private String  transaciton_user_ip = null;		// 操作客戶的 IP 位址
	private int		transaction_user_type = -1;		// 操作的客戶種類
	private String	transaction_user_id = null;		// 操作的客戶識別碼（如身分證字號/統一編號/外國人統一證號）
	private String	transaction_function = null;	// 操作的功能名稱
	private boolean	transaction_result_flag = false;	// 操作結果成功與否
	private String	transaction_result_message = null;	// 操作結果（錯誤）訊息
	private String  transaction_reason_code = null;	// 交易（查詢）理由代碼
	private String  transaction_reason_name = null;	// 交易（查詢）理由名稱
	private String	transaction_bank_code = null;	// 操作交易關聯銀行代碼
	private String	transaction_input = null;		// 操作輸入資料
	private String	transaction_output = null;		// 擦做輸出資料
	private String	transaction_data_id = null;		// 操作對應資料 ID
	private String	transaction_data_link = null;	// 操作對應的資料鏈接 URI
	private int		transaction_cert_type = 0;			// 操作交易憑證種類
	private String	transaction_cert_serial = null;		// 操作交易憑證(簽章／加密)序號
	private String  transaction_cert_issuer = null;		// 操作交易憑證(簽章／加密)簽發者
	private String  transaction_cert_subject = null;	// 操作交易憑證(簽章／加密)主旨
	private MyDate  transaction_cert_expire = null;		// 操作交易憑證(簽章／加密)到期日
	private String	transaction_signature = null;	// 操作交易簽章值(Base64)
	private String	transaction_order_no = null;	// 此信用報告查閱對應的訂單編號
	private int		transaction_device_type = 0;	// 此信用報告查閱的終端設備：0 PC，1 手機
	private ReportStatus transaction_reportStatus = null;	// 此信用報告查閱記錄的查閱狀態
	/*
	Date: 2016/12/22
	Author: Hsuan 
	WHY: 增加 加查項目(信用評分)及查詢理由
	*/
	private String	transaction_query_item = null;	// 加查項目
	private String	transaction_query_reason = null;	// 查詢理由

	// 交易種類
	public static final int	CATALOG_CREDIT_REPORT = 1;		// 信用報告操作類別
	public static final int	CATALOG_CREDIT_PAYMENT = 2;		// 信用報告付費操作類別
	public static final int CATALOG_SETUP_EMAIL = 3;		// 設定通知郵件操作類別
	public static final int CATALOG_JCIC_TOKEN = 4;			// 註冊聯徵載具操作類別
	// Add by 何政東, 20190107, catalog for online annotation
	public static final int CATALOG_ONLINE_ANNOTATION = 5;  // 線上查詢註記操作類別
		
	private String[] CATALOG_NAMES = {
			"credit_report", "consent", "setup_mail", "jcic_token", "unknown"
	};
	
	public void	setID(long id) {
		transaction_id = id;
	}
	
	public long	getID() {
		return transaction_id;
	}

	public void	setCatalog(int catalog) {
		if (catalog < CATALOG_CREDIT_REPORT || catalog > CATALOG_SETUP_EMAIL) return;
		transaction_catalog = catalog;
	}
	
	public int	getCatalog() {
		return transaction_catalog;
	}
	
	public static boolean isValidCatalog(int catalog) {
		if (catalog < CATALOG_CREDIT_REPORT || catalog > CATALOG_SETUP_EMAIL) return false;
		return true;
	}
	
	public String	getCatalogName() {
		if (transaction_catalog < CATALOG_CREDIT_REPORT || transaction_catalog > CATALOG_SETUP_EMAIL) {
			return CATALOG_NAMES[CATALOG_SETUP_EMAIL+1];
		}
		return CATALOG_NAMES[transaction_catalog];
	}
	
	public void	setTime(MyDate time) {
		transaction_time = time;
	}
	
	public MyDate	getTime() {
		return transaction_time;
	}
	
	public String getTimeString() {
		if (transaction_time == null) return "";
		return transaction_time.getDateTimeDisplay();
	}
	
	public String getDateString() {
		if (transaction_time == null) return "";
		return transaction_time.getDateDisplay();
	}
	
	public void setServerIP(String ip) {
		this.transaction_server_ip = ip;
	}
	
	public String getServerIP() {
		if (this.transaction_server_ip == null) return "";
		return this.transaction_server_ip;
	}
	
	public void setSessionId(String session_id) {
		this.transaction_session_id = session_id;
	}
	
	public String getSessionId() {
		if (this.transaction_session_id == null) return "";
		return this.transaction_session_id;
	}
	
	public void setUserIP(String ip) {
		this.transaciton_user_ip = ip;
	}
	
	public String getUserIP() {
		return this.transaciton_user_ip;
	}
	
	public void setUserType(int	type) {
		transaction_user_type = type;
	}
	
	public int	getUserType() {
		return transaction_user_type;
	}
	
	public String getUserTypeName() {
		return EndUser.getUserTypeNameByType(transaction_user_type);
	}
	
	public void	setUserId(String user_id) {
		transaction_user_id = user_id;
	}
	
	public String	getUserId() {
		return transaction_user_id;
	}
	
	public String	getMaskUserId() {
		if (transaction_user_id == null) return "";
		return FormatCheckUtil.maskPersonalID(transaction_user_id);
	}
	
	public void	setFunction(String function) {
		transaction_function = function;
	}
	
	public String	getFunction() {
		return transaction_function;
	}
	
	public void	setResultFlag(boolean flag) {
		transaction_result_flag = flag;
	}
	
	public boolean isResultSucceed() {
		return transaction_result_flag;
	}
	
	public void setResultMessage(String message) {
		this.transaction_result_message = message;
	}
	
	public String getResultMessage() {
		return this.transaction_result_message;
	}
	
	public String getResultCode() {
		if (this.transaction_result_flag || this.transaction_result_message == null) return "";
		int pos = 0;
		while (pos < this.transaction_result_message.length()) {
			char c = this.transaction_result_message.charAt(pos);
			if (c >= '0' && c <= '9') break;
			pos++;
		}
		if (pos >= this.transaction_result_message.length()) return "????";
		int epos = pos+1;
		while (epos < this.transaction_result_message.length()) {
			char c = this.transaction_result_message.charAt(epos);
			if (c < '0' || c > '9') break;
			epos++;
		}
		return this.transaction_result_message.substring(pos, epos);
	}
	
	public void setReasonCode(String reason_code) {
		this.transaction_reason_code = reason_code;
	}
	
	public String getReasonCode() {
		return this.transaction_reason_code;
	}
	
	public void setReasonName(String reason_name) {
		this.transaction_reason_name = reason_name;
	}
	
	public String getReasonName() {
		return this.transaction_reason_name;
	}
	
	public String getReason() {
		String reason = "";
		if (this.transaction_reason_name != null) reason += this.transaction_reason_name;
		if (this.transaction_reason_code != null) reason += "("+this.transaction_reason_code+")";
		return reason; 
	}
	
	public void setBank(String bank_code) {
		transaction_bank_code = bank_code;
	}
	
	public String getBank() {
		return transaction_bank_code;
	}
	
	public String getBankName() {
		if (transaction_bank_code == null) return "";
		String bankName = BankUtility.findFiscBankNameById(transaction_bank_code);
		if (bankName == null) return "";
		return bankName;
	}
	
	public void	setInput(String input) {
		transaction_input = input;
	}
	
	public String	getInput() {
		return transaction_input;
	}
	
	public void	setOutput(String output) {
		transaction_output = output;
	}
	
	public String	getOutput() {
		return transaction_output;
	}
	
	public void	setDataID(String id) {
		transaction_data_id = id;
	}
	
	public String	getDataID() {
		return transaction_data_id;
	}
	
	public void	setDataLink(String link) {
		transaction_data_link = link;
	}
	
	public String	getDataLink() {
		return transaction_data_link;
	}
	
	public void setCertType(int cert_type) {
		transaction_cert_type = cert_type;
	}
	
	public int	getCertCertType() {
		return transaction_cert_type;
	}
	
	public String getCertTypeName() {
		return EndUser.getCertTypeNameByType(transaction_cert_type);
	}
	
	public void	setCertificate(byte[] certificate) {
		if (certificate == null) {
			this.transaction_cert_serial = null;
			this.transaction_cert_subject = null;
			this.transaction_cert_expire = null;
		} else {
			SecurityProvider security = new SecurityProvider();
			if (!security.setEncodeCertificate(certificate)) {
				Log.error(this, "setnCertificate", "sign certificate not X509 format");
				return;
			}
			this.transaction_cert_serial = security.getCertificateSerialNumber();
			this.transaction_cert_subject = security.getCertificateOwner();
			this.transaction_cert_expire = security.getCertificateExpireDate();
		}
	}
		
	public void setBase64Certificate(String certificate) {
		if (certificate == null) {
			this.transaction_cert_serial = null;
			this.transaction_cert_subject = null;
			this.transaction_cert_expire = null;
		} else {
			SecurityProvider security = new SecurityProvider();
			if (!security.setBase64Certificate(certificate)) {
				Log.error(this, "setBase64Certificate", "sign certificate not X509 format");
				return;
			}
			this.transaction_cert_serial = security.getCertificateSerialNumber();
			this.transaction_cert_subject = security.getCertificateOwner();
			this.transaction_cert_expire = security.getCertificateExpireDate();
		}
	}
		
	public void setCertIssuer(String issuer) {
		this.transaction_cert_issuer = issuer;
	}
	
	public String getCertIssuer() {
		String value = this.transaction_cert_issuer;
		if (value == null) value = "";
		return value;
	}
	public void setCertSubject(String subject) {
		this.transaction_cert_subject = subject;
	}
	
	public String getCertSubject() {
		String value = this.transaction_cert_subject;
		if (value == null) value = "";
		return value;
	}
	
	public void setCertSerial(String serial) {
		this.transaction_cert_serial = serial;
	}
	
	public String getCertSerial() {
		String value = this.transaction_cert_serial;
		if (value == null) value = "";
		return value;
	}
	
	public void setCertExpireTime(MyDate time) {
		this.transaction_cert_expire = time;
	}
	
	public MyDate getCertExpireTime() {
		return this.transaction_cert_expire;
	}
	
	public String getCertExpireTimeString() {
		String value = "";
		if (this.transaction_cert_expire != null) {
			value = this.transaction_cert_expire.getDateTimeDisplay();
		}
		return value;
	}
	
	public void	setSignature(byte[] signature) {
		if (this.transaction_signature == null) 
			this.transaction_signature = null;
		else
			this.transaction_signature = Base64.encodeBase64String(signature);
	}
	
	public byte[]	getSignature() {
		if (this.transaction_signature == null) return null;
		try {
			return Base64.decodeBase64(this.transaction_signature);
		} catch (Exception ex) {
			Log.error(this, "getSignature", "transaction signature not base64 format");
			return null;
		}
	}
	
	public void setBase64Signature(String signature) {
		if (signature == null) 
			this.transaction_signature = null;
		else {
			this.transaction_signature = signature;
		}
	}
	
	public String	getBase64Signature() {
		if (transaction_signature != null)
			return this.transaction_signature;
		else
			return "";
	}
	
	public void setQueryItem(String queryitem) {
		this.transaction_query_item = queryitem;
	}
	
	public String getQueryItem() {
		if (this.transaction_query_item == null) return "";
		return this.transaction_query_item;
	}
	
	public void setQueryReason(String queryreason) {
		this.transaction_query_reason = queryreason;
	}
	
	public String getQueryReason() {
		if (this.transaction_query_reason == null) return "";
		return this.transaction_query_reason;
	}
	
	/**
	 * 以下的 Code 為增加收費機制，信用報告查閱記錄對應到對應的訂單編號
	 * Date: 2017/07/31
	 * @author Bruce Huang
	 */
	
	/**
	 * 設定此筆查閱記錄對應的訂單編號
	 * @param orderNo	訂單編號
	 */
	public void setOrderNo(String orderNo) {
		this.transaction_order_no = orderNo;
	}
	
	/**
	 * 讀取此查閱記錄對應的訂單編號
	 * @return	傳回訂單編號
	 */
	public String getOrderNo() {
		return this.transaction_order_no;
	}
	
	/**
	 * 設定此筆查閱記錄使用者的終端設備類型
	 * @param device_type	使用者終端設備類型：0 為 PC，1 為 手機
	 */
	public void setDeviceType(int device_type) {
		this.transaction_device_type = device_type;
	}
	
	/**
	 * 讀取此筆查閱記錄使用者的終端設備類型
	 * @return 返回 0 表示使用者終端為 PC；1 表示使用者終端為手機
	 */
	public int	getDeviceType() {
		return this.transaction_device_type;
	}
		
	/**
	 * 設定此筆查閱記錄的報告查閱狀態
	 * @param status
	 */
	public void setReportStatus(ReportStatus status) {
		this.transaction_reportStatus = status;
	}
	
	/**
	 * 讀取此筆查閱記錄的報告查閱狀態
	 * @return
	 */
	public ReportStatus getReportStatus() {
		return this.transaction_reportStatus;
	}
	
}
