/**
 * 
 */
	document.write("<DIV id='cc' style='BORDER-RIGHT: #000000 1px solid; PADDING-RIGHT: 0px; BORDER-TOP: #000000 1px solid; PADDING-LEFT: 0px; Z-INDEX: 2; BACKGROUND: #ffffff; FILTER: Alpha(opacity=85); PADDING-BOTTOM: 3px; BORDER-LEFT: #000000 1px solid;  LINE-HEIGHT: 22px; PADDING-TOP: 3px; BORDER-BOTTOM: #000000 1px solid; POSITION: absolute; TOP: 100px; LEFT: 100px; VISIBILITY: hidden;  WIDTH: 160px; HEIGHT: 160px'></DIV>");
//	document.write("<style>td {font-family: Arial, Helvetica, sans-serif;font-size: 11px;}table{border-collapse:collapse} .sel{font-family: Webdings;font-size: 9pt;font-weight: bold;color: #000000;cursor:hand;text-decoration: none; background-color:ff6464}body {margin-left:0px;margin-top: 0px;}</style>");
	document.write("<style>td {font-family: Arial, Helvetica, sans-serif;font-size: 11px;}table{border-collapse:collapse} .sel{font-family: sans-serif;font-size: 9pt;font-weight: bold;color: #000000;cursor:hand;text-decoration: none; background-color:ff6464}body {margin-left:0px;margin-top: 0px;}</style>");

	var dateInputObject;
	
   
   function newdate_onload() {
	   alert("newdate.js load");
  }
   
   function dateSelect(objname) {
	   
	   var cc = document.getElementById("cc");
	   if (cc == null) {
		   return;
	   }
	   cc.style.filter="Alpha(opacity=85)";
	   var left=document.body.scrollLeft+window.event.clientX;
	   cc.style.top=document.body.scrollTop+window.event.clientY+10+"px";
	   //如果日历超过当前页面的可见宽度，则日历显示位置左移
	   if(left+160 > document.body.clientWidth){
		   cc.style.left=(left-160)+"px";
	   } else {
		   cc.style.left=(left+2)+"px";
	   }
	   cc.style.visibility="visible";
	   
	   dateInputObject = document.getElementById(objname);

	   if (dateInputObject == null) {
		   return;
	   }
	   showSelect();
	}
	
	function hiddeninfo() {
		var cc = document.getElementById("cc");
		cc.style.visibility="hidden";
	}
	
	function RunNian(The_Year){
		if ((The_Year%400==0) || ((The_Year%4==0) && (The_Year%100!=0)))
		  	return true;
		else
		  	return false;
	}
	
	function GetWeekday(The_Year,The_Month)
	{
		var Allday = 0;
		
		if (The_Year>2000){
			for (var i=2000 ;i<The_Year; i++){
			 	if (RunNian(i)) {
					Allday += 366;
				} else {
					Allday += 365;
				}
			}
			for (i=1; i<The_Month; i++){
				switch (i){
					case 2 :
						if (RunNian(The_Year))
						  	Allday += 29;
						else
							Allday += 28;
						 break;
					case 1:
					case 3:
					case 5:
					case 7:
					case 8:
					case 10:
					case 12:
							Allday += 31; break;
					case 4:
					case 6:
					case 9:
					case 11:
							Allday += 30; break;
				}
			}
		}
		return (Allday+6)%7;
	}
	
	function chooseday(The_Year,The_Month,The_Day){
		var Firstday;
		if (The_Day!=0){
			if (The_Month<10)
				The_Month="0"+The_Month;
			if(The_Day<10)
				The_Day="0"+The_Day;
		}
		//showdate 只是一个为了显示而采用的东西，
		//如果外部想引用这里的时间，可以通过使用 completely_date引用完整日期
		//也可以通过The_Year,The_Month,The_Day分别引用年，月，日
		//当进行月份和年份的选择时，认为没有选择完整的日期
		Firstday = GetWeekday(The_Year,The_Month);
		ShowCalender(The_Year,The_Month,The_Day,Firstday);
	}
	
	function chooses(The_Year,The_Month,The_Day){

		var completely_date;
		if (The_Day!=0){
			if(The_Month<10)
				The_Month="0"+The_Month;
			if(The_Day<10)
				The_Day="0"+The_Day;
		  	completely_date = The_Year + "/" + The_Month + "/" + The_Day;
		 }
		 else{
			completely_date = "";
		 }
		 dateInputObject.value = completely_date;
		 hiddeninfo();
	}
	
	function nextmonth(The_Year,The_Month){
		 if (The_Month==12)
		  	chooseday(The_Year+1,1,0,name);
		 else
		  	chooseday(The_Year,The_Month+1,0,name);
	}
	function prevmonth(The_Year,The_Month){
		 if (The_Month==1)
		  	chooseday(The_Year-1,12,0);
		 else
		  	chooseday(The_Year,The_Month-1,0);
	}
	function prevyear(The_Year,The_Month){
	 	chooseday(The_Year-1,The_Month,0);
	}
	function nextyear(The_Year,The_Month){
	 	chooseday(The_Year+1,The_Month,0);
	}
	
	function ShowCalender(The_Year,The_Month,The_Day,Firstday){
		 var ycdate="";
		 var showstr;
		 var Month_Day;
		 var ShowMonth;
		 var today;
		 today = new Date();
		 switch (The_Month){
			  case 1 : ShowMonth = "1月"; Month_Day = 31; break;
			  case 2 :
				   ShowMonth = "2月";
				   if (RunNian(The_Year))
						Month_Day = 29;
				   else
						Month_Day = 28;
				   break;
			  case 3 : ShowMonth = "3月"; Month_Day = 31; break;
			  case 4 : ShowMonth = "4月"; Month_Day = 30; break;
			  case 5 : ShowMonth = "5月"; Month_Day = 31; break;
			  case 6 : ShowMonth = "6月"; Month_Day = 30; break;
			  case 7 : ShowMonth = "7月"; Month_Day = 31; break;
			  case 8 : ShowMonth = "8月"; Month_Day = 31; break;
			  case 9 : ShowMonth = "9月"; Month_Day = 30; break;
			  case 10 : ShowMonth = "10月"; Month_Day = 31; break;
			  case 11 : ShowMonth = "11月"; Month_Day = 30; break;
			  case 12 : ShowMonth = "12月"; Month_Day = 31; break;
			  default: ShowMonth = "1月";  The_Month = 1; Month_Day = 31; break;
		 }
		showstr = "";
		showstr = "<table cellpadding=0 cellspacing=0 border=1 bordercolor=#fd9d9d width=95% align=center valign=top >"; //上边框颜色
		showstr +=  "<tr ><td height=20 width=0 class='sel' onclick=prevyear("+The_Year+","+The_Month+")>&lt;</td><td  height=20 width=0>&nbsp;&nbsp;&nbsp;" + The_Year + "年&nbsp;</td><td  height=20 width=0 onclick=nextyear("+The_Year+","+The_Month+") class='sel'>&gt;</td><td  height=20 width=0 class='sel' onclick=prevmonth("+The_Year+","+The_Month+")>&lt;</td><td  height=20 width=40 align=center>" + ShowMonth + "</td><td  height=20 width=0 onclick=nextmonth("+The_Year+","+The_Month+")  class='sel'>&gt;</td></tr>";
		showstr +=  "<tr ><td align=center width=100% colspan=6>";
		showstr +=  "<table cellpadding=0 cellspacing=0 border=1 bordercolor=#fd9d9d width=100%>";//内边框颜色
		showstr += "<tr align=center bgcolor=#fd9d9d> ";//星期td背景
		showstr += "<td height=25><strong><font color=#ff0000>日</font></strong></td>";
		showstr += "<td height=25><strong><font color=#000000>一</font></strong></td>";
		showstr += "<td height=25><strong><font color=#000000>二</font></strong></td>";
		showstr += "<td height=25><strong><font color=#000000>三</font></strong></td>";
		showstr += "<td height=25><strong><font color=#000000>四</font></strong></td>";
		showstr += "<td height=25><strong><font color=#000000>五</font></strong></td>";
		showstr += "<td height=25><strong><font color=#ff0000>六</font></strong></td>";
	 	showstr += "</tr><tr>";
		for (var i=0; i<Firstday; i++)
		  	showstr += "<Td height=20  width=20 align=center bgcolor=#ffffff>&nbsp;</Td>";//月前空日日期背景
		for (i=1; i<=Month_Day; i++){
			if (The_Year==today.getFullYear() && The_Month==(today.getMonth()+1) && i==today.getDate()) {
				bgColor = "#ea9663";//当前日期td颜色
				ycdate = "<b><font color='#ff0000'>" + i + "</font></b>";
			}else{
				bgColor = "#ffe6e5";//大部分td颜色
				ycdate=i+"";
	  	   	}
			if (The_Day==i) bgColor = "#ffffff";//选择日期td颜色
		  	showstr += "<td height=20 width=20 align=center bgcolor=" + bgColor + " style='cursor:hand' onclick=chooses(" + The_Year + "," + The_Month + "," + i + ")>" + ycdate + "</td>";
		  	Firstday = (Firstday + 1)%7;
		  	if ((Firstday==0) && (i!=Month_Day)) showstr += "</tr><tr>";
	 	 }
		 if (Firstday!=0) {
			 for (i=Firstday; i<7; i++)
				 showstr += "<td height=20 width=20 align=center bgcolor=#ffffff>&nbsp;</td>";//月尾空日td背景
			 showstr += "</tr>";
		 }
		 showstr += "</tr></table></td></tr><tr ><td height=20 colspan='7' align='center' valign='bottom'><a href=# style='font-size: 9pt;color: #000000;text-decoration: none' onclick='hiddeninfo()'>&nbsp;&nbsp;&nbsp;&nbsp;取消&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr></table>";
		 var cc = document.getElementById("cc");
		 cc.innerHTML = showstr;
	}

	function showSelect() {
		
		var The_Year,The_Day,The_Month;
		var today = new Date();
		var Firstday;

		// Add by 何政東, 20190108, add filter 
		// add filter
		var value = dateInputObject.value.replace(/[\$\<\>]/g,'');
		if (value != null && value.length >= 10) {
			try {
				The_Year = value.substr(0,4);
				The_Month = value.substr(5,2) - 1;
				The_Day = value.substr(8,2);
				today = new Date(The_Year, The_Month, The_Day, 0,0,0,0);
			} catch (e) {
			}
		}
		The_Year = today.getFullYear();
		The_Month = today.getMonth() + 1;
		The_Day = today.getDate();
		Firstday = GetWeekday(The_Year,The_Month);
		ShowCalender(The_Year,The_Month,The_Day,Firstday);
	 }
	 